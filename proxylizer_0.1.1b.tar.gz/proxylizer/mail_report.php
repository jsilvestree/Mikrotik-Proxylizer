<?php
/****************************************************************************
*                                                                           *
*    MikroTik Proxylizer, Web-proxy log analyzer                            *
*    Copyright (C) 2009  MikroTik                                           *
*                                                                           *
*    This program is free software: you can redistribute it and/or modify   *
*    it under the terms of the GNU General Public License as published by   *
*    the Free Software Foundation, either version 3 of the License, or      *
*    (at your option) any later version.                                    *
*                                                                           *
*    This program is distributed in the hope that it will be useful,        *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of         *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
*    GNU General Public License for more details.                           *
*                                                                           *
*    You should have received a copy of the GNU General Public License      *
*    along with this program.  If not, see <http://www.gnu.org/licenses/>.  *
*                                                                           *
****************************************************************************/
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/index.php");
    return false;
}
//////////////////////////////////////////////////////////////////////////////////////////////////////
if (!isset($_REQUEST['add_new']) || !isset($_REQUEST['save'])) {
    $addorsavereportname = "add_new";
    $addorsavereportvalue = "Add new";
    $addorsavereport = "Add report :";
//    $add_saveandpreviewname = "add_preview";
//    $add_saveandpreviewvalue = "Add & preview";
}
if (isset($_REQUEST['add_new'])) {
    $valid_req = checkMailReportForm();
    insertMailreportConf($valid_req);
    if ($_REQUEST['noworlater'] == 'now' && $_REQUEST['frequency'] == FQ_ONCE) {
        echo "<div align=\"center\"><a href=\"". ACTIVE_PAGE ."\">[GO BACK]</a></div>\n";
        echo "<div id=\"errors\">{$errors}</div>\n";
        $id = selectLastId('report_config');
        echo notGeneratedCheckStatus($id);
        echo "<div align=\"center\"><a href=\"". ACTIVE_PAGE ."\">[GO BACK]</a></div>\n";
    }
} elseif (isset($_REQUEST['cancel'])) {
    unset($_REQUEST);
} elseif (isset($_REQUEST['inactive'])) {
    $id = (int) $_REQUEST['inactive'];
    reportOn($id);
} elseif (isset($_REQUEST['active'])) {
    $id = (int) $_REQUEST['active'];
    reportOff($id);
} elseif (isset($_REQUEST['delete'])) {
    $id = (int) $_REQUEST['delete'];
    deleteReport($id);
//} elseif (isset($_REQUEST['save_preview'])){
//    $id = (int) $_REQUEST['edit'];
//    $valid_req = checkMailReportForm();
//    if($valid_req) {
//        alterReportConf($id, $valid_req);
//        echo "<div align=\"center\"><a href=\"". ACTIVE_PAGE ."\">[GO BACK]</a></div>";
//        echo writeReportResult($id);
//        echo "<div align=\"center\"><a href=\"". ACTIVE_PAGE ."\">[GO BACK]</a></div>";
//    } else {
//        unset($_REQUEST['save_preview']);
//        $_REQUEST['save'] = true;
//        $cancelbutton = "<input type=\"submit\" name=\"cancel\" value=\"Cancel\"/>";
//        $addorsavereportname = "save";
//        $addorsavereportvalue = "Save";
//        $addorsavereport = "Edit report :";
//        $add_saveandpreviewname = "save_preview";
////        $add_saveandpreviewvalue = "Save & preview";
//        $editordelete = "&edit=". $_REQUEST['edit'] ."";
//    }
} elseif (isset($_REQUEST['save'])) {
    $valid_req = checkMailReportForm();
    if($valid_req) {
        $id = (int) $_REQUEST['edit'];
        alterReportConf($id, $valid_req);
        //unset($_REQUEST);
    } else {
        $cancelbutton = "<input type=\"submit\" name=\"cancel\" value=\"Cancel\"/>";
        $addorsavereportname = "save";
        $addorsavereportvalue = "Save";
        $addorsavereport = "Edit report :";
//        $add_saveandpreviewname = "save_preview";
//        $add_saveandpreviewvalue = "Save & preview";
        $editordelete = "&edit=". $_REQUEST['edit'] ."";
    }
} elseif (isset($_REQUEST['edit'])) {
//    $a_disable = "style=\"display: none;\"";
//    $disabled = "disabled=\"disabled\"";
//    $readonly = "readonly=\"readonly\"";
    $cancelbutton = "<input type=\"submit\" name=\"cancel\" value=\"Cancel\"/>";
    $addorsavereportname = "save";
    $addorsavereportvalue = "Save";
    $addorsavereport = "Edit report :";
//    $edit_border = "style=\"border: 1px solid #ff0000;\"";
//    $add_saveandpreviewname = "save_preview";
//    $add_saveandpreviewvalue = "Save & preview";
    $id = (int)$_REQUEST['edit'];
    editReportConf($id);
    $editordelete = "&edit=". $_REQUEST['edit'] ."";
//} elseif (isset($_REQUEST['add_preview'])){
//    $valid_req = checkMailReportForm();
//    if ($valid_req){
//        $id = insertMailreportConf($valid_req);
//        echo "<div align=\"center\"><a href=\"". ACTIVE_PAGE ."\">[GO BACK]</a></div>";
//        echo writeReportResult($id);
//        echo "<div align=\"center\"><a href=\"". ACTIVE_PAGE ."\">[GO BACK]</a></div>";
//    } else {
//        unset($_REQUEST['add_preview']);
//        $_REQUEST['add_new'] = true;
//    }
//} elseif (isset($_REQUEST['preview'])) {
//    echo "<div align=\"center\"><a href=\"". ACTIVE_PAGE ."\">[GO BACK]</a></div>";
//    $id = (int) $_REQUEST['preview'];
//    echo writeReportResult($id);
//    echo "<div align=\"center\"><a href=\"". ACTIVE_PAGE ."\">[GO BACK]</a></div>";
} elseif (isset($_REQUEST['history'])) {
    echo "<div align=\"center\"><a href=\"". ACTIVE_PAGE ."\">[GO BACK]</a></div>\n";
    echo "<div id=\"errors\">{$errors}</div>\n";
    $id = (int) $_REQUEST['history'];
    echo writeGeneratedReportsTable($id);
    echo "<div align=\"center\"><a href=\"". ACTIVE_PAGE ."\">[GO BACK]</a></div>\n";
}
// default values
if(!isset($_REQUEST['date1']) && !isset($_REQUEST['date2']) && !isset($_REQUEST['date1when']) &&
    !isset($_REQUEST['date2when']) && !isset($_REQUEST['datelater']) && !isset($_REQUEST['clocktime2input'])
    && !isset($_REQUEST['clocktimestart1']) && !isset($_REQUEST['clocktimeend1']) 
    && !isset($_REQUEST['monthdays2']) && !isset($_REQUEST['frequency'])) {
        $_REQUEST['date1'] = $_REQUEST['date2'] = $_REQUEST['date1when'] = date("Y-m-d");
        $_REQUEST['date2when'] = $_REQUEST['datelater'] = date("Y-m-d");
        $_REQUEST['clocktime2input'] = date("H:i",strtotime("now")+300);
        $_REQUEST['clocktimestart1'] = "00:00";
        $_REQUEST['clocktimeend1'] = "23:59";
        $_REQUEST['monthdays2'] = 31;
        $_REQUEST['frequency'] = FQ_ONCE;
}
//if(!isset($_REQUEST['frequency'])){
//    $_REQUEST['frequency'] = FQ_ONCE;
//}
if(!isset($_REQUEST['noworlater'])) {
    $_REQUEST['noworlater'] = "now";
}
//print_r($_REQUEST);
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$report_type_sbox = "<select onchange=\"showHideReportType('report_type')\" id=\"report_type\" name=\"report_type\">\n";
foreach ($report_type as $key=>$value) {
    $report_type_sbox .= "<option value=\"{$key}\"";
    if ($_REQUEST['report_type'] == $key) {
        $report_type_sbox .= " selected=\"selected\"";
    } else {
        $report_type_sbox .= $disabled;
    }
    $report_type_sbox .= "> {$value} </option>\n";
}
$report_type_sbox .= "</select>";

$frequencyoption = "<select onchange=\"showHideOptions('frequency')\" id=\"frequency\" name=\"frequency\">\n";
foreach ($frequency as $key=>$value) {
    $frequencyoption .= "\n<option " 
    . " value=\"{$key}\"";
    $aaaa = '';
    if ($_REQUEST['frequency'] == $key) {
        $frequencyoption .= " selected=\"selected\"";
    } else {
        $frequencyoption .= $disabled;
    }
    $frequencyoption .= "> {$value} </option>\n";
}
$frequencyoption .= "</select>";

$topoption = "";
foreach ($TOP as $key=>$value) {
    $topoption .= "<option value=\"{$key}\"";
    if ($_REQUEST['top'] == $key) {
        $topoption .= " selected=\"selected\"";
    } else {
        $topoption .= $disabled;
    }
    $topoption .= "> {$value}</option>\n";
}
for($i = 1; $i<=31; $i++) {
    $j = ($i < 0 || $i > 9) ? $i : "0{$i}";
    $monthdayoption .= "<option value=\"{$j}\"";
    if ($_REQUEST['monthdayoption'] == $i) $monthdayoption .= " selected=\"selected\"";
    $monthdayoption .= ">{$i}</option>\n";
}
for($i = 1; $i<=31; $i++) {
    $j = ($i < 0 || $i > 9) ? $i : "0{$i}"; 
    $monthdays1 .= "<option value=\"{$j}\"";
    if ($_REQUEST['monthdays1'] == $i){
        $monthdays1 .= " selected=\"selected\"";
    } else {
        $monthdays1 .= $disabled;
    }
    $monthdays1 .= ">{$i}</option>\n";
}
for($i = 1; $i<=31; $i++) {
    $j = ($i < 0 || $i > 9) ? $i : "0{$i}";
    $monthdays2 .= "<option value=\"{$j}\"";
    if ($_REQUEST['monthdays2'] == $i) {
        $monthdays2 .= " selected=\"selected\"";
    } else {
        $monthdays2 .= $disabled;
    }
    $monthdays2 .= ">{$i}</option>\n";
}
$weekaboutcheckboxes .= "<div id=\"weekdayabout\" style=\"padding: 5px\">\n";
foreach ($weekdays as $key=>$value) {
    if (isset($_REQUEST["dayabout$key"]) || (!isset($_REQUEST['add_new']) && !isset($_REQUEST['edit']))) {
        $checked = "checked=\"checked\"";
    } else {
        $checked = "";
    }
    $disabledweek = $disabled;
    if ($_REQUEST['frequency'] == 1) $disabledweek = "";
    $weekaboutcheckboxes .= "<input {$disabledweek} type=\"checkbox\" id=\"dayabout{$key}\" name=\"dayabout{$key}\""
        . " {$checked} onclick=\"doNotUnCheckAll('weekdayabout', 'dayabout{$key}', 'weekalertmsg1')\"/> "
        . "{$value} &nbsp;&nbsp;\n";
    if ($disabled && $checked && $_REQUEST['frequency'] != 1) {
        $weekaboutcheckboxes .= "\n<input type=\"hidden\" name=\"dayabout{$key}\" value=\"1\"/>\n";
    }
}
$weekaboutcheckboxes .= "</div><!--EOF weekday-->\n<div id=\"weekalertmsg1\" style=\"color: #FF0000;" 
            . "font-weight: bold;\">\n</div><!--EOF alert-->\n";

$weekwhencheckboxes .= "<div id=\"weekdaywhen\" style=\"padding: 5px\">\n";

foreach ($weekdays as $key=>$value) {
    if (isset($_REQUEST["daywhen$key"]) || (!isset($_REQUEST['add_new']) && !isset($_REQUEST['edit']))) {
        $checked = "checked=\"checked\"";
    } else {
        $checked = "";
    }
    $weekwhencheckboxes .= "<input {$disabled} type=\"checkbox\" id=\"daywhen{$key}\" name=\"daywhen{$key}\""
        . " {$checked} onclick=\"doNotUnCheckAll('weekdaywhen','daywhen{$key}','weekalertmsg2')\"/> "
        . "{$value} &nbsp;&nbsp;\n";
    if ($disabled && $checked) {
        $weekwhencheckboxes .= "\n<input type=\"hidden\" name=\"daywhen{$key}\" value=\"1\"/>\n";
    }
}
$weekwhencheckboxes .= "</div><!--EOF weekday-->\n<div id=\"weekalertmsg2\" style=\"color: #FF0000;" 
            . "font-weight: bold;\">\n</div><!--EOF alert-->\n";

foreach ($weekdays as $key=>$value) {
    $weekdayoption .= "<option value=\"{$key}\"";
    if ($_REQUEST['weekdayoption'] == $key) $weekdayoption .= " selected=\"selected\"";
    $weekdayoption .= ">{$value}</option>\n";
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
if(!isset($_REQUEST['preview']) && 
    !(isset($_REQUEST['add_new']) && $_REQUEST['noworlater']=='now' && $_REQUEST['frequency']== FQ_ONCE) 
    && !isset($_REQUEST['history'])) {
    include ("templates/mail_report_form.php");
    writeRepConfTable();
}

echo "<script type=\"text/javascript\"> " . 
    " //function initShowHideOpt() {showHideOptions('frequency')}\n" .
    " womAdd('showHideOptions(\"frequency\")');\n" .
    " //function initShowHideRepType() {showHideReportType('report_type')}\n" . 
    " womAdd('showHideReportType(\"report_type\")');\n" .
    " //function initShowNorL() {showHideNowOrLater('" . $_REQUEST['frequency'] . "','" . $_REQUEST['noworlater'] . "')}" .
    " womAdd('showHideNowOrLater(\"" . $_REQUEST['frequency'] . "\",\"" . $_REQUEST['noworlater'] . "\")');\n " .
    " womOn();</script>\n";

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function checkMailReportForm() {
global $frequency, $TOP, $weekdays, $report_type;
global $errors, $errorcount;
    $errorcount = 0;
    $valid_request = array();
    if (isset($_REQUEST['report_name'])) {
    	$valid_request['report_name'] = parseAndSplitInput($_REQUEST['report_name'], REPORT_NAME_LENGTH, REPORT_NAME_WORD_LENGTH);
        if($valid_request['report_name'] === false) {
            $errorcount++;
            $errors .= errorMesage("Report name to long, please choose another!");
        } else {
            // a;
        }
    }
    
    if(isset($_REQUEST['report_type'])) {
        if (!array_key_exists($_REQUEST['report_type'], $report_type)) {
            $errors .= errorMesage("Not valid report type!");
            $errorcount++;
        } else {
            $valid_request['rep_type'] = $_REQUEST['report_type'];
        }
    }
    if ($_REQUEST['report_type'] == 2 && $_REQUEST['frequency']!= 1) {
        $errors .= errorMesage("Sorry, only domain daily report available!");
        $errorcount++;
    }
    if(isset($_REQUEST['ip_users'])) {
        if($_REQUEST['ip_users'] == false) {
            $valid_request['email'] = false;
        } else {
            $isvalidemail = ereg("^[a-zA-Z0-9_\.]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-\.]+$", $_REQUEST['ip_users']);
            if($isvalidemail == false) {
                $errors .= errorMesage("Not valid e-mail address!");
                $errorcount++;
            } else {
                $valid_request['email'] = $_REQUEST['ip_users'];
                
            }
        } 
    }
    if(isset($_REQUEST['is_sendtoadmin'])) {
        $valid_request['sendtoadmin'] = true;
    } else {
        $valid_request['sendtoadmin'] = false;
    }
    if(isset($_REQUEST['frequency'])) {
        if (!array_key_exists($_REQUEST['frequency'], $frequency)) {
            $errors .= errorMesage("Not valid frequency value!");
            $errorcount++;
        } else {
            $valid_request["current_frequency"] = $_REQUEST['frequency'];
        }
    }
    if(isset($_REQUEST['IP'])) {
        if($_REQUEST['IP'] != ""){
            if($_REQUEST['IP'] != 0) {
                $ip = ip2long($_REQUEST['IP']);
                if($ip == false) {
                    $errors .= errorMesage("Invalid IP address!");
                    $errorcount++;
                }
            } else {
                $ip = 0;
            }
            $valid_request["ip"] = $ip; 
        } else {
            $errors .= errorMesage("No IP value selected!");
            $errorcount++;
        }
    }
    $time_array = parseTimeIntervals();
    $valid_request["time_array"] = $time_array;
    if ($_REQUEST['subdomain'] !="") {
        $valid_request["subdomain"] = requestToQuery($_REQUEST['subdomain']);
    }
    if ($_REQUEST['domain'] !="") {
        $valid_request["domain"] = requestToQuery($_REQUEST['domain']);
    }
    if ($_REQUEST['topdomain'] !="") {
        $valid_request["topdomain"] = requestToQuery($_REQUEST['topdomain']);
    }
    $week = parseWeek("about");
    if ($week == 0) $week = MON + TUE + WED + THU + FRI + SAT + SUN;
    $valid_request["week"] = $week;
    if ($_REQUEST['date1'] != "") {
        $valid_request["date1"] = requestToValidDate($_REQUEST['date1']);
    }
    if ($_REQUEST['date2'] != "") {
        $valid_request["date2"] = requestToValidDate($_REQUEST['date2']);
    }
    if(strtotime($valid_request['date1']) > strtotime($valid_request['date2'])) {
        $errors .= errorMesage("First date greater than second!");
        $errorcount++;
    }
    if (isset($_REQUEST['top'])) {
        if (!array_key_exists($_REQUEST['top'], $TOP)) {
            $errors .= errorMesage("Not valid Top value");
            $errorcount++;
        } else {
            $valid_request["current_top"] = $_REQUEST['top'];
        }
    }
    if ($_REQUEST['datelater'] != "") {
        $valid_request["datelater"] = requestToValidDate($_REQUEST['datelater']);
    }
    if ($_REQUEST['clocktime2input'] != "") {
        $time = strtotime($_REQUEST['clocktime2input']);
        if ($time == false) {
            $errors .= errorMesage("Invalid time format!");
            $errorcount++;
        } else {
            $time = date("H:i", $time);
        }
        $valid_request['timewhen'] = $time;
    }
//    if ($_REQUEST['frequency'] == FQ_ONCE && $_REQUEST['noworlater'] == "later") {
//        if(strtotime($valid_request['datelater'] . " " . $valid_request['timewhen']) < strtotime("now")) {
//            $errors .= errorMesage("Send time already past!");
//            $errorcount++;
//        }
//    }
    if ($_REQUEST['frequency'] == FQ_ONCE && $_REQUEST['noworlater'] == "now") {
        $valid_request['datelater'] = date("Y-m-d", strtotime("now"));
        $valid_request['timewhen'] = date("H:i", strtotime("now"));
    }
    if ($_REQUEST['date1when'] != "") {
        $valid_request['date1when'] = requestToValidDate($_REQUEST['date1when']);
    }
    if ($_REQUEST['date2when'] != "") {
        $valid_request['date2when'] = requestToValidDate($_REQUEST['date2when']);
    }
    if(strtotime($valid_request['date1when']) > strtotime($valid_request['date2when'])) {
        $errors .= errorMesage("First date greater than second!");
        $errorcount++;
    }
//    $valid_request['weekwhen'] = parseWeek("when");
//    if ($valid_request['weekwhen'] == 0) $valid_request['weekwhen'] = MON + TUE + WED + THU + FRI + SAT + SUN; 
    if (isset($_REQUEST['weekdayoption'])) {
        if (!array_key_exists($_REQUEST['weekdayoption'], $weekdays)) {
            $errors .= errorMesage("Not valid week value!");
            $errorcount++;
        } else {
            $valid_request['weekdaywhen'] = $_REQUEST['weekdayoption'];
        }
    }
    if (isset($_REQUEST['monthdayoption'])) {
        if((int)$_REQUEST['monthdayoption'] >= 1 || (int)$_REQUEST['monthdayoption'] <= 31) {
            $valid_request['monthdaywhen'] = $_REQUEST['monthdayoption'];
        } else {
            $errors .= errorMesage("Not valid monthday value!");
            $errorcount++;
        }
    }
    if (isset($_REQUEST['monthdays1'])) {
        if((int)$_REQUEST['monthdays1'] == 1 || (int)$_REQUEST['monthdays1'] <= 31) {
            $valid_request['monthdays1'] = $_REQUEST['monthdays1'];
        } else {
            $errors .= errorMesage("Not valid monthday value!");
            $errorcount++;
        }
    }
    if (isset($_REQUEST['monthdays2'])) {
        if((int)$_REQUEST['monthdays2'] >= 1 || (int)$_REQUEST['monthdays2'] <= 31) {
            $valid_request['monthdays2'] = $_REQUEST['monthdays2'];
        } else {
            $errors .= errorMesage("Not valid monthday value!");
            $errorcount++;
        }
    }
    if ($valid_request['monthdays1'] > $valid_request['monthdays2']) {
        $errors .= errorMesage("First date bigger than second!");
        $errorcount++;
    }
    if (isset($_REQUEST['noworlater'])) {
        if ($_REQUEST['noworlater'] == "now" || $_REQUEST['noworlater'] == "later") {
            $valid_request['noworlater'] = $_REQUEST['noworlater'];
        } else {
            $errors .= errorMesage("Not valid value submited!");
            $errorcount++;
        }
    }
    if ($errorcount) {
        return false;
    } else {
        return $valid_request;
    }
}

function parseTimeIntervals() {
global $errors, $errorcount;
    $timearray = array();
    foreach ($_REQUEST as $key=>$value){
        if (ereg("^clocktimestart", $key)) {            
            $time = strtotime($value);
            if ($time == false) {
                $errors .= errorMesage("Invalid time format!");
                $errorcount++;
                return false;
            } else {
                $time = date("H:i", $time);
                $starttimeindex = str_replace("clocktimestart", "", $key);
                $timearray[$starttimeindex] = array ("start" => $value, "end" => $_REQUEST['clocktimeend' . $starttimeindex]);
            }
        }
    }
    if(!checkTimeIntervals($timearray)) {
        return false;
    }
    return $timearray;
}

function checkTimeIntervals($timearray) {
global $errors, $errorcount;
    for($i=1; $i<=count($timearray); $i++) {
        for($j=$i+1; $j<=count($timearray); $j++) {
            if((strtotime($timearray[$j]['start']) >= strtotime($timearray[$i]['start'])
            && strtotime($timearray[$j]['start']) < strtotime($timearray[$i]['end'])) ||
            (strtotime($timearray[$j]['start']) < strtotime($timearray[$i]['start']) 
            && strtotime($timearray[$j]['end']) > strtotime($timearray[$i]['start']))) {
                $errors = errorMesage("Time intervals overlap!");
                $errorcount++;
                return false;
            }
            }
    }
    return true;
}

function parseWeek($postfix) {
    $len = strlen("day{$postfix}");
    $w = 0;
    foreach ($_REQUEST as $key=>$value) {
        if (substr($key, 0, $len) == "day{$postfix}") $w += (int) substr($key, $len);
    }
    return $w;
}

function insertMailreportConf($validrequest) {
global $errors, $errorcount, $weekdays, $weeknums;
    if($validrequest != false) {
        if ($db = connectDB()) {
            
            switch($validrequest['current_frequency']) {
                case FQ_ONCE:
                    $validrequest['date1when'] = $validrequest['datelater'];
                    $validrequest['date2when'] = "";
                    $validrequest['weekwhen'] = 127;
                    break;
                case FQ_DAILY:
                    $validrequest['date1when'] = $validrequest['date1'];
                    $validrequest['date2when'] = $validrequest['date2'];
                    $validrequest['weekwhen'] = 127;
                    break;
                case FQ_WEEKLY:
                    $validrequest['date1when'] = $validrequest['date1'];
                    $validrequest['date2when'] = $validrequest['date2'];
                    //getCurrentWeekBounds($validrequest['date1'], $validrequest['date2']);
                    $validrequest['weekwhen'] = $validrequest['weekdaywhen'];
                    break;
                case FQ_MONTHLY:
                    $date1 = strtotime($validrequest['date1']);
                    $Y_of_date1 = date("Y", $date1);
                    $m_of_date1 = date("m", $date1);
                    $validrequest['date1'] = date("Y-m-", $date1) . $validrequest['monthdays1'];
                    $date2 = strtotime($validrequest['date2']);
                    $validrequest['date2'] = date("Y-m-", $date2) . $validrequest['monthdays2'];
                    $validrequest['date1when'] = "1970-01-" . $validrequest['monthdaywhen'];
//                    $validrequest['date2when'] = "1970-01-" . $validrequest['monthdays2'];
                    $validrequest['weekwhen'] = 127;
                    break;
            }
            $is_active_time = "2000-01-01";
            $query = "INSERT INTO report_config(report_name, email, send_to_admin, frequency, rep_type," 
                . " date_start, date_end, weekdays, send_date_start, send_date_end, send_time, send_weekday, "
                . "IP, sub_domain, domain, topdomain, top, is_active) VALUES('{$validrequest['report_name']}',"
                . " '{$validrequest['email']}', '{$validrequest['sendtoadmin']}', '{$validrequest['current_frequency']}', " 
                . " '{$validrequest['rep_type']}', '{$validrequest['date1']}', '{$validrequest['date2']}', "
                . " '{$validrequest['week']}', '{$validrequest['date1when']}', '{$validrequest['date2when']}', "
                . " '{$validrequest['timewhen']}', '{$validrequest['weekwhen']}', '{$validrequest['ip']}', "
                . " '{$validrequest['subdomain']}', '{$validrequest['domain']}', '{$validrequest['topdomain']}', "
                . " '{$validrequest['current_top']}', '{$is_active_time}')";
//            echo "</br> QUERY : " . $query;
            $insertdata = & $db->query($query);
            if (PEAR::isError($insertdata)) {
                $errors = errorMesage("Failed to insert data! " . $insertdata->getMessage());
                $errorcount++;
                return false;
            } else {
                $query = "SELECT MAX(id) FROM report_config";
                $res = & $db->query($query);
                if (PEAR::isError($res)){
                    $errors = errorMesage("Failed to get max id!");
                    $errorcount++;
                    return false;
                } else {
                    if ($row =& $res->fetchRow()) {
                        $rep_conf_id = $row['0'];
                        foreach ($validrequest['time_array'] as $value) {
                            $query = "INSERT INTO time_intervals(report_id, time_start, time_end) "
                            . " VALUES('{$rep_conf_id}', '{$value['start']}', "
                            . " '{$value['end']}')";
                            //echo "</br> QUERY : " . $query;
                            $inserttime = &$db->query($query);
                            if (PEAR::isError($insertdata)) {
                                $errors = errorMesage("Failed to insert data!");
                                $errorcount++;
                                return false;
                            } else {
                                //unset($_REQUEST);
                            }
                        }
                    } else {
                        return false;
                    }
                }
            }
        } else {
            $errors .= errorMesage("Failed to connect to data base!");
            $errorcount++;
        }
    }
    return $rep_conf_id;
}

function writeRepConfTable() {
    if ($db = connectDB()) {
        $query = "SELECT id, email, send_to_admin, frequency, date_start, date_end, weekdays, "
        . "send_date_start, send_date_end, send_time, send_weekday, IP, sub_domain, domain, "
        . "topdomain, top, is_active, rep_type, report_name FROM report_config ORDER BY id DESC";
        $res = & $db->query($query);
        if (PEAR::isError($res)){
            echo $res->getMessage();
            return false;
        } else {
            if ($row =& $res->fetchRow()) {
                $rowcounter = 1;
                echo writeRepConfTableHeader();
                $time_intervals = fetchTimeIntervals($row['0'], $db);
                writeRepConfTableRow($row, $rowcounter, $time_intervals, $db);
                $rowcounter++;
                $eoftable .= "</table>\n";
            } else {
                echo "<div align=\"center\" style='color: #FF0000; font-weight: bold;'>No reports!</div>";
            }
            while ($row =& $res->fetchRow()) {
                $time_intervals = fetchTimeIntervals($row['0'], $db);
                writeRepConfTableRow($row, $rowcounter, $time_intervals, $db);
                $rowcounter++;
            }
            echo $eoftable;
        }
    } else {
        $errors = errorMesage("Failed to connect to data base!");
        $errorcount++;
        return false;
    }
}

function writeRepConfTableRow(& $fetchedrow, $rowcounter, $time_int, & $db){
global $frequency, $report_type_short;
static $previousid;
    echo "<tr>\n";
    echo "<td align=\"center\"> {$rowcounter}</td>\n";
    echo "<td align=\"center\" width=\"50\"> {$fetchedrow['18']}</td>\n";
    echo "<td align=\"center\"> {$report_type_short[$fetchedrow['17']]}</td>\n";
    echo "<td align=\"center\"> {$frequency[$fetchedrow['3']]}</td>\n";
    if($fetchedrow['1'] == false) {
        $email = "No recipient";
    } else {
        $email = $fetchedrow['1'];
    }
    $currenttime = strtotime("now");
    $ccadmin = ($fetchedrow['2'] == true) ? "</br> + CC to admin" : "";
    echo "<td align=\"center\">{$email}{$ccadmin}</td>\n";
    if ($fetchedrow['3'] != FQ_ONCE && $fetchedrow['3'] != FQ_WEEKLY) {
        $sendtime .= $fetchedrow['4'] . " - " . $fetchedrow['5'] . "</br>\n";
    }
    switch ($fetchedrow['3']) {
        case FQ_ONCE:
            if ($fetchedrow['4'] == $fetchedrow['5']) {
                $timeconditions .= "{$fetchedrow['4']}</br>\n";
            } else {
                $timeconditions .= "{$fetchedrow['4']} - {$fetchedrow['5']}</br>\n";
            }
            $week = parseWeekDays($fetchedrow['6']);
            if ($week != "") $break = "</br>\n";
            $timeconditions .= $week . $break;
            $sendtime .= $fetchedrow['7'] . " " . $fetchedrow['9'];
            if (strtotime($sendtime) < $currenttime) {
                $noneditable = true;
            } else {
                $noneditable = false;
            }
            break;
        case FQ_DAILY:
            //$sendtime .= $fetchedrow['7'] . " - " . $fetchedrow['8'] . "</br>\n";
            $sendtime .= $fetchedrow['9'] . "</br>\n";
            $weekwhen = parseWeekDays($fetchedrow['6']);
            if ($weekwhen != "") $break = "</br>\n";
            $timeconditions .= $weekwhen . $break;
            break;
        case FQ_WEEKLY:
            $sendtime .= $fetchedrow['7'] . " - " . $fetchedrow['8'] . "</br>\n";
            $week = parseWeekDays($fetchedrow['6']);
            if ($week != "") $break = "</br>\n";
            $timeconditions .= $week . $break;
            $sendtime .= $fetchedrow['9'] . "</br>\n";
            $weekwhen = parseWeekDays($fetchedrow   ['10']);
            $sendtime .= $weekwhen;
            break;
        case FQ_MONTHLY:
            $frommonthday = date("d",strtotime($fetchedrow['4']));
            $tillmonthday = date("d",strtotime($fetchedrow['5']));
            if ($frommonthday == $tillmonthday) {
                $timeconditions .= date("d",strtotime($fetchedrow['5'])) . "</br>\n";
            }elseif ($frommonthday == "01" && $tillmonthday == "31") {
                $timeconditions .= "";
            }else {
                $timeconditions .= $frommonthday . " - " . $tillmonthday . "</br>\n";
            }
            
            $sendtime .= date("d",strtotime($fetchedrow['7'])) . "</br>\n";
            $sendtime .= $fetchedrow['9'];
            $week = parseWeekDays($fetchedrow['6']);
            if ($week != "") $break = "</br>\n";
            $timeconditions .= $week . $break;
            break;
    }
    $time = parseTimeIntervalsForTableRow($time_int);
    $timeconditions .= $time;
    echo "<td align=\"center\">{$timeconditions}</td>\n";
    if ($fetchedrow['11'] == 0) {
        if ($fetchedrow['17'] == 1) {
            $ip = "All users";
        }
    } else {
        $ip = long2ip($fetchedrow['11']);
    }
    $datafilters .= $ip . "</br>\n";
    if ($fetchedrow['12'] == "" && $fetchedrow['13'] == "" && $fetchedrow['14'] == "") {
        $domain = "";
    } elseif ($fetchedrow['12'] == "" || $fetchedrow['13'] == "" || $fetchedrow['14'] == "") {
        if ($fetchedrow['12'] == "") {
            $domain .= "*.";
        } else {
            $domain .= $fetchedrow['12'] . ".";
        }
        if ($fetchedrow['13'] == "") {
            $domain .= "*";
        } else {
            $domain .= $fetchedrow['13'];
        }
        if ($fetchedrow['14'] == "") {
            $domain .= ".*</br>\n";
        } else {
            $domain .= "." . $fetchedrow['14'] . "</br>\n";
        }
    } else {
        $domain .= $fetchedrow['12'] . "." . $fetchedrow['13'] . "." . $fetchedrow['14'] . "</br>\n";
    }
    $datafilters .= $domain;
    if ($fetchedrow['15'] == 0) {
        $datafilters .= "";
    } else {
        $datafilters .= "View top " . $fetchedrow['15'];
    }
    echo "<td align=\"center\">" . $datafilters . "</td>\n";
    echo "<td align=\"center\">" . $sendtime . "</td>\n";
   
    echo "<td align=\"center\">";
    if ($noneditable == false) {
        echo "<a href=\"" . ACTIVE_PAGE . "&amp;edit=" . $fetchedrow['0'] . "\">
            <img src=\"images/icons/edit.png\" border=\"0\" title=\"Edit report\" alt=\"[Edit]\"/></a>";
    } else {
        echo "<img src=\"images/icons/not_editable.png\" border=\"0\" title=\"Not editable\" alt=\"[Not editable]\"/>";
    }
    echo "<a name=\"del" . $fetchedrow['0'] . "\" href=\"". ACTIVE_PAGE . "&amp;delete=" 
            . $fetchedrow['0'] . "#del" . $previousid . "\">
            <img src=\"images/icons/delete.png\" border=\"0\" title=\"Delete report\" alt=\"[Delete]\"/></a>\n
            ";
    if ($fetchedrow['16'] != R_NOT_ACTIVE) {
        $is_active = "<a name=\"light" . $fetchedrow['0'] . "\" href=\"". ACTIVE_PAGE . "&amp;active=" 
        . $fetchedrow['0'] . "#light" . $fetchedrow['0'] . "\">\n
        <img src=\"images/icons/light_bulb.png\" title=\"Report active\" alt=\"[Active]\"";
    } else {
        $is_active = "<a name=\"light" . $fetchedrow['0'] . "\" href=\"". ACTIVE_PAGE . "&amp;inactive=" 
        . $fetchedrow['0'] . "#light" . $fetchedrow['0'] . "\">\n
        <img src=\"images/icons/light_bulb_off.png\" title=\"Report inactive\" alt=\"[Unactive]\"";
    }        
    echo " {$is_active} border=\"0\"/></a>\n";
//    echo "<a href=\"". ACTIVE_PAGE . "&amp;preview=" . $fetchedrow['0'] . "\">
//            <img src=\"images/icons/lightning.png\" title=\"Preview\" border=\"0\" alt=\"[Preview]\"/></a>";
    $reportcount = getGeneratedReportsCount($db, $fetchedrow['0']);
    echo "<a href=\"". ACTIVE_PAGE . "&amp;history=" . $fetchedrow['0'] . "\">
        <img src=\"images/icons/history1.png\" title=\"History : {$reportcount}\" border=\"0\" alt=\"[History]\"/></a>";
    echo "</td>\n</tr>\n";
     $previousid = (int) $fetchedrow['0'];
}

function writeRepConfTableHeader() {
    $header .= "<h3>Created reports:</h3>";
    $header .= "<table class=\"report\" border=\"1\" align=\"center\">\n";
    $header .= "<tr>\n";
    $header .= "<th align=\"center\">#</th>";
    $header .= "<th align=\"center\">Report name</th>";
    $header .= "<th align=\"center\">Type</th>";
    $header .= "<th align=\"center\">Freq.</th>\n";
    $header .= "<th align=\"center\">e-mail</th>\n";
    $header .= "<th align=\"center\">Time conditions</th>\n";
    $header .= "<th align=\"center\">Filters</th>\n";
    $header .= "<th align=\"center\">Send time</th>\n";
    $header .= "<th align=\"center\">Actions</th>\n";
    $header .= "</tr>\n";
    return $header;
}

function reportOn($id) {
    if ($db = connectDB()) {
        $current_time = date("Y-m-d H:i");
        $query = "UPDATE report_config SET is_active='{$current_time}' WHERE id=\"{$id}\"";
        $update = & $db->query($query);
        if (PEAR::isError($update)){
            return false;
        } else {
            unset($_REQUEST);
            $_REQUEST['frequency'] = FQ_ONCE;
            $_REQUEST['noworlater'] = "now";
        }
    } else {$pdf->SetAutoPageBreak(true);
        return false;
    }
}

function reportOff($id) {
    if ($db = connectDB()) {
        $query = "UPDATE report_config SET is_active='" . R_NOT_ACTIVE . "' WHERE id=\"{$id}\"";
        $update = & $db->query($query);
        if (PEAR::isError($update)){
            return false;
        } else {
            unset($_REQUEST);
            $_REQUEST['frequency'] = FQ_ONCE;
            $_REQUEST['noworlater'] = "now";
        }
    } else {
        return false;
    }
}

function deleteReport($id) {
global $errors, $errorcount;
    if($db = connectDB()) {
        $query = "DELETE FROM time_intervals WHERE report_id = '{$id}'";
        $deletetimeintervals = & $db->query($query);
        if (PEAR::isError($deletereport)){
            $errors = errorMesage("Error deleting record!");
            $errorcount++;
            return false;
        } else {
            $query = "DELETE FROM generated_reports WHERE report_id=\"{$id}\"";
            $deletegenrep = & $db->query($query);
            if (PEAR::isError($deletegenrep)){
                $errors = errorMesage("Error deleting record!");
                $errorcount++;
                return false;
            } else {
                $query = "DELETE FROM report_config WHERE id=\"{$id}\"";
                $deletereport =  & $db->query($query);
                if (PEAR::isError($deletereport)){
                    $errors = errorMesage("Error deleting record!");
                    $errorcount++;
                    return false;
                }
            }
        }
    } else {
        $errors = errorMesage("Failed to connect to data base!");
        $errorcount++;
        return false;
    }
}

function editReportConf($id) {
global $CCchecked, $addedtimeintervals, $readonly, $a_disable, $disabled;
    if ($db = connectDB()) {
        if($row = getReportConf($id, $db)) {
            $a_disable = "style=\"display: none;\"";
            $disabled = " disabled=\"disabled\"";
            $readonly = " readonly=\"readonly\"";
            $time_intervals = fetchTimeIntervals($id, $db);
            $_REQUEST['report_name'] = $row['16'];
            $_REQUEST['ip_users'] = $row['0'];
            if ($row['1'] == true) $CCchecked = "checked=\"checked\"";
            $_REQUEST['frequency'] = $row['2'];
            $_REQUEST['report_type'] = $row['15'];
            //print_r($row);
            if ($row['2'] == 0) {
                $readonly = "";
                $a_disable = "";
                $disabled = "";
            }
            unParseWeek($row['5'], "about");
            unParseWeek($row['9'], "when");
            if ($row['2'] == 3) {
                $_REQUEST['monthdays1'] = date("d", strtotime($row['3']));
                $_REQUEST['monthdays2'] = date("d", strtotime($row['4']));
            }
            $addedtimeintervals = drawTimeIntInput($time_intervals, $readonly, $a_disable);
            $_REQUEST['IP'] = long2ip($row['10']);
            $_REQUEST['subdomain'] = $row['11'];
            $_REQUEST['domain'] = $row['12'];
            $_REQUEST['topdomain'] = $row['13'];
            $_REQUEST['top'] = $row['14'];
            $sendtime = date("H:i",strtotime($row['8']));
            $_REQUEST['date1'] = $row['6'];
            $_REQUEST['date2'] = $row['7'];
            switch ($row['2']) {
                case FQ_ONCE:
                    $_REQUEST['date1'] = $row['3'];
                    $_REQUEST['date2'] = $row['4'];
                    $currenttime = strtotime("now");
                    if ($currenttime < strtotime($row['6'] . " " . $row['8'])) {
                        $disabled = "";
                        $_REQUEST['noworlater'] = "later";
                        $_REQUEST['datelater'] = $row['6'];
                    } else {
                        $_REQUEST['noworlater'] = "now";
                        $_REQUEST['datelater'] = date("Y-m-d", $currenttime);
                        $sendtime = date("H:i", $currenttime + 300);
                    }
                    break;
                case FQ_DAILY:
                    
                    break;
                case FQ_WEEKLY:
                    $_REQUEST['weekdayoption'] = $row['9'];
                    break;
                case FQ_MONTHLY:
                    $_REQUEST['monthdayoption'] = date("d", strtotime($row['6']));
                    $_REQUEST['date1'] = date("Y-m", strtotime($row['3']));
                    $_REQUEST['date2'] = date("Y-m", strtotime($row['4']));
                    break;
            }
            $_REQUEST['clocktime2input'] = $sendtime;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function getReportConf($id, &$db) {
    if ($db == false) {
        $db = connectDB();
        if (!$db) {
            return false;
        }
    }
    $query = "SELECT email, send_to_admin, frequency, date_start, date_end, weekdays, "
        . "send_date_start, send_date_end, send_time, send_weekday, IP, sub_domain, domain, "
        . "topdomain, top, rep_type, report_name FROM report_config WHERE id='{$id}'";
    $res = & $db->query($query);
    if (PEAR::isError($res)){
        return false;
    } else {
        if ($row =& $res->fetchRow()) {
            return $row;
        }
    }
    return false;
}

function unParseWeek($w, $postfix) {
global $weekdays;
    foreach ($weekdays as $key=>$value) {
        if ($w & $key) {
            $_REQUEST["day{$postfix}{$key}"] = "on";        
        } else {
            unset($_REQUEST["day{$postfix}{$key}"]);
        }
    }
}

function drawTimeIntInput(& $time_intervals, $readonly = "", $a_disable = "") {
global $counter_for_javascript;
    foreach($time_intervals as $key=>$value) {
        $counter = $key +1;
        $_REQUEST["clocktimestart" . $counter] = date("H:i", strtotime($value['start']));
        $_REQUEST["clocktimeend" . $counter] = date("H:i", strtotime($value['end']));
        if ($counter > 1) {
            $time_input .= "<span id=\"addedtime{$counter}\" ><input size=\"7\" type=\"text\""
                            . "id=\"clocktimestart" . $counter . "\" \n value=\"". $_REQUEST["clocktimestart{$counter}"] . "\""
                            . "name=\"clocktimestart" . $counter . "\" {$readonly}/> - <input size=\"7\" type=\"text\" \n" 
                            . "id=\"clocktimeend" . $counter . "\" value=\"" . $_REQUEST["clocktimeend{$counter}"] 
                            . "\" name=\"clocktimeend" . $counter . "\" {$readonly}/>\n" 
                            . "<a {$a_disable} onclick=\"removeTimeInterval('addedtime','{$counter}')\">\n" 
                            . "<img src=\"images/icons/clock__minus.png\" title=\"Remove time interval\"" 
                            . "alt=\"[-]\"/></a></br>\n</span>";
        }
        $counter_for_javascript = "<script type=\"text/javascript\"> var counter={$counter}; </script>";
    }
    
    return $time_input;
}

function alterReportConf($id, $validrequest) {
global $errors, $errorcount;
    //print_r($validrequest);
    if($validrequest != false) {
        if ($db = connectDB()) {
            switch($validrequest['current_frequency']) {
                case FQ_ONCE:
                    $validrequest['date1when'] = $validrequest['datelater'];
                    $validrequest['date2when'] = "";
                    $validrequest['weekwhen'] = 127;
                    break;
                case FQ_DAILY:
                    $validrequest['date1when'] = $validrequest['date1'];
                    $validrequest['date2when'] = $validrequest['date2'];
                    break;
                case FQ_WEEKLY:
                    $validrequest['date1when'] = $validrequest['date1'];
                    $validrequest['date2when'] = $validrequest['date2'];
                    getCurrentWeekBounds($validrequest['date1'], $validrequest['date2']);
                    $validrequest['weekwhen'] = $validrequest['weekdaywhen'];
                    break;
                case FQ_MONTHLY:
                    $date1 = strtotime($validrequest['date1']);
                    $Y_of_date1 = date("Y", $date1);
                    $m_of_date1 = date("m", $date1);
                    $validrequest['date1'] = date("Y-m-", $date1) . $validrequest['monthdays1'];
                    $date2 = strtotime($validrequest['date2']);
                    $validrequest['date2'] = date("Y-m-", $date2) . $validrequest['monthdays2'];
                    $validrequest['date1when'] = "1970-01-" . $validrequest['monthdaywhen'];
                    $validrequest['weekwhen'] = 127;
                    break;
            }
            $query = "UPDATE report_config SET report_name='{$validrequest['report_name']}', "
                . " email='{$validrequest['email']}', send_to_admin='{$validrequest['sendtoadmin']}',"
                . " date_start='{$validrequest['date1']}', date_end='{$validrequest['date2']}',"
                . " weekdays='{$validrequest['week']}', send_date_start='{$validrequest['date1when']}', "
                . "send_date_end='{$validrequest['date2when']}', send_time='{$validrequest['timewhen']}', "
                . " send_weekday='{$validrequest['weekwhen']}' WHERE id='{$id}'";
//            echo "</br> QUERY : " . $query;
            $insertdata = & $db->query($query);
            if (PEAR::isError($insertdata)) {
                $errors = errorMesage("Failed to insert data! - " . $insertdata->getMessage());
                $errorcount++;
                return false;
            } else {
                $query = "DELETE FROM time_intervals WHERE report_id='{$id}'";
                $delete = & $db->query($query);
                if (PEAR::isError($delete)){
                    $errors = errorMesage("Failed to delete time intervals!");
                    $errorcount++;
                    return false;
                } else {
                    foreach ($validrequest['time_array'] as $value) {
                        $query = "INSERT INTO time_intervals(report_id, time_start, time_end) "
                        . " VALUES('{$id}', '{$value['start']}', "
                        . " '{$value['end']}')";
                        //echo "</br> QUERY : " . $query;
                        $inserttime = &$db->query($query);
                        if (PEAR::isError($insertdata)) {
                            $errors = errorMesage("Failed to insert data!");
                            $errorcount++;
                            return false;
                        } else {
                            //unset($_REQUEST);
                        }
                    }
                }
            }
        } else {
            $errors .= errorMesage("Failed to connect to data base!");
            $errorcount++;
        }
    } 
}

function writeReportResult($reportid) {
global $errors, $errorcount, $reptable;
global $weekdays, $weekNums, $config_const;
    if($db = connectDB()) {
        $query = "SELECT frequency, rep_type, date_start, date_end, weekdays, "
        . "IP, sub_domain, domain, topdomain, top FROM report_config WHERE id='{$reportid}'";
        $res = & $db->query($query);
        if (PEAR::isError($res)){
            return false;
        } else {
            if ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
                $time_intervals = fetchTimeIntervals($reportid, $db);
                $wherequery = "";
                $current_time = strtotime("now");
                    switch ($row['frequency']) {
                        case FQ_ONCE:
                            $start_date = $row['date_start'];
                            $datestartquery = "webproxylog.event_date>='{$start_date}' ";
                            addWhereCondition($wherequery, $datestartquery);
                            $end_date = $row['date_end'];
                            $dateendquery = "webproxylog.event_date<='{$end_date}' ";
                            addWhereCondition($wherequery, $dateendquery);
                            break;
                        case FQ_DAILY:
                            $previousdate = date("Y-m-d", $current_time - SECONDS_IN_DAY);
                            $start_date = $previousdate;
                            $end_date = $previousdate;
                            $datequery = "webproxylog.event_date = '{$previousdate}' ";
                            addWhereCondition($wherequery, $datequery);
                            break;
                        case FQ_WEEKLY:
                            $weekdaynum = (int) date("N", strtotime("now"));
                            $end_date = date("Y-m-d", $current_time - ($weekdaynum * SECONDS_IN_DAY)); //last Sunday date
                            $start_date = date("Y-m-d", $current_time - ($weekdaynum * SECONDS_IN_DAY) - 518400); //last Monday date
                            $datestartquery = "webproxylog.event_date>='{$start_date}' ";
                            addWhereCondition($wherequery, $datestartquery);
                            $dateendquery = "webproxylog.event_date<='{$end_date}' ";
                            addWhereCondition($wherequery, $dateendquery);
                            break;
                        case FQ_MONTHLY:
                            $curr_monthnum = (int) date("m", $current_time);
                            $curr_daynum = (int) date("d", $current_time);
                            $end_daynum = (int) date("d", strtotime($row['date_end']));
                            $start_daynum = (int) date("d", strtotime($row['date_start']));
                            if ($curr_daynum < $end_daynum) {
                                $m = $curr_monthnum -1;
                            } else {
                                $m = $curr_monthnum;
                            }
                            $Y = (int) date("Y", $current_time);
                            $end_daynum = checkMonthEnd($Y, $m, $end_daynum);
                            $end_date = "{$Y}-{$m}-{$end_daynum}";
                            $end_date = date("Y-m-d", strtotime($end_date)); // good format;
                            $start_date = "{$Y}-{$m}-{$start_daynum}";
                            $start_date = date("Y-m-d", strtotime($start_date)); // good format;
                            $datestartquery = "webproxylog.event_date>='{$start_date}' ";
                            addWhereCondition($wherequery, $datestartquery);
                            $dateendquery = "webproxylog.event_date<='{$end_date}' ";
                            addWhereCondition($wherequery, $dateendquery);
                            break;
                }
                echo writeDataFilters($row, $start_date, $end_date, $time_intervals);
                foreach ($time_intervals as $key=>$value) {
                    $end = strtotime($value['end']);
                    $start = strtotime($value['start']);
                    $seconds += strtotime($value['end']) - strtotime($value['start']);
                }
                if ($seconds != 86340) {
                    $counter = 1;
                    $or = "";
                    $timequery .= "(";
                    foreach ($time_intervals as $key=>$value) {
                        if ($counter > 1) $or = " or ";
                        $timequery .= "{$or}webproxylog.event_time>='{$value['start']}'
                                 and webproxylog.event_time<='{$value['end']}' ";
//                        $timestartquery = "webproxylog.event_time>='{$value['start']}' ";
//                        addWhereCondition($wherequery, $timestartquery);
//                        $timeendquery = "webproxylog.event_time<='{$value['end']}'";
//                        addWhereCondition($wherequery, $timeendquery);
                        $counter++;
                    }
                    $timequery .= ")";
                    addWhereCondition($wherequery, $timequery);
                }
                if ($row['weekdays'] != 0 && $row['weekdays'] != 127) {
                    $count = 1;
                    $or = "";
                    $weekdayquery .= "(";
                    foreach ($weekNums as $key=>$value) {
                        if ($row['weekdays'] & $key) {
                            if ($count > 1) $or = " or ";
                            $weekdayquery .= "{$or} DAYOFWEEK(webproxylog.event_date)='{$value}' ";
                            $count++;
                        }
                    }
                    $weekdayquery .= ")";
                    addWhereCondition($wherequery, $weekdayquery);
                }
                
                if ($row['sub_domain'] != "") {
                    $subdomainquery = "domain.subdomain='{$row['sub_domain']}' ";
                    addWhereCondition($wherequery, $subdomainquery);
                }
                if ($row['domain'] != "") {
                    $domainquery = "domain.domain='{$row['domain']}' ";
                    addWhereCondition($wherequery, $domainquery);
                }
                if ($row['topdomain'] != "") {
                    $topdomainquery = "domain.topdomain='{$row['topdomain']}' ";
                    addWhereCondition($wherequery, $topdomainquery);
                }
                if ($row['top'] != 0) $rec_limit_query = "LIMIT {$row['top']}";
                $reptype = $row['rep_type'];
                if ($row['ip'] == 0 && $row['rep_type'] == 1) {
                    $query = "SELECT IP, count(distinct(TIMESTAMP(event_date, event_time))) as time, 
                            count(webproxylog.id) as hitcount FROM {$config_const['DB_NAME']}.webproxylog
                            JOIN {$config_const['DB_NAME']}.domain ON ( webproxylog.domain_id = domain.ID )
                            {$wherequery} GROUP BY IP ORDER BY count(DISTINCT(event_time)) DESC {$rec_limit_query}";
                            $header1 = "IP";
                            $isdomains = true;
                } elseif($row['rep_type'] == 1) {
                    $ipquery = "IP='{$row['ip']}'";
                    addWhereCondition($wherequery, $ipquery);
                    $query = "SELECT domain.subdomain as subdomain, domain.domain as domain, domain.topdomain as topdomain,
                                count(distinct(TIMESTAMP(event_date, event_time))) as time, count(webproxylog.id) as hitcount 
                                FROM {$config_const['DB_NAME']}.webproxylog 
                                JOIN {$config_const['DB_NAME']}.domain ON ( webproxylog.domain_id = domain.ID ) 
                                {$wherequery} GROUP BY webproxylog.domain_id 
                                ORDER BY count(DISTINCT(event_time)) desc {$rec_limit_query}";
                    $header1 = "Domain";
                    $isdomains = false;
                } elseif($row['rep_type'] == 2) {
                    $query = "SELECT domain.subdomain as subdomain, domain.domain as domain, domain.topdomain as topdomain,
                                count(distinct(webproxylog.IP)) as ipcount,
                                count(distinct(TIMESTAMP(event_date, event_time))) as time, count(webproxylog.id) as hitcount 
                                FROM {$config_const['DB_NAME']}.webproxylog 
                                JOIN {$config_const['DB_NAME']}.domain ON ( webproxylog.domain_id = domain.ID ) 
                                {$wherequery} GROUP BY webproxylog.domain_id 
                                ORDER BY count(DISTINCT(event_time)) desc {$rec_limit_query}";
                    $header1 = "Domain";
                    $isdomains = false;
                } 
                //echo $query;
                $query2 = "SELECT count(distinct(TIMESTAMP(event_date, event_time))), COUNT(webproxylog.id) 
                            FROM {$config_const['DB_NAME']}.webproxylog 
                            JOIN {$config_const['DB_NAME']}.domain 
                            ON ( webproxylog.domain_id = domain.ID ) {$wherequery}
                            ORDER BY count(DISTINCT(event_time)) desc {$rec_limit_query}";
                //echo $query2;
                $res =& $db->query($query);
                if (PEAR::isError($res)) {
                    $errors = errorMesage($res->getMessage() . "!");
                } else {
                    if ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
                        $reptable .= writeTableHeader($header1, "Time", $reptype);
                        $reptable .= writeTableRow($row, $isdomains, true, false, $reptype);
                        $eoftable .= "</table>\n";
                    } else {
                        echo "<div align=\"center\" style='color: #FF0000; font-weight: bold;'>No records found!</div>";
                    }
                    while ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
                        $fulldomain = "";
                        $reptable .= writeTableRow($row, $isdomains, true, false, $reptype);
                    }
                    $res2 =& $db->query($query2);
                    if (PEAR::isError($res2)) {
                        return $res2->getMessage();
                    } else {
                        if ($row =& $res2->fetchRow()) { 
                            $totaltime = $row['0'];
                            if ($totaltime != 0) {
                                if ($reptype == 2) $reptable .= "<td></td>\n";
                                $reptable .= "<td align=\"center\"> Total time</td>\n";
                                $reptable .= "<td align=\"center\">" . formatTime($totaltime) ."</td>\n";
                                $reptable .= "<td align=\"center\">{$row['1']}</td>\n";
                            } 
                        }
                    }
                    $reptable .= $eoftable;
                }
            } 
        }
        return $reptable;
    } else {
        $errors = errorMesage("Failed to connect to data base!");
        $errorcount;
        return false;
    }
}

function writeGeneratedReportsTable($id) {
    global $errors;
    if($db = connectDB()) {
        $generatedreports = "";
        $query = "SELECT id, datestart, dateend, date_time, execute_time FROM generated_reports WHERE report_id='{$id}' ORDER BY date_time DESC";
        $res =& $db->query($query);
        if (PEAR::isError($res)) {
            $errors = errorMesage($res->getMessage() . "!");
        } else {
            if ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
                $rowcount = 1;
                echo writeRepHistoryTHeader();
                echo writeRepHistoryTRow($db, $row, $rowcount);
                $eoftable = "</table>";
                $rowcount++;
            } else {
                echo notGeneratedCheckStatus($id);
            }
            while ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
                echo writeRepHistoryTRow($db, $row, $rowcount);
                $rowcount++;
            }
            echo $eoftable;
        }
    }
}

function writeRepHistoryTHeader() {
    $header .= "<table class=\"report\" border=\"1\" border align=\"center\">\n";
    $header .= "<tr>\n";
    $header .= "<th align=\"center\">#</th>";
    $header .=  "<th align=\"center\">Dates</th>\n";
    $header .= "<th align=\"center\">Generate time</th>\n";
    $header .= "<th align=\"center\">Execute time</th>\n";
    $header .= "<th align=\"center\">Actions</th>\n";
    $header .= "</tr>\n";
    return $header;
}

function writeRepHistoryTRow(& $db, $row, $rowcount) {
    $table .= "<tr>\n";
    $table .= "<td align=\"center\"> ". $rowcount . "</td>\n";
    if ($row['datestart'] == $row['dateend']) {
        $dates = $row['datestart'];
    } else {
        $dates = $row['datestart'] . " - " . $row['dateend'];
    }
    $table .= "<td align=\"center\">" . $dates . "</td>\n";
    $table .= "<td align=\"center\">" . $row['date_time'] . "</td>\n";
    if ($row['execute_time'] == 0) {
        $time = "In progress!";
        $view_hist_link = "";
    } else {
        $time = formatTime($row['execute_time'], true);
        $view_hist_link .= "<a name=\"histinact" . $row['id'] . "\""; 
        $view_hist_link .=  "href=\"" . ACTIVE_PAGE . "&amp;history=" . $_REQUEST['history']; 
        $view_hist_link .= "&amp;viewhist=" . $row['id'] . "#histact" . $row['id'] . "\">\n";
        $view_hist_link .= "<img src=\"images/icons/binocular.png\" border=\"0\" title=\"View\" alt=\"[View]\"/></a>\n";
    }
    $table .= "<td align=\"center\">" . $time . "</td>\n";
    if (isset($_REQUEST['history']) && isset($_REQUEST['viewhist']) && $_REQUEST['viewhist'] == $row['id']) {
        $id = (int)$_REQUEST['viewhist'];
        $history = getCurrentHistory($db, $id);
        $report .= "<tr>\n";
        $report .= "<td align=\"center\" colspan=\"5\">" . $history . "</td>";
        $report .= "</tr>";
        $table .= "<td align=\"center\"><a name=\"histact" . $row['id'] . "\""; 
        $table .= "href=\"" . ACTIVE_PAGE . "&amp;history=" . $_REQUEST['history'] . "#histinact" . $row['id'] . "\">\n";
        $table .= "<img src=\"images/icons/binocular_fliped.png\" border=\"0\" title=\"Hide\" alt=\"[Hide]\"/></a>\n";
    } else {
        $table .= "<td align=\"center\">" . $view_hist_link;
    }
    $table .= "</td>\n";
    $table .= "</tr>\n";
    $table .= $report;
    
    return $table;
}

function getCurrentHistory($db, $id) {
    $query = "SELECT msg FROM generated_reports WHERE id='{$id}'";
    $res =& $db->query($query);
    if (PEAR::isError($res)) {
        $errors = errorMesage($res->getMessage() . "!");
    } else {
        if ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
            return unserializeReport($row['msg']);
        }
    }
}

function unserializeReport($s_report) {
    $report = unserialize($s_report);
    if (isset($report['no_rec'])) {
        return $report['no_rec'];
    }
    $datafilters = $report['data_filters'];
    $t_header = $report['header'];
    $t_body = $report['data'];
    unset($report);
    $align_c = "align=\"center\"";
    $table .= "";
    if ($datafilters['head'] != '') {
    	$table .= "<div {$align_c} style=\"font-size: 1.5em;\">\n";
    	$table .= $datafilters['head'];
    	$table .= "</div>\n";
    }
    if ($datafilters['name'] != '') {
        $table .= "<div {$align_c}>" . $datafilters['name'] . "</div>\n";
    }
    if ($datafilters['date'] != '') {
        $table .= "<div {$align_c}>" . $datafilters['date'] . "</div>\n";
    }
    if ($datafilters['time_intervals'] != '') {
        $table .= "<div {$align_c}>" . $datafilters['time_intervals'] . "</div>\n";
    }
    if ($datafilters['IP'] != '') {
        $table .= "<div {$align_c}>" . $datafilters['IP'];
        if ($datafilters['ipname'] != '') {
            $table .=  $datafilters['ipname'];
        } 
        $table .= "</div>\n";
    }
    if ($datafilters['domain'] != '') {
        $table .= "<div {$align_c}>" . $datafilters['date'] . "</div>\n";
    }
    $table .= "<table class=\"report\" {$align_c} border=\"1\">\n";
    $table .= "<tr>\n";
    foreach ($t_header as $header) {
        $table .= "<th {$align_c}>" . $header . "</th>";
    }
    $table .= "</tr>\n";
    foreach ($t_body as $row) {
        $table .= "<tr>\n";
    	foreach ($row as $cell) {
    		$table .= "<td {$align_c}>" . $cell . "</td>\n";
    	}
    	$table .= "</tr>\n";
    }
    
    $table.= "</table>";
    return $table;
}

function notGeneratedCheckStatus($id) {
    $db = false;
    $report = getReportConf($id, $db);
    $body .= "<div align=\"center\">Report not generated yet, click \"Check Status\" after few moments. "
        . " Report will strart to generate at {$report['3']} {$report['8']} </div>\n";
    $body .= "<div align=\"center\">" . 
        "<input class=\"refreshbutton\" type=\"button\"" . 
        " name=\"check_status\" value=\"Check Status\"" .
        " style='width: 100px' onclick=\"document.location='". ACTIVE_PAGE ."&history={$id}'\"/>" .
        "</div>";
    return $body;
}

?>