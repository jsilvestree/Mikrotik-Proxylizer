<?php
/****************************************************************************
*                                                                           *
*    MikroTik Proxylizer, Web-proxy log analyzer                            *
*    Copyright (C) 2009  MikroTik                                           *
*                                                                           *
*    This program is free software: you can redistribute it and/or modify   *
*    it under the terms of the GNU General Public License as published by   *
*    the Free Software Foundation, either version 3 of the License, or      *
*    (at your option) any later version.                                    *
*                                                                           *
*    This program is distributed in the hope that it will be useful,        *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of         *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
*    GNU General Public License for more details.                           *
*                                                                           *
*    You should have received a copy of the GNU General Public License      *
*    along with this program.  If not, see <http://www.gnu.org/licenses/>.  *
*                                                                           *
****************************************************************************/
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/index.php");
    return false;
}

require_once("inputfunc.php");
require_once("constants.php");

function checkDSN() {
    global $dbhost, $dbname, $dbtype, $dbusername, $paswrd;
    if (ereg("@|:|/", $_REQUEST['dbtype'])) {
        return "Sorry, can't use @, : or / in DB type";
    } else {
        $dbtype = $_REQUEST['dbtype'];
    }
    if (ereg(":|/", $_REQUEST['dbhost'])) {
        return "Sorry, can't use : or / in DB host";
    } else {
        $dbhost = $_REQUEST['dbhost'];
    }
    if (ereg(":|/", $_REQUEST['dbname'])) {
        return "Sorry, can't use / in DB name";
    } else {
        $dbname = $_REQUEST['dbname'];
    }
    if (ereg("@|:|/", $_REQUEST['dbusername'])) {
        return "Sorry, can't use @, : or / in DB username";
    } else {
        $dbusername = $_REQUEST['dbusername'];
    }
    if (ereg("@|:|/", $_REQUEST['paswrd'])) {
        return "Sorry, can't use @, : or / in DB password";
    } else {
        $paswrd = $_REQUEST['paswrd'];
    }
    return "";
}

function createDsnString($dbtype, $uname, $pwd, $host, $dbname) {
	$p = $pwd == "" ? "" : ":{$pwd}";
	$dbn = $dbname == "" ? "" : "/{$dbname}";
    return "{$dbtype}://{$uname}{$p}@{$host}{$dbn}";
}

function formatTime($t, $showseconds = false, $short = false) {
    if ($showseconds == false) {
        $time_unit1 = "hour";
        $time_unit2 = "minute";
    } else {
        $time_unit1 = "minute";
        $time_unit2 = "second";
    }
    if ($t>=60) {
        $T1 = (int)($t/60);
        $T2 = $t % 60;
        if ($short == true) {
            $T1 = ($T1 < 0 || $T1 > 9) ? $T1 : "0{$T1}";
            $T2 = ($T2 < 0 || $T2 > 9) ? $T2 : "0{$T2}";
            return $T1 . ":" . $T2;
        }
        if ($T1 !=1) {
            $t1 = "s";
        } else {
            $t1 = "";
        }
        if ($T2 != 1) {
            $t2 = "s";
        } else {
            $t2 = "";
        } 
        if ($T2 != 0) {
            return "{$T1} {$time_unit1}{$t1} and {$T2} {$time_unit2}{$t2}";
        } else {
            return "{$T1} {$time_unit1}{$t1}";
        }
    } elseif ($t == 1) {
        if ($short == true) {
            return "00:0" . $t;
        } else {
            return $t . " " . $time_unit2;
        }
    } else {
        if ($short == true) {
            $t = ($t < 0 || $t > 9) ? $t : "0{$t}";
            return "00:" . $t;
        } else {
            return $t . " " . $time_unit2 . "s";
        }
    }
}

function addDays($timeVal, $dayCount) {
    return strtotime("+{$dayCount} days", $timeVal);
}

function requestToValidDate($date) {
global $errors, $errorcount;
    $date = strtotime($date);
    if ($date == false) {
        $errors .= errorMesage("Invalid date format!");
        $errorcount++;
        return;
    } else {
        $date = date("Y-m-d", $date);
        return $date;
    }
}

function addWhereCondition (& $query, $addquery) {
    if ($query === "") {
         $query = "WHERE " . $addquery;
    } else {
        $query .= " and " . $addquery;
    }
}

function writeTableHeader ($kol1, $kol2, $rep_type) {
    $header .= "<table class=\"report\" border=\"1\" align=\"center\">\n";
    $header .= "<tr>";
    $header .= "<th align=\"center\">\n{$kol1}</th>";
    if ($rep_type == 2) $header .= "<th align=\"center\">IP count</th>\n";
    $header .= "<th align=\"center\">{$kol2}</th>\n";
    $header .= "<th align=\"center\">Hitcount</th>\n";
    $header .= "</tr>";
    return $header;
}

function writeTableRow(& $fetchedrow, $showIP=true, $isemailrep=false, $ispdfreport=false, $reptype) {
    if ($showIP == true) {
        if(getIpUserName($fetchedrow['ip'])) {
            $ipname = getIpUserName($fetchedrow['ip']);
            $ipstring = long2ip($fetchedrow['ip']);
        } else {
            $ipname = long2ip($fetchedrow['ip']);
            $ipstring = long2ip($fetchedrow['ip']);
        }
        if ($isemailrep == false) {
            $cellcont = "<a onclick=\"setSelectFieldValue('ip_selector','{$ipstring}','report3form')\">{$ipname}</a>"; 
        } else {
            $cellcont = $ipstring;
        }
        $tbody .= "<tr>\n";
        $tbody .= "<td align=\"center\">{$cellcont}</td>\n";
        $tbody .= "<td align=\"center\">" . formatTime($fetchedrow['time'], false, true) . "</td>\n";
        $tbody .= "<td align=\"center\">" . $fetchedrow['hitcount'] . "</td>\n";
        $tbody .= "</tr>\n";
        if ($ispdfreport == true) {
            $data=array($cellcont, formatTime($fetchedrow['time'], false, true), $fetchedrow['hitcount']);
        }
    } else {
        $fulldomain = "";
        $tbody .= "<tr>\n";
        if ($fetchedrow['subdomain'] != "") $fulldomain .= $fetchedrow['subdomain'] . ".";
        if ($fetchedrow['domain'] != "") $fulldomain .= $fetchedrow['domain'];
        if ($fetchedrow['topdomain'] != "") $fulldomain .= "." . $fetchedrow['topdomain'];
        $tbody .= "<td align=\"center\">" . $fulldomain . " </td>\n";
        if ($reptype == 2) {
            $tbody .= "<td align=\"center\">" . $fetchedrow['ipcount'] . " </td>\n";
        }
        $tbody .= "<td align=\"center\">" . formatTime($fetchedrow['time'], false, true) . "</td>\n";
        $tbody .= "<td align=\"center\">" . $fetchedrow['hitcount'] . "</td>\n";
        $tbody .= "</tr>\n";
        if ($ispdfreport == true) {
            $data = array($fulldomain, formatTime($fetchedrow['time'], false, true), $fetchedrow['hitcount']);
            if($reptype == 2) {
                array_splice($data, 1, 0, $fetchedrow['ipcount']);
            }
        }
    }
    if ($ispdfreport == false) {
        return $tbody;
    } else {
        return $data;
    }
}

function ipSelector ($showall = false, $disabled = "") {
    global $dsn, $options;
    $db = & DB::connect($dsn, $options);
    if (PEAR::isError($db)) {
        return $db->getMessage();
    } else {
        $ipoption = array (0 => "Show All");
        $ipoptionquery = "SELECT DISTINCT(IP) FROM webproxylog";
        $res =& $db->query($ipoptionquery);
        if (PEAR::isError($res)) {
            return $res->getMessage();
        } else {
            if ($row =& $res->fetchRow()) {
                if (getIpUserName($row['0'])) {
                    $name = getIpUserName($row['0']);
                    $ipoption[long2ip($row['0'])] = $name . " - " . long2ip($row['0']);
                } else {
                    $ipoption[long2ip($row['0'])] = long2ip($row['0']);
                }
            } else {
                echo "<div style='color: #FF0000; font-weight: bold;'>No IP adreses to select</div>";
            }
            while ($row =& $res->fetchRow()) {
                if (getIpUserName($row['0'])) {
                    $name = getIpUserName($row['0']);
                    $ipoption[long2ip($row['0'])] = $name . " - " . long2ip($row['0']);
                } else {
                    $ipoption[long2ip($row['0'])] = long2ip($row['0']);
                }
            }
        }
    }
    $db->disconnect();
    echo "<select style=\"width: 150px;\" id=\"ip_selector\" name=\"IP\">\n ";
    if ($showall == false) {
        echo "<option ";
        if ($_REQUEST['IP'] != array_search($ipoption['0'], $ipoption)) {
            echo $disabled ;
        }
        echo " value=\"" . array_search($ipoption['0'], $ipoption) . "\"> {$ipoption['0']}</option>\n";
    }
    foreach ($ipoption as $key=>$value){
        if ($key != 0) {
            echo "<option value=\"{$key}\"";
            if ($_REQUEST['IP'] == $key) {
                echo " selected = \"selected\"";
            } else {
                echo $disabled;
            }
            echo "> {$value}</option>\n";
        } 
    }   
    echo "</select>";
}

function ipUsersSelector() {
global $no_emails;
    if ($db = connectDB()) {
        $ip_users = array();
        $query = "SELECT name, email FROM ip_users";
        $res =& $db->query($query);
        if (PEAR::isError($res)) {
            return false;
        } else { 
            if ($row =& $res->fetchRow()) {
                $ip_users[$row['1']] = $row['0'];
            } else {
                $no_emails = errorMesage("Please go to IP users section and add users");
            }
            while ($row =& $res->fetchRow()) {
                $ip_users[$row['1']] = $row['0'];
            }
        }
    } else {
        errorMesage("Failed to connect to data base");
    }
    $db->disconnect();
    echo "<select  style=\"width: 170px;\" id=\"ip_user_selector\" name=\"ip_users\">\n ";
    echo "<option value=\"0\">Don't send</option>\n";
    foreach($ip_users as $key => $value) {
        echo "<option value=\"{$key}\"";
        if ($_REQUEST['ip_users'] == $key) {
            echo " selected = \"selected\"";
        }
        echo "> {$value} - {$key}</option>\n";
    }
    echo "</select>";
}

function connectDB() {
global $db, $config_const;
    if(@include('config_constants.php')){
        require_once 'DB.php';
        $DBpaswrd = $config_const['DB_PASSWORD'];
        if ($DBpaswrd != "") $DBpaswrd = ":" . $DBpaswrd;
        $dsn = "{$config_const['DB_TYPE']}://{$config_const['DB_USERNAME']}{$DBpaswrd}@{$config_const['DB_HOST']}/{$config_const['DB_NAME']}";
        $options = array(
            'debug'       => 2,
            'portability' => DB_PORTABILITY_ALL,
            );
        $db = & DB::connect($dsn, $options);
        if (PEAR::isError($db)) {
            echo $db->getMessage();
            return false;
        } else {
            return $db;
        }
    } else {
        return false;
    }
}

function errorMesage($msg) {
    return "<div style='color : #FF0000'>{$msg}</div>\n";
}

function getIpUserName($ip) {
    if($db = connectDB()) {
        $query = "SELECT name FROM ip_users WHERE ip='{$ip}'";
        $res =& $db->query($query);
        if (PEAR::isError($res)) {
            return false;
        } else {
            if ($row =& $res->fetchRow()) {
               $ipusername = $row['0']; 
            }
        }
        return $ipusername;
    } else {
        return false;
    }
}

function fetchTimeIntervals($id, & $db) {
global $errors, $errorcount;
    $query = "SELECT time_start, time_end FROM time_intervals WHERE report_id = '{$id}'";
    $timequery = $query;
    $res = & $db->query($query);
    $time_array = array();
    if (PEAR::isError($res)){
        return false;
    } else {
        if ($row =& $res->fetchRow()) {
            $timeintervals['start'] = $row['0'];
            $timeintervals['end'] = $row['1'];
            array_push($time_array, $timeintervals);
        } else {
            $errors = errorMesage("Invalid data in time intervals table!");
            $errorcount++;
            return false;
        }
        while ($row =& $res->fetchRow()) {
            $timeintervals['start'] = $row['0'];
            $timeintervals['end'] = $row['1'];
            array_push($time_array, $timeintervals);
        }
    }
    return $time_array;
}

function checkMonthEnd($y, $m, $d) {
global $monthdaycount;
    if ($d > 28) {
        if ($m == 2) {
            if ((($y % 4 == 0) && ($y % 100 != 0)) || ($y % 400 == 0)) {
                $d = 29;
            } else {
                $d = 28;
            }
        } elseif ($d > $monthdaycount[$m]) {
            $d = $monthdaycount[$m];
        }
    }
    return $d;
}

function send_mail($toName, $toAdd, $fromName, $fromAdd, $subject, $body, $emailType, $attachmentData, $attachmentName, $attachmentType) {
    //http://www.webmasterworld.com/php/3562901.htm
    $eol = "\r\n"; //End of line characters
    $mime_boundary = md5(time());
    // Common Headers
    $headers = "To: " .$toName."<".$toAdd.">".$eol;
    $headers .= "From: ".$fromName."<".$fromAdd.">".$eol;
    //$headers .= "Reply-To: ".$fromName."<".$fromAdd.">".$eol;
    $headers .= "Return-Path: ".$fromName."<".$fromAdd.">".$eol;
    $headers .= "Message-ID: <".time()."-".$fromAdd.">".$eol;
    $headers .= "X-mailer: php v".phpversion().$eol;
    $headers .= "X-Priority: 1".$eol;
    $headers .= "X-MSmail-Priority: High".$eol;
    // Boundry for marking the split & Multitype Headers
    $headers .= 'MIME-Version: 1.0'.$eol;
    $headers .= "Content-Type: multipart/mixed; boundary=\"".$mime_boundary."\"".$eol.$eol;

    // Open the first part of the mail
    $msg = "--".$mime_boundary.$eol;

    $htmlalt_mime_boundary = $mime_boundary."_htmlalt";

    // Setup for text OR html -
    $msg .= "Content-Type: multipart/alternative; boundary=\"".$htmlalt_mime_boundary."\"".$eol.$eol;

    if($emailType == 'Text') {
    // Text Version
        $msg .= "--".$htmlalt_mime_boundary.$eol;
        $msg .= "Content-Type: text/plain; charset=iso-8859-1".$eol;
        $msg .= "Content-Transfer-Encoding: 8bit".$eol.$eol;
        $msg .= $body . $eol . $eol;
    } else {
    // HTML Version
        $msg .= "--".$htmlalt_mime_boundary.$eol;
        $msg .= "Content-Type: text/html; charset=iso-8859-1".$eol;
        $msg .= "Content-Transfer-Encoding: 8bit".$eol.$eol;
        $msg .= $body . $eol . $eol;
    }
    //close the html/plain text alternate portion
    $msg .= "--".$htmlalt_mime_boundary."--".$eol.$eol;
    if ($attachmentData) {
        $data=chunk_split(base64_encode($attachmentData));
        // attachment
        $msg .= "--".$mime_boundary.$eol;
        $msg .= "Content-Type: ".$attachmentType."; name=\"".$attachmentName."\"".$eol;
        $msg .= "Content-Transfer-Encoding: base64" . $eol;
        $msg .= "Content-Description: " . $attachmentName . $eol;
        $msg .= "Content-Disposition: attachment; filename=\"".$attachmentName."\"".$eol.$eol;
        $msg .= $data.$eol.$eol;
    }
    // Finished
    $msg .= "--".$mime_boundary."--".$eol.$eol;
    // SEND THE Email
    ini_set('sendmail_from',$fromAdd);
    $mail_sent = mail($toAdd, $subject, $msg, $headers);
    ini_restore('sendmail_from');
    return $mail_sent;
}

function send_mail_smtp($from, $to, $subject, $text, $attachment, $attachmentType, $attachmentName, $smtpHost, $smtpUserName, $smtpPassword, $bcc = array(), & $resultMessage = '') {
    require_once('Mail.php');
    require_once('Mail/mime.php');
    if ($bcc != "") $bcc = "," . implode(",", $bcc);
    if ($to == "" && $bcc == "") return;
    $recipient = $to . $bcc;
    $headers = array('From' => $from,
                'To' => $to,
                'Subject' => $subject
                );
    $crlf = "\r\n";
    $mime = new Mail_mime($crlf);
    $mime->_build_params['text_charset'] = 'utf-8';
    $mime->_build_params['head_charset'] = 'utf-8';
    $mime->_build_params['text_encoding'] = 'base64';
    $mime->setTXTBody($text);
    $mime->addAttachment($attachment, $attachmentType, $attachmentName, false);
    $body = $mime->get();
    $headers = $mime->headers($headers);
    $mimeparams = array('encoding' => 'base64',
                        'charset' => 'utf-8'
    );
    $smtpParams = array('host' => $smtpHost,
                    'auth' => true,
                    'username' => $smtpUserName,
                    'password' => $smtpPassword
                    );
    $smtp = Mail::factory('smtp', $smtpParams);
    $mail = $smtp->send($recipient, $headers, $body);
    if (PEAR::isError($mail)) {
        $resultMessage = "Error sending email! " . $mail->getMessage() . "\n";
        return false;
    }
    return true;
}

function isEmptyReportReceiver(& $db, $email, & $errormsg) {
    $query = "SELECT is_empty_report_receiver as i_e_r FROM ip_users WHERE email='{$email}'";
    $res = $db->query($query);
    if (PEAR::isError($res)) {
        $errormsg = $res->getMessage();
    } else { 
        if ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
            if ($row['i_e_r'] == true) {
                return true;
            }
        } 
    }
    return false;
}

function getGlobalVarName(& $var) {
	$ret = '';
	$tmp = $var;
	$var = md5(uniqid(rand(), TRUE));
	foreach ($GLOBALS as $k => $v ) {
		if ($v === $var) {
    		$ret = $k;
		  break;
    	}
	}
	$var = $tmp;
	return $ret;
}

function dumpVar(& $var) {
	$name = getGlobalVarName($var);
	echo ($name == "" ? "" : "{$name} = ");
	print_r($var);
    echo "]<br/>\n";
}

function parseTimeIntervalsForTableRow ($time_array) {
    $i = 1;
    foreach ($time_array as $key=>$value) {
        $end = strtotime($value['end']);
        $start = strtotime($value['start']);
        $seconds += strtotime($value['end']) - strtotime($value['start']);
    }
    if ($seconds != 86340) {
        foreach ($time_array as $key=>$value) {
            $coma = ($i > 1) ? "; " : "";
            $starttime = date("H:i", strtotime($value['start']));
            $endtime = date("H:i", strtotime($value['end']));
            $timeintoutput .= "{$coma}{$starttime} - {$endtime}";
            $i++;
        }
        return $timeintoutput;
    } else {
    return "";
    }
}

function parseWeekDays($w) {
global $weekdays;
    $i = 1;
    $comma = ($w == MON || $w == TUE || $w == WED || $w == THU || $w == FRI || $w == SAT || $w == SUN) ?
    "" : ", ";
    if ($w == 0) {
        $week .= "<span style='color : #FF0000'>Invalid data</span>";
    } elseif($w == 127) {
        $week .= "";
    } else {
        foreach($weekdays as $key=>$value){
            if ($w & $key) {
                if ($i > 1) {
                    $week .= $comma . $value;
                } else {
                    $week .= $value;
                }
                $i++;
            }
        }
    }
    return $week;
}

function writeDataFilters($fetchedrow, $startdate, $enddate, $timeintervals, $isPDF=false) {
global $frequency;
    if ($fetchedrow['frequency'] == FQ_MONTHLY) {
        $date1 = strtotime($fetchedrow['data_date_start']);
        $date2 = strtotime($fetchedrow['data_date_end']);
        $startdate = date("Y-m-", strtotime($startdate)) . date("d", $date1);
        $enddate = date("Y-m-", strtotime($enddate)) . date("d", $date2);
    }
    $pdfdatafilter = array();
    if ($fetchedrow['frequency'] != FQ_ONCE) {
        $datafilter .= "<div align=\"center\" style=\"font-size: 1.5em;\">" 
                        . ucfirst($frequency[$fetchedrow['frequency']]) . " report</div>\n";
        $pdfdatafilter['head'] = ucfirst($frequency[$fetchedrow['frequency']]) . " report";
    }  else {
        $pdfdatafilter['head'] = "";
    }
    if ($fetchedrow['report_name'] != '') {
        $datafilter .= "<div align=\"center\">{$fetchedrow['report_name']}</div>\n";
        $pdfdatafilter['name'] = $fetchedrow['report_name'];
    } else {
        $pdfdatafilter['name'] = '';
    }
    if ($startdate == $enddate) {
        $datafilter .= "<div align=\"center\">{$startdate}</div>\n";
        $pdfdatafilter['date'] = $startdate;
    } else {
        $datafilter .= "<div align=\"center\">{$startdate} - {$enddate}</div>\n";
        $pdfdatafilter['date'] = $startdate . " - " . $enddate;
    }
    $datafilter .= "<div align=\"center\">";
    if ($fetchedrow['weekdays'] != 0) {
        $week = parseWeekDays($fetchedrow['weekdays']);
        $pdfweek = parseWeekDays($fetchedrow['weekdays']);
        if ($week != "") {
            $datafilter .= "{$week}; ";
            $pdfdatafilter['week'] = $pdfweek . "; ";
        } else {
            $pdfdatafilter['week'] = "";
        }
    }
    $datafilter .= parseTimeIntervalsForTableRow($timeintervals);
    $pdfdatafilter['timeintervals'] = parseTimeIntervalsForTableRow($timeintervals);
    $datafilter .= "</div>\n";
    $datafilter .= "<div align=\"center\">";
    if ($fetchedrow['ip'] == 0) {
        if ($fetchedrow['rep_type'] == 2) {
            $datafilter .= "Domain statistics";
            $pdfdatafilter['IP'] = "Domain statistics";
        } else {
            $datafilter .= "IP: All users";
            $pdfdatafilter['IP'] = "IP: All users";
        }
    } else {
        $datafilter .= "IP: " . long2ip($fetchedrow['ip']) . ";";
        $pdfdatafilter['IP'] = "IP: " . long2ip($fetchedrow['ip']) . ";";
        if (getIpUserName($fetchedrow['ip'])) {
            $datafilter .= " ( " . getIpUserName($fetchedrow['ip']) . " ) ";
            $pdfdatafilter['ipname'] = " ( " . getIpUserName($fetchedrow['ip']) . " )";
        } else {
            $pdfdatafilter['ipname'] = "";
        }
    }
    $datafilter .= "</div>\n";
    if ($fetchedrow['sub_domain'] == "" && $fetchedrow['domain'] == "" && $fetchedrow['topdomain'] == "") {
        $domain = "";
    } elseif ($fetchedrow['sub_domain'] == "" || $fetchedrow['domain'] == "" || $fetchedrow['topdomain'] == "") {
        if ($fetchedrow['sub_domain'] == "") {
            $domain .= "*.";
        } else {
            $domain .= $fetchedrow['sub_domain'] . ".";
        }
        if ($fetchedrow['domain'] == "") {
            $domain .= "*";
        } else {
            $domain .= $fetchedrow['domain'];
        }
        if ($fetchedrow['topdomain'] == "") {
            $domain .= ".*\n";
        } else {
            $domain .= "." . $fetchedrow['topdomain'] . "\n";
        }
    } else {
        $domain .= $fetchedrow['sub_domain'] . "." . $fetchedrow['domain'] . "." . $fetchedrow['topdomain'] . "<br/>\n";
    }
    if ($domain != ""){
        $datafilter .= "<div align=\"center\">";
        $datafilter .= "Domain: {$domain}";
        $pdfdatafilter['domain'] = "Domain: {$domain}";
        $datafilter .= "</div>\n";
    } else {
        $pdfdatafilter['domain'] = "";
    }
    
    if ($isPDF == false) {
        return $datafilter;
    } else {
        return $pdfdatafilter;
    }
}

function getCurrentWeekBounds(& $datestart, & $dateend) {
    $currenttime = strtotime("now");
    if ((int)date("w", $currenttime) != 1) {
        $datestart = date("Y-m-d", strtotime("last Monday"));
    } else  {
        $datestart = date("Y-m-d", $currenttime);
    }
    $dateend = date("Y-m-d", strtotime("Sunday"));
}

function genTime() {
    static $a;
    if($a == 0) {
        $a = microtime(true);
    } else {
        return (string)(microtime(true)-$a);
    }
}

function getProxylizerConfig(& $db, & $errorMSG) {
    $query = "SELECT name, value FROM proxylizerconfig";
    $res = $db->query($query);
    if (PEAR::isError($res)) {
        $errorMSG = $res->getMessage();
    }
    if ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
        $result[$row['name']] = $row['value'];
    } else {
        return false;
    }
    while ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
        $result[$row['name']] = $row['value'];
    }
    return $result;
}

function getWarningText(& $row, $type) {
    $content = file_get_contents("email_template/warning_email{$type}.txt");
    if ($content == false) {
        echo date("Y-m-d H:i | ") . "Error reading email template. Please, check file permissions!";
    }
    $config = writeDataFilters($row, $row['send_now_boundary_start'], $row['send_now_boundary_end'], array(), true);
    if ($config['head'] != '') {
        $conditions .= ucfirst($config['head']) . "; ";
    }
    $conditions .= $config['IP'] . " ";
    if ($type == 1) {
        $replaceable = array('%generation_start%', '%pid%', '%conditions%');
        $replace = array($row['dt'], $row['pid'], $conditions);
    } elseif ($type == 2) {
        $replaceable = array('%wrng_time%', '%generation_start%', '%conditions%');
        $replace = array(WRNG_TIME, $row['dt'], $conditions);
    }
    $content = str_replace($replaceable, $replace, $content);
    return $content;
}

function getGeneratedReportsCount(& $db, $id) {
    $query = "SELECT count(id) as count FROM generated_reports WHERE report_id='{$id}'";
    $res = $db->query($query);
    if ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
        return $row['count'];
    } else {
        return false;
    }
}

function parseCellString($cell, $len, & $fpdf) {
    $parsed = $cell;
    $middle = "...";
    $start = substr($parsed, 0, strlen($parsed)/2);
    $end = substr($parsed, strlen($parsed)/2);
    while ($fpdf->getStringWidth($start . $middle . $end) > $len) {
        $start = substr($parsed, 0, strlen($parsed)/2 -1 );
        $end = substr($parsed, strlen($parsed)/2 + 1);
        $parsed = $start . $end;
        $istolong = true;
    }
    if ($istolong == true) {
        $parsed = $start . $middle . $end;
    }
    return $parsed;
}

function  getStyle() {
    if($db = connectDB()) {
        $query = "SELECT value FROM proxylizerconfig WHERE name='colorofproxylizer'";
        $res = $db->query($query);
        if ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
            return "style_{$row['value']}.css";
        } else {
            return "style_1.css";
        }
    } else {
        return false;
    }
}

function selectLastId($table_name) {
    if($db = connectDB()) {
        require_once('dbconstants.php');
        foreach ($TABLES as $t) {
            if ($t->name == $table_name) {
                $idfield = $t->primaryKey->name;
                $query = "SELECT MAX({$idfield}) as maxid FROM {$table_name}";
                $res = $db->query($query);
                if ($row = & $res->fetchRow(DB_FETCHMODE_ASSOC)) {
                    return $row['maxid'];
                }
            }
        }
    }
}

?>