<?php
/****************************************************************************
*                                                                           *
*    MikroTik Proxylizer, Web-proxy log analyzer                            *
*    Copyright (C) 2009  MikroTik                                           *
*                                                                           *
*    This program is free software: you can redistribute it and/or modify   *
*    it under the terms of the GNU General Public License as published by   *
*    the Free Software Foundation, either version 3 of the License, or      *
*    (at your option) any later version.                                    *
*                                                                           *
*    This program is distributed in the hope that it will be useful,        *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of         *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
*    GNU General Public License for more details.                           *
*                                                                           *
*    You should have received a copy of the GNU General Public License      *
*    along with this program.  If not, see <http://www.gnu.org/licenses/>.  *
*                                                                           *
****************************************************************************/
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/index.php");
    return false;
}
if (isset($_REQUEST['colorofproxylizer']))  {
    echo "<script type=\"text/javascript\"> document.location='{$_SERVER['PHP_SELF']}?action={$_REQUEST['action']}&a=1&refresh=1';</script>";
}
require_once('proxylizer_config_act.php');
if (!isset($_REQUEST['colorofproxylizer'])) $_REQUEST['colorofproxylizer'] = 1;
$sel_gen_rep_count = "<select style='width: 85px' name=\"maxreports\">";
for ($i = 1; $i <= 8; $i++) {
    $sel_gen_rep_count .= "<option value=\"{$i}\"";
    $sel_gen_rep_count .= $_REQUEST['maxreports'] == $i ? " selected=\"selected\"" : "";
    $sel_gen_rep_count .= ">{$i}</option>";
}
$sel_gen_rep_count .= "</select>";
$sel_del_after = "<select style='width: 85px' name=\"del_after\">";
foreach ($delete_after as $key=>$value) {
    $sel_del_after .= "<option value=\"{$key}\"";
    $sel_del_after .= $_REQUEST['del_after'] == $key ? " selected=\"selected\"" : "";
    $sel_del_after .= ">{$value}</option>";
}
$sel_del_after .= "</select>";
include('templates/change_config_form.php');
echo "<hr><br/><br/>";
include('templates/mail_config_form.php');
echo "<hr><br/><br/>";
include('templates/change_psw_form.php');
?>