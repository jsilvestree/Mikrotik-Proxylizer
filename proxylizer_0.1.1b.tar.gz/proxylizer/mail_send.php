#!/usr/bin/php

<?php
/****************************************************************************
*                                                                           *
*    MikroTik Proxylizer, Web-proxy log analyzer                            *
*    Copyright (C) 2009  MikroTik                                           *
*                                                                           *
*    This program is free software: you can redistribute it and/or modify   *
*    it under the terms of the GNU General Public License as published by   *
*    the Free Software Foundation, either version 3 of the License, or      *
*    (at your option) any later version.                                    *
*                                                                           *
*    This program is distributed in the hope that it will be useful,        *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of         *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
*    GNU General Public License for more details.                           *
*                                                                           *
*    You should have received a copy of the GNU General Public License      *
*    along with this program.  If not, see <http://www.gnu.org/licenses/>.  *
*                                                                           *
****************************************************************************/
if (isset($_SERVER['REQUEST_URI'])) return;
define("STARTED_FROM_INDEX", 2);
chdir(dirname($argv[0]));
include("config_constants.php");
include("constants.php");
include('DB.php');
include('functions.php');
include('ufpdf/ufpdf.php');
require_once("check_report_queue.php");
if ($db = connectDB()) {
    deleteOlderReports($db);
    $report = getFirstReportToGenerate($db);
    if ($report['status'] == RS_ERROR) {
        if ($report != false) {
            //print_r($report);
            generateReport($db, $report);
        } else {
            //echo "No Reports to generate!!!\n";
        }
    } else {
        if (!isMaxRepGenerating($db)) {
            if ($report != false) {
                //print_r($report);
                generateReport($db, $report);
            } else {
              // echo "No Reports to generate!!!\n";
            }
        } else {
        //echo "Max reports generating!\n\n";
        }
    }
	$db->disconnect;
} else {
	echo date("Y-m-d H:i") . " | Not connected to DB!\n";
}

function generateReport(& $db, $rep_conf) {
global $weekNums, $frequency, $config_const;
    genTime();
    $pid = getmypid();
    $date1 = $rep_conf['send_now_boundary_start'];
    $date2 = $rep_conf['send_now_boundary_end'];
    if ($rep_conf['status'] == RS_ERROR) {
        $query = "UPDATE generated_reports SET php_pid={$pid} WHERE id={$rep_conf['gen_rep_id']}";
        $rep_conf_id = $rep_conf['gen_rep_id'];
    } else {
        $query = "INSERT INTO generated_reports(report_id, datestart, dateend, status, php_pid) "
        . " VALUES('{$rep_conf['id']}','{$date1}','$date2','" . RS_IN_PROGRESS . "', '{$pid}')";
        $insertNotUpdate = true;
    }
    $res = $db->query($query);
    if (PEAR::isError($res)) {
        echo date("Y-m-d H:i") . " | " . $res->getMessage() . "\n";
    } else {
        if ($config_const['DB_TYPE'] == "mysql" && $insertNotUpdate == true) {
            $rep_conf_id = mysql_insert_id();
        } else {
            $query = "SELECT MAX(id) as maxid FROM generated_reports";
            $res = $db->query($query);
            if(PEAR::isError($res)) {
                echo date("Y-m-d H:i | ") . $res->getMessage();
            }
            if( $row = & $res->fetchRow(DB_FETCHMODE_ASSOC)) {
                $rep_conf_id = $row['maxid'];
            }
        }

        $wherequery = "";
        $select_date1 = $rep_conf['send_now_date_start'];
        $select_date2 = $rep_conf['send_now_date_end'];
        $time_intervals = fetchTimeIntervals($rep_conf['id'], $db);
        $datestartquery = "webproxylog.event_date>='{$select_date1}' ";
        addWhereCondition($wherequery, $datestartquery);
        $dateendquery = "webproxylog.event_date<='{$select_date2}' ";
        addWhereCondition($wherequery, $dateendquery);
        foreach ($time_intervals as $key=>$value) {
            $end = strtotime($value['end']);
            $start = strtotime($value['start']);
            $seconds += strtotime($value['end']) - strtotime($value['start']);
        }
        if ($seconds != 86340) {
            $counter = 1;
            $or = "";
            $timequery .= "(";
            foreach ($time_intervals as $key=>$value) {
                if ($counter > 1) $or = " or ";
                $timequery .= "{$or}webproxylog.event_time>='{$value['start']}'
                                 and webproxylog.event_time<='{$value['end']}' ";
                $counter++;
            }
            $timequery .= ")";
            addWhereCondition($wherequery, $timequery);
        }
        if ($rep_conf['weekdays'] != 0 && $rep_conf['weekdays'] != 127) {
            $count = 1;
            $or = "";
            $weekdayquery .= "(";
            foreach ($weekNums as $key=>$value) {
                if ($rep_conf['weekdays'] & $key) {
                    if ($count > 1) $or = " or ";
                    $weekdayquery .= "{$or} DAYOFWEEK(webproxylog.event_date)='{$value}' ";
                    $count++;
                }
            }
            $weekdayquery .= ")";
            addWhereCondition($wherequery, $weekdayquery);
        }
        if ($rep_conf['sub_domain'] != "") {
            $subdomainquery = "domain.subdomain='{$rep_conf['sub_domain']}' ";
            addWhereCondition($wherequery, $subdomainquery);
        }
        if ($rep_conf['domain'] != "") {
            $domainquery = "domain.domain='{$rep_conf['domain']}' ";
            addWhereCondition($wherequery, $domainquery);
        }
        if ($rep_conf['topdomain'] != "") {
            $topdomainquery = "domain.topdomain='{$rep_conf['topdomain']}' ";
            addWhereCondition($wherequery, $topdomainquery);
        }
        if ($rep_conf['top'] != 0) $rec_limit_query = "LIMIT {$rep_conf['top']}";
        if ($rep_conf['ip'] == 0 && $rep_conf['rep_type'] == 1) {
            $query = "SELECT IP, count(distinct(TIMESTAMP(event_date, event_time))) as time, "
            . " COUNT(webproxylog.id) as hitcount "
            . " FROM {$config_const['DB_NAME']}.webproxylog "
            . " JOIN {$config_const['DB_NAME']}.domain ON ( webproxylog.domain_id = domain.ID ) "
            . " {$wherequery} GROUP BY IP ORDER BY count(DISTINCT(event_time)) DESC {$rec_limit_query}";
            $header1 = "IP";
            $isdomains = true;
        } elseif ($rep_conf['rep_type'] == 1) {
            $ipquery = "IP='{$rep_conf['ip']}'";
            addWhereCondition($wherequery, $ipquery);
            $query = "SELECT domain.subdomain, domain.domain, domain.topdomain, "
            . " count(distinct(TIMESTAMP(event_date, event_time))) as time, "
            . " COUNT(webproxylog.ID) as hitcount "
            . " FROM {$config_const['DB_NAME']}.webproxylog "
            . " JOIN {$config_const['DB_NAME']}.domain ON ( webproxylog.domain_id = domain.ID ) "
            . " {$wherequery} GROUP BY webproxylog.domain_id "
            ." ORDER BY count(DISTINCT(event_time)) desc {$rec_limit_query}";
            $header1 = "Domain";
            $isdomains = false;
        } elseif ($rep_conf['rep_type'] == 2) {
            $query = "SELECT domain.subdomain as subdomain, domain.domain as domain, domain.topdomain as topdomain,
                                count(distinct(webproxylog.IP)) as ipcount,
                                count(distinct(TIMESTAMP(event_date, event_time))) as time, count(webproxylog.id) as hitcount 
                                FROM {$config_const['DB_NAME']}.webproxylog 
                                JOIN {$config_const['DB_NAME']}.domain ON ( webproxylog.domain_id = domain.ID ) 
                                {$wherequery} GROUP BY webproxylog.domain_id
                                ORDER BY count(DISTINCT(event_time)) desc {$rec_limit_query}";
                                $header1 = "Domain";
                                $isdomains = false;
        }
        $tableheader = array($header1);
        if ($rep_conf['rep_type'] == 2) array_push($tableheader, "IP count");
        array_push($tableheader,"Time (hh:mm)");
        array_push($tableheader, "Hitcount");
        $query2 = "SELECT count(distinct(TIMESTAMP(event_date, event_time))), count(webproxylog.id) "
        . " FROM {$config_const['DB_NAME']}.webproxylog "
        . " JOIN {$config_const['DB_NAME']}.domain ON ( webproxylog.domain_id = domain.ID ) "
        . " {$wherequery}";
        //echo $query . "\n";
        //echo $query2 . "\n";
        $res =& $db->query($query);
        $datafilters = writeDataFilters($rep_conf, $date1, $date2, $time_intervals, true);
        if (PEAR::isError($res)) {
            echo date("Y-m-d H:i") . " | " .  $res->getMessage() . "\n";
        } else {
            $i = 0;
            if ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
                $data = array();
                $htmltable = "";
                array_push($data, writeTableRow($row, $isdomains, true, true, $rep_conf['rep_type']));
                $datafiltershtml = writeDataFilters($rep_conf, $date1, $date2, $time_intervals);
                $eoftable = "</table>";
                //$htmltable .= $datafiltershtml;
                //$htmltable .= writeTableHeader($header1, "Time", $rep_conf['rep_type']);
                //$htmltable .= writeTableRow($row, $isdomains, true, false, $rep_conf['rep_type']);
            } else {
                if (!isEmptyReportReceiver($db, $rep_conf['email'], $errormsg)) {
                    $rep_conf['email'] = '';
                    if ($errormsg) echo date("Y-m-d H:i | ") .  $errormsg . "\n";;
                }
                if ($rep_conf['rep_type'] == 2) {
                    $ipconditions = "Domain statistics";
                } elseif ($isdomains == false) {
                    $ip = long2ip($rep_conf['ip']);
                    $ipconditions = "IP : {$ip}\n";
                } else {
                    $ipconditions = "IP : All users\n";
                }
                if ($rep_conf['send_to_admin'] == true) {
                    $adm_mails = getAdmEmail_s($db, true);
                } else {
                    $adm_mails = '';
                }
                $report_name = $rep_conf != '' ? "Report name : {$rep_conf['report_name']}; " : ''; 
                $conditions = "{$report_name}Date interval : {$date1} - {$date2}; {$ipconditions}";
                $htmltable = serialize(array("no_rec"=>"No records for this conditions!"));
                if($proxconf = getProxylizerConfig($db, $errormsg)) {
                    $text = getNoRecordsEmailText($conditions);
                    if ($rep_conf['frequency'] == 0) {
                        $frequency[$rep_conf['frequency']] = '';
                    }
                    send_mail_smtp($proxconf['from_mail'], $rep_conf['email'],
                    ucfirst($frequency[$rep_conf['frequency']]) . " report",
                    $text, '', '', '', $proxconf['smtp'], $proxconf['smtp_user'],
                    $proxconf['smtp_psw'], $adm_mails, $result);
                    if ($result) {
                        echo date("Y-m-d H:i | ") .  $result . "\n";
                    }
                } else {
                    echo date("Y-m-d H:i") . " | " .  $errormsg . "\n";
                }
                $query = "UPDATE {$config_const['DB_NAME']}.generated_reports SET msg='{$htmltable}'"
                . " WHERE id='{$rep_conf_id}'";
                $update = &$db->query($query);
                if (PEAR::isError($update)) {
                    echo date("Y-m-d H:i") . " | " .  $update->getMessage() . "\n";
                } else {
                }
                reportGenerated($db, $rep_conf_id);
            }
            while ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
                array_push($data, writeTableRow($row, $isdomains, true, true, $rep_conf['rep_type']));
                //$htmltable .= writeTableRow($row, $isdomains, true, false, $rep_conf['rep_type']);
            }
            $res2 =& $db->query($query2);
            if (PEAR::isError($res2)) {
                echo date("Y-m-d H:i") . " | " .  $res2->getMessage() . "\n";
            } else {
                if ($row =& $res2->fetchRow()) {
                    $totaltime = $row['0'];
                    if ($totaltime != 0) {
                        $totaltime = array ("Total time");
                        if($rep_conf['rep_type'] == 2) array_push($totaltime, '');
                        array_push($totaltime, formatTime($row['0'], false, true));
                        array_push ($totaltime, $row['1']);
                        array_push($data, $totaltime);
                        //$htmltable .= "<tr>";
                        //if ($rep_conf['rep_type'] == 2) //$htmltable .= "<td></td>";
                        //$htmltable .= "<td align=\"center\"> Total time</td>";
                        //$htmltable .= "<td align=\"center\">" . formatTime($row['0']) . "</td>";
                        //$htmltable .- "<td align=\"center\"> {$row['1']}</td>";
                        //$htmltable .= "</tr>";
                        //$htmltable .= $eoftable;
                        $htmltable = array("data_filters"=>$datafilters, "header" => $tableheader, "data" => $data);
                        $htmltable = serialize($htmltable);
                        $query = "UPDATE {$config_const['DB_NAME']}.generated_reports SET msg='{$htmltable}'"
                        . " WHERE id='{$rep_conf_id}'";
                        $update = &$db->query($query);
                        if (PEAR::isError($update)) {
                            echo date("Y-m-d H:i") . " | " .  $update->getMessage() . "\n";
                        }
                        $is_mail_sent = true; // if this changes mail not sent;
                        if($proxconf = getProxylizerConfig($db, $errormsg)) {
                            if ($rep_conf['send_to_admin'] == true) {
                                $adm_mails = getAdmEmail_s($db);
                            } else {
                                $adm_mails = '';
                            }
                            // check if some mail is empty becouse cant send to email '';
                            if ($adm_mails != '' || $rep_conf['email'] !='') {
                                $is_mail_sent = sendSmtpMailPdfAttached($rep_conf['email'], $data, $datafilters,
                                $tableheader, $rep_conf, $proxconf, $adm_mails, $date1, $date2);
                            }
                        } else {
                            echo date("Y-m-d H:i") . " | " .  $errormsg . "\n";
                        }
                        if ($is_mail_sent != false) {
                            reportGenerated($db, $rep_conf_id);
                        }
                    }
                }
            }
        }
    }
}



function generatePdfAttachment($data, $datafilters, $tableheader, $rep_type) {
    require_once('ufpdf/ufpdf_extended.php');
    $pdf = new PDF('P', 'mm', 'A4');
    $pdf->Open();
    $pdf->AddFont('Times', '', 'times.php');
    //$pdf->AddFont('Timesb', '', 'timesb.php');
    $pdf -> AddPage();
    $pdf->SetTitle($datafilters['head'], true);
    $pdf->SetAuthor("MikroTik Proxylizer", true);
    $pdf -> SetFont('Times', '', '16');
    if ($datafilters['head'] != "") {
        $pdf->Cell(0, 0, $datafilters['head'], 0, 0, 'C');
        $pdf->Ln(6);
    }
    $pdf->SetFont('Times', '', '12');
    if ($datafilters['date'] != "") {
        $pdf->Cell(0, 0, $datafilters['date'], 0, 0, 'C');
        $pdf->Ln(5);
    }
    if ($datafilters['week'] != "") {
        $pdf->Cell(0, 0, $datafilters['week'] . $datafilters['timeintervals'], 0, 0, 'C');
        $pdf->Ln(5);
    }
    if ($datafilters['IP'] != "") {
        $pdf->Cell(0, 0, $datafilters['IP'] . $datafilters['ipname'], 0, 0, 'C');
        $pdf->Ln(5);
    }
    if ($datafilters['domain'] != "") {
        $pdf->Cell(0, 0, $datafilters['domain'], 0, 0, 'C');
        $pdf->Ln(5);
    }
    $pdf->RepTable($tableheader, $data, $rep_type);
    $pdf->Close();
    return $pdf->Output("", "S");
}


function getEmailText($freqnum, $datafilters) {
global $frequency;
    if ($freqnum == 3) {
        $dates =  explode(" - ", $datafilters['date']); 
        $monthname = date("F", strtotime($dates['0']));
        $datafilters['date'] = $monthname;
        $datereplaceable = "dates %datebetween%";
    } else {
        $datereplaceable = "%datebetween%";
    }
    $contents = file_get_contents("email_template/e-mail.txt");
    $replaceable = array("%frequency%", $datereplaceable, "%IP%", "%report_name%");
    if ($freqnum == 0) $frequency[$freqnum] = "";
    $report_name = $datafilters['name'] != '' ? "report name : " . $datafilters['name'] : '';
    $replace = array($frequency[$freqnum], $datafilters['date'],
                $datafilters['IP'] . $datafilters['ipname'], $report_name);
    $contents = str_replace($replaceable, $replace, $contents);
    return $contents;
}


function  getNoRecordsEmailText($conditions) {
    $contents = file_get_contents("email_template/no_records.txt");
    $contents = str_replace("%conditions%", $conditions, $contents);
    return $contents;
}

function sendSmtpMailPdfAttached($email, $data, $datafilters, $tableheader, $rep_conf, $proxconf, $adm_mails, $data_date_start, $data_date_end) {
global $frequency;
    if ($rep_conf['frequency'] == FQ_MONTHLY) {
        $date1 = strtotime($rep_conf['data_date_start']);
        $date2 = strtotime($rep_conf['data_date_end']);
        $data_date_start = date("Y-m-", strtotime($data_date_start)) . date("d", $date1);
        $data_date_end = date("Y-m-", strtotime($data_date_end)) . date("d", $date2);
    }
    if ($rep_conf['frequency'] == 0) {
        $frequency[$rep_conf['frequency']] = '';
    }
    //echo "SEND MAIL WITH PDF VIA SMTP!\n\n";
    $pdfreport = generatePdfAttachment($data, $datafilters, $tableheader, $rep_conf['rep_type']);
    $text = getEmailText($rep_conf['frequency'], $datafilters);
    $is_sent = send_mail_smtp($proxconf['from_mail'], $email, ucfirst($frequency[$rep_conf['frequency']]) . " report", 
            $text, $pdfreport, "application/pdf", $data_date_start . "_" . $data_date_end . ".pdf", $proxconf['smtp'], 
            $proxconf['smtp_user'], $proxconf['smtp_psw'], $adm_mails, $resultMSG );
    //echo "\n----{$resultMSG}----\n";
    return $is_sent;
}

function reportGenerated(& $db, $id) {
    (int)$gen_time = genTime();
    $gen_time = round($gen_time, 0);
    if ($gen_time == 0) $gen_time = 1;
    $query = "UPDATE generated_reports SET status=" . RS_DONE . ", execute_time={$gen_time}, "
            ." execute_count=execute_count+1 WHERE id='{$id}'";
    $update = &$db->query($query);
    if (PEAR::isError($update)) {
        echo date("Y-m-d H:i") . " | " .  $update->getMessage() . "\n";
    } else {
        //echo "STATUS SET!!!!!";
    }
}


function getAdmEmail_s(& $db, $is_empty_record = false) {
    $query = "SELECT email FROM ip_users WHERE is_admin='1'";
    $res = $db->query($query);
    $admins = array();
    $count = 0;
    if (PEAR::isError($res)) {
        echo date("Y-m-d H:i") . " | " .  $res->getMessage() . "\n";
    } else {
        if ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
            if ($is_empty_record == true) { 
                if (isEmptyReportReceiver($db, $row['email'], $error)) {
                    array_push($admins, $row['email']);
                }
            } else {
                array_push($admins, $row['email']);
            }
        } else {
            return false;
        }
        while ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
            if ($is_empty_record == true) {
                if (isEmptyReportReceiver($db, $row['email'], $error)) {
                    array_push($admins, $row['email']);
                }
            } else {
                array_push($admins, $row['email']);
            }
        }
    }
    if (count($admins) == 0) $admins = '';
    return $admins;
}

function deleteOlderReports(& $db) {
    $prox_conf = getProxylizerConfig($db, $error);
    if ($error) {
        echo date("Y-m-d H:i | ") . $error . "\n";
    }
    if ($prox_conf['del_after'] == 0) {
        return;
    } else {
        //$delete_after = date("Y-m-d", strtotime("- " . $prox_conf['del_after'] . " month"));
        // in this case incorect result for strtotime(- n months);
        // so better delete less then more;
        $days_interval = (int)$prox_conf['del_after'] * 31;
        $delete_after = date("Y-m-d", strtotime("- " . $days_interval . " days"));
        $query = "DELETE FROM webproxylog WHERE event_date < '{$delete_after}'";
        $delete = &$db->query($query);
        if (PEAR::isError($delete)) {
            echo date("Y-m-d H:i | ") . $delete->getMessage() . "\n";
        } else {
            
        }
    }
}

?>