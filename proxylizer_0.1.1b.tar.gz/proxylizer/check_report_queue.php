<?php
/****************************************************************************
*                                                                           *
*    MikroTik Proxylizer, Web-proxy log analyzer                            *
*    Copyright (C) 2009  MikroTik                                           *
*                                                                           *
*    This program is free software: you can redistribute it and/or modify   *
*    it under the terms of the GNU General Public License as published by   *
*    the Free Software Foundation, either version 3 of the License, or      *
*    (at your option) any later version.                                    *
*                                                                           *
*    This program is distributed in the hope that it will be useful,        *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of         *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
*    GNU General Public License for more details.                           *
*                                                                           *
*    You should have received a copy of the GNU General Public License      *
*    along with this program.  If not, see <http://www.gnu.org/licenses/>.  *
*                                                                           *
****************************************************************************/
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/index.php");
    return false;
}
require_once("constants.php");

function getFirstReportToGenerate(& $db) {
global $weekdays, $weekNums, $config_const;

    // query fields:
    // date boundaries about which to generate: [data_date_start, data_date_end] 
    // date boundaries when last report generated: [gen_date_start, gen_date_end]
    // send date boundaries: [send_date_start, send_date_end] + send_time

    // variables:
    // $sendtime: timestamp when the current report must be sent
    // $dataStartData, $dataEndDate: overall boundaries of report config data  
    // $lastGeneratedStart, $lastGeneratedEnd: data boundaries of last generated report
    $current_time = date("Y-m-d H:i");
    $query = "SELECT g.status IS NULL as isnull, c.id, c.report_name, c.email, c.send_to_admin, c.frequency, c.rep_type, "
            . " c.date_start as data_date_start, c.date_end as data_date_end, "
            . " c.send_date_start, c.send_date_end, c.send_time, c.weekdays as data_weekday, "
            . " c.send_weekday, c.IP, c.sub_domain, c.domain, c.topdomain, c.top, c.is_active,"
            . " g.id as gen_rep_id, g.date_time as dt, g.datestart as gen_date_start, "
            . " g.dateend as gen_date_end, g.status, g.php_pid as pid, "
            . " g.execute_count as counter FROM {$config_const['DB_NAME']}.report_config as c LEFT JOIN "
            . " {$config_const['DB_NAME']}.generated_reports as g ON "
            . " (c.id=g.report_id) WHERE c.is_active<'{$current_time}' AND (g.id=(SELECT id FROM generated_reports "
            . " AS g2 WHERE g2.report_id=c.id ORDER BY g2.id DESC LIMIT 1) OR g.id IS NULL)"
            . " ORDER BY isnull ASC, g.status ASC, g.date_time ASC";
    //echo $query;
    $res = $db->query($query);
    if (PEAR::isError($res)) {
        echo date("Y-m-d h:i | ") . $res->getMessage() . "\n";
        return false;
    }
    
    while ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
        if (PEAR::isError($res)) {
            echo date("Y-m-d h:i | ") . $row->getMessage() . "\n";
            continue;
        }
	if ($row['frequency'] == FQ_ONCE) {
            $reportToSend = checkOnceReportRow($row, $db, $query);
        } else {
            $reportToSend = checkReportRow($row, $db, $query);
        }
	if ($reportToSend !== false) return $reportToSend;        
    }

    return false;
}

function checkOnceReportRow(& $row, & $db, $query) {
    //print_r($row);
    // exact timestamp of sendtime is known
    if ($row['status'] == null || $row['status'] == RS_IN_PROGRESS) {
        if ((int)$row['status'] == RS_IN_PROGRESS) {
            if(isError($row, $db, $query)) {
                $counter = updateCounter($db, $row);
                $row['status'] = RS_ERROR;
                if ($counter == WRNG_TIME) {
                    if(warningNotSent($db, $row['gen_rep_id'])) {
                        sendWarning($db, $row, $query, 2);
                    }
                }
            } else {
	    
            }
        }
        //echo "not sent yet\n";
        $sendtime = strtotime($row['send_date_start'] . " " . $row['send_time']);
        $currenttime = strtotime("now");
        if ($sendtime < $currenttime) {
            //echo "send time in past, ok, returning\n";
            $row['send_now_date_start'] = $row['data_date_start'];
            $row['send_now_date_end'] = $row['data_date_end'];
            $row['send_now_boundary_start'] = $row['data_date_start'];
            $row['send_now_boundary_end'] = $row['data_date_end'];
            //echo "generation data period: [" . $row['data_date_start']
            //    . ", " . $row['data_date_end'] . "]\n";
            return $row;
        } else {
            //echo "send time in future, not sending\n";
        }
    }
    return false;
}

function checkReportRow(& $row, & $db, $query) {
    if ((int)$row['status'] === RS_IN_PROGRESS) {
        if(isError($row, $db, $query)) {
            $counter = updateCounter($db, $row);
            if ($counter == WRNG_TIME) {
                if(warningNotSent($db, $row['gen_rep_id'])) {
                    sendWarning($db, $row, $query, 2);
                }
            }
            $row['status'] = RS_ERROR;
            return checkRow($row);
        } else {
            return false;
        }
    } else {
        return checkRow($row);
    }
}

function checkRow(& $row) {
    if ($row['status'] != RS_IN_PROGRESS || $row['status'] == null || $row['status'] == RS_ERROR) {
        // report is not in progress
        //echo "not in progress\n";
        $dataWeekdays = (int) $row["data_weekday"]; // 0 = Sun, 1 = Mon, 2 = Tue, ...
        $currdate = strtotime(date("Y-m-d"));
        if ($row['status'] == RS_DONE) {
            // report already generated at least once
            //echo "some already finished\n";
            $lastPeriodEnd = strtotime($row['gen_date_end']);            
            //echo "last generated: [" . $row['gen_date_start'] . ", " . $row['gen_date_end'] . "]\n";
        } elseif ($row['status'] == RS_ERROR) {
            $lastPeriodEnd = strtotime($row['gen_date_end']);
        } else {
            //echo "no previous reports\n";
            // fake last period end
            if ($row['frequency'] == FQ_MONTHLY) {
                $lastGenMonthStart = date("Y-m-1", strtotime($row['data_date_start']));
                $lastPeriodEnd = addDays(strtotime($lastGenMonthStart), -1);
            } else {
                $lastPeriodEnd = addDays(strtotime($row['data_date_start']), -1);
            }
        }
	// find first period after last report, about which to generate
        if ($row['status'] != RS_ERROR) {
            $is_active_time = strtotime($row['is_active']);
	        $nextTimeStart = getNextTimeStart($row, $lastPeriodEnd);
            if ($nextTimeStart === false) return false;
            $nextTimeEnd = getNextTimeEnd($row, $lastPeriodEnd, $nextTimeStart);
            if ($nextTimeEnd === false) return false;
            while ($nextTimeEnd < $is_active_time) {
		$lastPeriodEnd = addDays($lastPeriodEnd, daysInPeriod($lastPeriodEnd, $row['frequency']));
                $nextTimeStart = getNextTimeStart($row, $lastPeriodEnd);
		if ($nextTimeStart === false) return false;
		$nextTimeEnd = getNextTimeEnd($row, $lastPeriodEnd, $nextTimeStart);
                if ($nextTimeEnd === false) return false;
            }
	} else {
            $nextTimeStart = strtotime($row['gen_date_start']);
            $nextTimeEnd = strtotime($row['gen_date_end']);
        }
	//echo "next period: [" . date("Y-m-d", $nextTimeStart)
        //. ", " . date("Y-m-d", $nextTimeEnd) . "]\n";
        if ($nextTimeEnd !== false && $nextTimeEnd < $currdate) {
            //echo "data boundary in past, look at send time\n";
            $sendTime = getSendTime($row, $nextTimeEnd);
            $currenttime = strtotime("now");
            $is_active_time = strtotime($row['is_active']);
            //echo "send time = " . date("Y-m-d H:i:s", $sendTime) . ", now = " 
            //   . date("Y-m-d H:i:s") . "\n";
            if ($sendTime !== false && $sendTime < $currenttime) {
                //echo "report must be sent\n";
                $row['send_now_date_start'] = date("Y-m-d", $nextTimeStart);
                $row['send_now_date_end'] = date("Y-m-d", $nextTimeEnd);
                if ($row['frequency'] == FQ_DAILY) {
                    // daily boundaries = actual data boundaries
                    $row['send_now_boundary_start'] = date("Y-m-d", $nextTimeStart);
                    $row['send_now_boundary_end'] = date("Y-m-d", $nextTimeEnd);
                } else {
                    // weekly/monthly boudaries = week/month boundaries
                    // also when the actual data boundaries differ
                    $boundStart = addDays($lastPeriodEnd, 1);
                    $row['send_now_boundary_start'] = date("Y-m-d", $boundStart);
                    $periodLen = daysInPeriod($lastPeriodEnd, $row['frequency']);
                    $boundEnd = addDays($lastPeriodEnd, $periodLen);
                    $row['send_now_boundary_end'] = date("Y-m-d", $boundEnd);
                }
                //echo "boundaries: [" . $row['send_now_boundary_start']
                //    . ", " . $row['send_now_boundary_end'] . "]\n";
                return $row;
            } else {
                //echo "not sending\n";
            }
        } else {
            //echo "nextTimeEnd > currdate\n";
        }
    }
    return false;
}

function daysInPeriod($lastGeneratedEnd, $frequency) {
    global $monthdaycount;
    switch ($frequency) {
    case FQ_DAILY: return 1;
    case FQ_WEEKLY: return 7;
    case FQ_MONTHLY: {
        $nextMonthStart = addDays($lastGeneratedEnd, 1);
        $nextMonth = (int) date("m", $nextMonthStart);
        return date('t', $nextMonthStart);        
    }
    default: return 0;
    }
}

// start of next period = lastPeriodEnd + 1 day
// exception for month: can have date-offset
// incrementing startDate until it matches an allowed weekday              
function getNextTimeStart(& $row, $lastGeneratedEnd) {
    // monthly reports can start from specified day (for ex., 10th)
    if ($row['frequency'] == FQ_MONTHLY) {
        // offset stored as 1970-01-xx, we need only the xx part
        $offset = (int) date("d", strtotime($row['data_date_start']));
        // add xx days to start date
        $nextTimeStart = addDays($lastGeneratedEnd, $offset);
    } else {
        $nextTimeStart = addDays($lastGeneratedEnd, 1);
    }

    // check weekdays, increment start when neccessary
    $dataWeekdays = (int) $row["data_weekday"]; // 0 = Sun, 1 = Mon, 2 = Tue, ...    
    if ($dataWeekdays != ALL_WEEKDAYS && $dataWeekdays != 0) {
        $nextTimeStart = getFirstNeededDate($nextTimeStart, $dataWeekdays, true);
    }
    
    return $nextTimeStart;
}

// end of next period = lastPeriodEnd + periodLength
// then find first allowed weekday
function getNextTimeEnd(& $row, $lastGeneratedEnd, $nextTimeStart) {
    if ($row['frequency'] == FQ_DAILY) {
        $nextTimeEnd = $nextTimeStart;
    } else if ($row['frequency'] == FQ_WEEKLY) {
        $nextTimeEnd = addDays($lastGeneratedEnd, 7);
    } else if ($row['frequency'] == FQ_MONTHLY) {
        $endDate = (int) date("d", strtotime($row['data_date_end']));
        $nextTimeEnd = addDays($lastGeneratedEnd, $endDate);
    } else {
        return false;
    }
    // check if date fits in report interval
    if ($nextTimeEnd > strtotime($row['data_date_end'])) {
        //echo "nextTimeEnd > data_end_date\n";
        return false;
    }
    // check weekdays, decrement end when neccessary
    $dataWeekdays = (int) $row["data_weekday"]; // 0 = Sun, 1 = Mon, 2 = Tue, ...    
    if ($dataWeekdays != ALL_WEEKDAYS && $dataWeekdays != 0) {
        // value false for parameter 'doIncrement' means "find in opposite direction"
        $nextTimeEnd = getFirstNeededDate($nextTimeEnd, $dataWeekdays, false);
    }
    return $nextTimeEnd;
}

function allowedDayOfWeek($dayOfWeek, $allowedWeekDays) {
    global $weekBits;
    return $allowedWeekDays & $weekBits[$dayOfWeek];
}

// find first date in interval [startDate, startDate + 6] with respect to allowed weekdays
function getFirstNeededDate($startDate, $allowedWeekdays, $doIncrement = true) {
    //echo "getFirstNeededDate(" . date("Y-m-d", $startDate) . ", $allowedWeekdays, $doIncrement)\n";
    $dt = $startDate;
    $endDt = addDays($startDate, ($doIncrement ? 7 : -7));
    while ($dt != $endDt) {
        $wd = (int) date("w", $dt) + 1; // day-of-week as in mysql
        //echo "chk " . date("Y-m-d", $dt) . ", wd = {$wd}\n";
        if (allowedDayOfWeek($wd, $allowedWeekdays)) return $dt;
        $dt = addDays($dt, ($doIncrement ? 1 : -1)); // increment/decrement
    }
    return false;
}

// get send time for date interval with specified end-date
function getSendTime(& $row, $dataIntervalEnd) {
    //echo "getSendTime(" . date("Y-m-d", $dataIntervalEnd) . ")\n";
    if ($row['frequency'] == FQ_DAILY) {
        //echo "daily\n";
        // send on next day for daily report
        $send_time = strtotime(date("Y-m-d", addDays($dataIntervalEnd, 1)) . " " . $row['send_time']);
        //$send_weekday = (int) date("w ", addDays($dataIntervalEnd, 1) . $row['send_time']);
        //while(!allowedDayOfWeek($send_weekday, $row['data_weekday'])) {
        //    $send_time = strtotime(date("Y-m-d", addDays($send_time, 1)) . " " . $row['send_time']);
	//    $send_weekday = (int) date("w ", $send_time . $row['send_time']);
	//    echo $send_weekday . " <- wd\n";
	//echo date("Y-m-d H:i:s"  ,$send_time) . " <- st\n";
        //}
	return $send_time;
    } else if ($row['frequency'] == FQ_WEEKLY) {
        //echo "weekly\n";
        // for weekly report find required weekday, starting with next day
        return getFirstNeededDate(addDays($dataIntervalEnd, 1), $row['send_weekday'], true);
    } else if ($row['frequency'] == FQ_MONTHLY) {
        //echo "monthly\n";
        // monthly reports must be sent on specified date (day of month)
        // check if that date in current month (i.e., the month about which the data is gathered)
        // is past already. when yes, send next month, when not - send current month
        $dataEndDate = (int) date("d", $dataIntervalEnd);
        $sendDate = (int) date("d", strtotime($row['send_date_start']));
        $sendYear = (int) date("Y", $dataIntervalEnd);
        $sendMon = (int) date("m", $dataIntervalEnd);
        //echo "data end = {$dataEndDate}, send date = {$sendYear}-{$sendMon}-{$sendDate}\n";
        if ($dataEndDate >= $sendDate) {
            $sendMon++;
            if ($sendMon > 12) {
                $sendYear++;
                $sendMon = 1;
            }
        }
        return strtotime("{$sendYear}-{$sendMon}-{$sendDate} " . $row['send_time']);
    } else {
        return false;
    }    
}

function isMaxRepGenerating(& $db) {
    $query = "SELECT COUNT(id) as count FROM generated_reports WHERE status=" . RS_IN_PROGRESS;
    $res = $db->query($query);
    if (PEAR::isError($res)) {
        echo date("Y-m-d h:i | ") . $res->getMessage() . "\n";
    } else {
        if ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
            if (PEAR::isError($row)) {
                echo  date("Y-m-d h:i | ") . $row->getMessage() . "\n";
            } else {
                $count = (int)$row['count'];
            }
        }
    }
    //dumpVar($count);
    $query = "SELECT name, value FROM proxylizerconfig WHERE name='maxreports'";
    $res = $db->query($query);
    $maxrep = 1;
    if (PEAR::isError($res)) {
        echo date("Y-m-d h:i | ") . $res->getMessage() . "\n";
    } else {
        if ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
            if (PEAR::isError($res)) {
                echo date("Y-m-d h:i | ") . $row->getMessage() . "\n";
            } else {
                $maxrep = (int)$row['value'];
            }
        }
    }
    //dumpVar($maxrep);
    return $count >= $maxrep;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function isError(& $row, & $db, $query) {
    $ps_pid = popen("ps {$row['pid']} | grep " . MAIL_SEND_FILE, "r");
    $result = fread($ps_pid, 1024);
    if ($result == "") {
        return true;
    } else {
        if (strtotime("now") - strtotime($row['dt']) > 3600) {
            if (warningNotSent($db, $row['gen_rep_id'])) {
                sendWarning($db, $row, $query, 1);
                return false;
            }
        } else {
            return false;
        }
    }
    pclose($ps_pid);
}

function updateCounter(& $db, & $row) {
    $query = "UPDATE generated_reports  SET execute_count={$row['counter']} + 2 WHERE id='{$row['gen_rep_id']}'";
    $update = $db->query($query);
    if(PEAR::isError($update)) {
        echo date("Y-m-d h:i | ") . $update->getMessage();
    } else {
        return ($row['counter'] + 2) >> 1;
    }
}

function warningNotSent(& $db, $id) {
    $query = "SELECT execute_count FROM generated_reports WHERE id={$id}";
    $res = $db->query($query);
    if(PEAR::isError($res)) {
        echo date("Y-m-d h:i | ") . $res->getMessage();
    } else {
        if ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
            if ($row['execute_count'] & 1) {
                return false;
            } else {
                return true;
            }
        } else {
             echo date("Y-m-d h:i | ") . "Error fetching row!";
        }
    }
}

function sendWarning(& $db, & $row, $query, $type) {
    $prox_conf = getProxylizerConfig($db, $errormsg);
    $text = getWarningText($row, $type);
    send_mail_smtp($prox_conf['from_mail'], $prox_conf['main_email'], "Proxylizer warning!", $text,
    '', '', '', $prox_conf['smtp'], $prox_conf['smtp_user'], $prox_conf['smtp_psw'], '', $error);
    if ($error) {
        echo date("Y-m-d h:i | ") . $error;
    } else {
        if(setEmailSent($db, $row['gen_rep_id'])) {
            return true;
        } 
    }
    
}

function setEmailSent($db, $id) {
    $query = "UPDATE generated_reports SET execute_count=execute_count+1 WHERE id={$id}";
    $update = $db->query($query);
    if (PEAR::isError($update)) {
        echo date("Y-m-d h:i | ") . $update->getMessage();
    } else {
        return true;
    }
}
