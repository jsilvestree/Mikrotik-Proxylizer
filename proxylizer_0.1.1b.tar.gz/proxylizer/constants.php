<?php
/****************************************************************************
*                                                                           *
*    MikroTik Proxylizer, Web-proxy log analyzer                            *
*    Copyright (C) 2009  MikroTik                                           *
*                                                                           *
*    This program is free software: you can redistribute it and/or modify   *
*    it under the terms of the GNU General Public License as published by   *
*    the Free Software Foundation, either version 3 of the License, or      *
*    (at your option) any later version.                                    *
*                                                                           *
*    This program is distributed in the hope that it will be useful,        *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of         *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
*    GNU General Public License for more details.                           *
*                                                                           *
*    You should have received a copy of the GNU General Public License      *
*    along with this program.  If not, see <http://www.gnu.org/licenses/>.  *
*                                                                           *
****************************************************************************/
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/index.php");
    return false;
}
// weekday constants;
define("MON", 1);
define("TUE", 2);
define("WED", 4);
define("THU", 8);
define("FRI", 16);
define("SAT", 32);
define("SUN", 64);
define("ALL_WEEKDAYS", (MON + TUE + WED + THU + FRI + SAT + SUN));

define("RT_USERS", 1);
define("RT_DOMAINS", 2);

$report_type = array( RT_USERS => "User statistics",
                    RT_DOMAINS => "Domain statistics"
                );
$report_type_short = array( RT_USERS => "Users",
                    RT_DOMAINS => "Domains"
                );

define("FQ_ONCE", 0);
define("FQ_DAILY", 1);
define("FQ_WEEKLY", 2);
define("FQ_MONTHLY", 3);

$frequency = array(FQ_ONCE => "once",
                   FQ_DAILY => "daily",
                   FQ_WEEKLY => "weekly",
                   FQ_MONTHLY => "monthly"
                );
$TOP = array(0 => "View all",
        5 => "View top 5",
        10 => "View top 10",
        20 => "View top 20",
        50 => "View top 50",
        100 => "View top 100",
);
$weekdays = array (SUN => "Sun", 
                MON => "Mon",
                TUE => "Tue",
                WED => "Wed",
                THU => "Thu",
                FRI => "Fri",
                SAT => "Sat"
                
);

$weekNums = array ( MON => 2,
                TUE => 3,
                WED => 4,
                THU => 5,
                FRI => 6,
                SAT => 7,
                SUN => 1
);
$weekBits = array_flip($weekNums);


$monthdaycount = array ( 1 => 31, // Jan
                        2 => 28, // Feb
                        3 => 31, // Mar
                        4 => 30, // Apr 
                        5 => 31, // May
                        6 => 30, // June
                        7 => 31, // July
                        8 => 31, // Aug
                        9 => 30, // Sept
                        10 => 31, // Oct
                        11 => 30, // Nov
                        12 => 31 // Dec
);

$delete_after = array( 0 => "Never delete", 
                    12 => "1 year",
                    6 => "6 months",
                    3 => "3 months",
                    1 => "1 month"
);

//files
define("MAIL_SEND_FILE", "./mail_send.php");

// report status
define ("SECONDS_IN_HOUR", 360);
define("RS_IN_PROGRESS", 1);
define("RS_DONE", 2);
define("RS_ERROR", 3);
define("SECONDS_IN_DAY", 86400);

define("WRNG_TIME", 6);
define("REPORT_NAME_LENGTH", 25);
define("REPORT_NAME_WORD_LENGTH", 15);
define("R_NOT_ACTIVE", "2030-01-01 00:00:00");
?>