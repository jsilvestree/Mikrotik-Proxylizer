<?php
/****************************************************************************
*                                                                           *
*    MikroTik Proxylizer, Web-proxy log analyzer                            *
*    Copyright (C) 2009  MikroTik                                           *
*                                                                           *
*    This program is free software: you can redistribute it and/or modify   *
*    it under the terms of the GNU General Public License as published by   *
*    the Free Software Foundation, either version 3 of the License, or      *
*    (at your option) any later version.                                    *
*                                                                           *
*    This program is distributed in the hope that it will be useful,        *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of         *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
*    GNU General Public License for more details.                           *
*                                                                           *
*    You should have received a copy of the GNU General Public License      *
*    along with this program.  If not, see <http://www.gnu.org/licenses/>.  *
*                                                                           *
****************************************************************************/
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/index.php");
    return false;
}

if (isset($_REQUEST['delete'])){
    
    if ($_REQUEST['IP'] != "") {
        $ipquery = "";
        $ip =ip2long($_REQUEST['IP']);
        $ipquery .= " and IP = '" . $ip . "'";
    }
    if ($ip !== false) {
        if ($_REQUEST['datetime1'] != "" && $_REQUEST['datetime2'] != "") {
            $datetime1 = requestToValidDate($_REQUEST['datetime1']);
            if (!$errors) {
                $datetime2 = requestToValidDate($_REQUEST['datetime2']);
                if (!$errors) {
                    $db = & DB::connect($dsn, $options);
                    if (PEAR::isError($db)) {
                        return $db->getMessage();
                    } else {
                        $query = "DELETE FROM webproxylog WHERE event_date >= '{$datetime1}'
                                    and event_date<='{$datetime2}'  {$ipquery}";
                        //echo $query;
                        $res =& $db->query($query);
                        if (PEAR::isError($res)) {
                            return $res->getMessage();
                        } else {
                           $result = "{$db->affectedRows()} records successfuly deleted!";
                        }    
                    }
                }
            }
        } else {
            $errors .= errorMesage("Please fill both date fields!");
        }
    } else {
        $errors .= errorMesage("Invalid IP address!");
    }
}
include ("templates/delete_logs_form.php");

?>