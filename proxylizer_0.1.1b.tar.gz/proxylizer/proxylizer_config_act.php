<?php
/****************************************************************************
*                                                                           *
*    MikroTik Proxylizer, Web-proxy log analyzer                            *
*    Copyright (C) 2009  MikroTik                                           *
*                                                                           *
*    This program is free software: you can redistribute it and/or modify   *
*    it under the terms of the GNU General Public License as published by   *
*    the Free Software Foundation, either version 3 of the License, or      *
*    (at your option) any later version.                                    *
*                                                                           *
*    This program is distributed in the hope that it will be useful,        *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of         *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
*    GNU General Public License for more details.                           *
*                                                                           *
*    You should have received a copy of the GNU General Public License      *
*    along with this program.  If not, see <http://www.gnu.org/licenses/>.  *
*                                                                           *
****************************************************************************/
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/index.php");
    return false;
}
if (!$db = connectDB()) {
    $errorMSG1 .= errorMesage("Failed to connect to data base!");
}
if (isset($_REQUEST['change_config'])) {
    if ($_REQUEST['main_mail'] != "") {
        $isvalidemail = ereg("^[a-zA-Z0-9_\.]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-\.]+$", $_REQUEST['main_email']);
        if($isvalidemail === false) {
            $errorMSG1 = errorMesage("Not valid e-mail address!");
            $is_error1 = true;
        }
    }
    if ($_REQUEST['maxreports'] < 1 && $_REQUEST['maxreports'] > 8) {
        $errorMSG1 = errorMesage("Not valid report count!");
        $is_error1 = true;
    }
    if (!array_key_exists($_REQUEST['del_after'], $delete_after)) {
        $errorMSG1 = errorMesage("Not valid automatic delete value!");
        $is_error1 = true;
    }
    if ($_REQUEST['colorofproxylizer'] < 1 || $_REQUEST['colorofproxylizer'] > 3) {
        $errorMSG1 = errorMesage("Not valid color of web interface!");
    }
    $change_config = array ("main_email", "maxreports", "del_after", "colorofproxylizer");
    if ($is_error1 != true) {
        insertOrUpdatePconfig($db, $change_config, $errorMSG1);
    } else {
        $_SESSION['ch_conf_error'] = $errorMSG1; 
    }
} else if (isset($_REQUEST['change_smtp'])) {
    if ($_REQUEST['from_mail'] != "") {
        $isvalidemail = ereg("^[a-zA-Z0-9_\.]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-\.]+$", $_REQUEST['from_mail']);
        if($isvalidemail === false) {
            $errorMSG1 .= errorMesage("Not valid e-mail address!");
            $is_error1 = true;
        }
    } else {
        $errorMSG2 .= errorMesage("Please type in e-mail!");
        $is_error2=true;
    }
    $_REQUEST['smtp'] = requestToQuery($_REQUEST['smtp']);
    $_REQUEST['smtp_user'] = requestToQuery($_REQUEST['smtp_user']);
    $_REQUEST['smtp_psw'] = requestToQuery($_REQUEST['smtp_psw']);
    $_REQUEST['smtp_psw2'] = requestToQuery($_REQUEST['smtp_psw2']);
    if ($_REQUEST['smtp_psw'] != $_REQUEST['smtp_psw2']) {
        $errorMSG2 .= errorMesage("SMTP passwords didnt match!");
        $is_error2=true;
    }
    $change_smtp = array("from_mail" ,"smtp", "smtp_user", "smtp_psw");
    if ($is_error2 != true) {
        insertOrUpdatePconfig($db, $change_smtp, $errorMSG2);
    }
} else if (isset($_REQUEST['change_psw'])) {
    $_REQUEST['old_login'] = requestToQuery($_REQUEST['old_login']);
    $_REQUEST['new_login'] = requestToQuery($_REQUEST['new_login']);
    if ($_REQUEST['psw'] != $_REQUEST['psw2']) {
        $errorMSG3 .= errorMesage("New passwords didn't match!");
        $is_error3 = true;
    }
    $check_psw = checkWebPaswrd($_REQUEST['psw']);
    if ($check_psw != "") {
        $errorMSG3 .= errorMesage($check_psw);
    }
    if(!checkLogin($db, $_REQUEST['old_login'], md5($_REQUEST['old_psw']))) {
        $errorMSG3 .= errorMesage("Incorrect old login or password!");
        $is_error3 = true;
    } else if ($is_error3 != true) {
        changeLoginInformation($db, $_REQUEST['new_login'], $_REQUEST['psw'], $_REQUEST['old_login'], $errorMSG3);
    }
    
} elseif (isset($_REQUEST['refresh'])) {
    $errorMSG1 = $_SESSION['ch_conf_error'];
    unset($_SESSION['ch_conf_error']);
}
getInRequestConfigValues($db);

function getInRequestConfigValues(& $db) {
global $errorMSG1;
    $query = "SELECT name, value FROM proxylizerconfig";
    $res = $db->query($query);
    if ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
        $_REQUEST[$row['name']] = $row['value'];
    } else {
        return false;
    }
    while ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
        $_REQUEST[$row['name']] = $row['value'];
    }
}

function insertOrUpdatePconfig (& $db, $fields, & $errorMSG) {
    foreach ($fields as $value) {
        $query = "INSERT INTO proxylizerconfig(name, value) VALUES ('{$value}', '{$_REQUEST[$value]}')";
        $insert = $db->query($query);
        if (PEAR::isError($insert)) {
            $query = "UPDATE proxylizerconfig SET value='{$_REQUEST[$value]}' WHERE name='{$value}'";
            $update = $db->query($query);
            if (PEAR::isError($update)) {
                $errorMSG = errorMesage("Error changing configuration parameters :" . $update->getMessage());
                return false;
            }
        }
    }
    return true;
}

function changeLoginInformation(& $db, $newlogin, $newpsw, $oldlogin, & $errorMSG) {
    $psw = md5($newpsw);
    $query = "UPDATE login SET login='{$newlogin}', passw='{$psw}' WHERE login='{$oldlogin}'";
    $update = $db->query($query);
    if (PEAR::isError($update)) {
        $errorMSG .= errorMesage("Error changing login information :" . $update->getMessage());
        return false;
    }
    return true;
}

?>