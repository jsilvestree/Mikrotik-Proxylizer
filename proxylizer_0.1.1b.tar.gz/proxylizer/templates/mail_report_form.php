<?php
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/../index.php");
    return false;
}
?>
        <form action="<?=ACTIVE_PAGE . $editordelete;?>" method="post" name="mail_report" id="mailreportform">
        <h3><?=$addorsavereport;?></h3>
            <div class="stats_box" <?=$edit_border; ?>>
            <table class="stats" >
            <tr><td>
                <table >
                    <tr>
                        <th colspan="2" style="font-size: 0.9em;">
                            <?=$errors;?>
                        </th>
                    </tr>
                    <tr>
                        <th colspan="2" align="left">
                            Report name : 
                        </th>
                    </tr>
                    <tr>
                        <td colspan="2" align="left">
                            <input size="25" type="text" name="report_name" id="report_name" 
                                value="<?=$_REQUEST['report_name']?>"/> 
                            <br/> <span style="font-size: 0.8em;">(max length, 25 chars)</span>
                        </td>
                    </tr> 
                    <tr>
                        <th colspan="2" align="left">
                            Recipient :
                        </th>
                    </tr>
                    <tr>
                        <td colspan="2">
                        <?=ipUsersSelector();?> &nbsp;&nbsp;&nbsp;
                        <input type="checkbox" name="is_sendtoadmin" id="is_sendtoadmin" <?=$CCchecked;?>/> CC to admin(s)
                        <br/><?=$no_emails;?>
                        </td>
                    </tr>
                    <tr>
                    <th colspan="2" align="left">
                        Included data :
                    </th>
                    </tr>
                    <tr>
                        <td>Report type: </td>
                        <td>
                            <?=$report_type_sbox; ?>
                        </td>
                    </tr>
                    <tr>
                        <td>Frequency : </td>
                        <td id="freq_sel_box">
                            <?=$frequencyoption;?>
                        </td>
                    </tr>
                    <tr id="datebetween" style="display: none;">
                        <td>
                            Date interval: 
                        </td>
						<td>
						    <div id="monthlyalert" style="display: none;">Only year and month is important</div>
						    <input size="12" type="text" id="date1" name="date1" value ="<?=$_REQUEST['date1'];?>"/> - 
                            <input size="12" type="text" id="date2" name="date2" value ="<?=$_REQUEST['date2'];?>"/>
                         <br/><span style="font-size: 0.8em">Format:(YYYY-MM-DD)</span>
						</td>
                    </tr>
                    <tr id="mothdaybetween" style="display: none;">
                        <td>
                            Day interval:
                        </td>
                        <td>
                            <select id="mothdays1" name="monthdays1">
                            <?=$monthdays1;?>
                            </select> - 
                            <select id="mothdays2" name="monthdays2">
                            <?=$monthdays2;?>
                            </select>
                        </td>
                    </tr>
                    <tr id="weekdaytr" style="display: none;" >
                        <td colspan="2" >
                            Weekday: 
                            <?=$weekaboutcheckboxes; ?>
						</td>
                    </tr>
                    <tr id="clocktime" style="display: none;">
                        <td>
                            Time interval:
                        </td>
						<td>
							<div>
								<input <?=$readonly;?> size="7" type="text" id="clocktimestart1" name="clocktimestart1" value="<?=$_REQUEST['clocktimestart1'];?>"/> -
								<input <?=$readonly;?> size="7" type="text" id="clocktimeend1" name="clocktimeend1" value="<?=$_REQUEST['clocktimeend1'];?>"/>
								<!--  <a onclick=""><img src="images/icons/clock__minus.png" alt=""/></a> -->
							</div>
							<div id="addedtime"><?=$addedtimeintervals;?></div>
							<a <?=$a_disable;?> onclick="addTimeInterval('addedtime')"> 
							    <img width="16" height="16" src="images/icons/clock__plus.png" title="Add time interval" alt="[+]"/> 
							</a>
						</td>
                    </tr>
                    <tr id="ip_selector_tr">
                        <td>IP : </td>
                        <td>
                            <?=ipSelector(false, $disabled);?>
                        </td>
                    </tr>
                    <tr>
                        <td>Domain : </td>
                        <td>
                            <input <?=$readonly;?> size="7" type="text" name="subdomain" value="<?=$_REQUEST['subdomain'];?>"/> .
                            <input <?=$readonly;?> size="7" type="text" name="domain" value="<?=$_REQUEST['domain'];?>"/> .
                            <input <?=$readonly;?> align="right" size="7" type="text" name="topdomain" value="<?=$_REQUEST['topdomain'];?>"/>
                        </td>
                    </tr>
                    <tr>
                        <td>Top : </td>
                        <td><select name="top">
                            <?=$topoption;?>
                        </select>
                        </td>
                    </tr>
                    <tr>
                        <th colspan="2" style="">
                            Generate time :
                        </th>
                    </tr>
                    <tr id="noworlater" style="display: none;">
                        <td colspan="2">
                            <input type="radio" name="noworlater" value="now" id="now" <?=$_REQUEST['noworlater'] == "now" ? "checked=\"checked\"" : "";?>
                            onclick="showHideNowOrLater('0','now')"/> Generate now &nbsp;&nbsp;<br/>
                            <input type="radio" name="noworlater" value="later" id="later" <?=$_REQUEST['noworlater'] == "later" ? "checked=\"checked\"" : "";?>
                            onclick="showHideNowOrLater('0','later')"/> Generate later &nbsp;&nbsp;
                        </td>
                    </tr>
                    <tr id="dateone" style="display: none;">
                        <td>
                            Date :
                        </td>
                        <td>
                            <input size="7" type="text" name="datelater" id="datelater" value="<?=$_REQUEST['datelater'] ?>"/>
                            <br/><span style="font-size: 0.8em">Format:(YYYY-MM-DD)</span>
                        </td>
                    </tr>
                    <tr id="monthday"  style="display: none;">
                        <td>
                            Monthday :
                        </td>
                        <td> 
                            <select id="monthdayoption" name="monthdayoption">
                                <?=$monthdayoption;?>
                            </select>
                        </td>
                    </tr>
                    <tr id="weekdayonewhen" style="display: none;">
                        <td>
                            Weekday :
                        </td>
                        <td> 
                            <select id="weekdayoption" name="weekdayoption">
                            <?=$weekdayoption;?>
                            </select>
                        </td>
                    </tr>
                    
                    <tr id="clocktime2" style="display: none;">
                        <td>
                            Generate time :
                        </td>
                        <td> 
                            <input size="7" type="text" id="clocktime2input" name="clocktime2input" value="<?=$_REQUEST['clocktime2input'] ?>"/>                        </td>
                    </tr>
                    <tr class="disabled">
                        <td></td>
                        <td style='text-align: right;'>
                            <?=$cancelbutton; ?>
                            <input type="submit" name="<?=$addorsavereportname;?>" value="<?=$addorsavereportvalue;?>"/>
                            <!--  <input type="submit" name="<?=$add_saveandpreviewname;?>" value="<?=$add_saveandpreviewvalue;?>"/> -->
                        </td>
                    </tr>
                </table>
                </td></tr>
            </table>
            </div>
        </form>
        <?=$counter_for_javascript;?>
    