<?php
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/../index.php");
    return false;
}
?>
        <div style="font-size: 1.1em; font-weight: bold;"><?=$errorMSG1;?> </div>
        <h3> &nbsp;Proxylizer config :</h3>
        <form action="<?=ACTIVE_PAGE;?>" method="post" name="config_form">
            <br/>
            <table>
                <tr>
                    <td width="200" align="right">
                        Admin e-mail :
                    </td>
                    <td width="200">
                        <input type="text" name="main_email" id="main_email" value="<?=$_REQUEST['main_email'] ?>"/>
                        <img title="All error and warning mesages will be sent to this email" id="question_sign" src="images/icons/question_small.png" alt="tip"/>
                    </td>
                </tr>
                
                <tr>
                    <td width="200" align="right">
                        Max simultaneous reports : 
                    </td>
                    <td width="200">
                        <?=$sel_gen_rep_count;?>
                    </td>
                </tr>
                <tr>
                    <td width="200" align="right">
                        Purge reports older than :
                    </td>
                    <td width="200">
                        <?=$sel_del_after;?>
                    </td>
                </tr>
                <tr>
                    <td width="200" align="right">
                        Color of web interface:
                    </td>
                    <td>
                        <div>
                            <input type="radio" name="colorofproxylizer" value="1" style="float: left;" <?=$_REQUEST['colorofproxylizer']==1?"checked=\"checked\"":""?>/>
                            <div style="background-color: #C1CE96; width: 100px; float: left; margin:0 0 2px 5px;">&nbsp;</div>
                        </div>
                        <div style="clear: both;">
                            <input type="radio" name="colorofproxylizer" value="2" style="float: left;" <?=$_REQUEST['colorofproxylizer']==2?"checked=\"checked\"":""?>/>
                            <div style="background-color: #B64926; width: 100px; float: left; margin:0 0 2px 5px;">&nbsp;</div>
                        </div>
                        <div style="clear: both;">
                            <input type="radio" name="colorofproxylizer" value="3" style="float: left;" <?=$_REQUEST['colorofproxylizer']==3?"checked=\"checked\"":""?>>
                            <div style="background-color: #3C89DB; width: 100px; float: left;margin:2px 0 2px 5px;">&nbsp;</div>
                            </div>
                    </td>
                </tr>
                <tr>
                    <td width="200"></td>
                    <td width="200">
                        <input type="submit" name="change_config" value="Submit"/>
                    </td>
                </tr>
            </table>
            
        </form>