<?php
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/../index.php");
    return false;
}
?>
    <div id="setupcontent" align="center">
        <form action="index.php" method="POST" name="configfrm">
        <div style='color: #FF0000; font-weight: bold;'><?=$msg;?></div>
        <table border="0" height="120" class='std' cellspacing="1" cellpadding="4">
            <tr>
                <th colspan="2">Data Base parameters</th>
            </tr>
            <tr>
                <td align ="center">DB type:</td>
                <td><select style="width : 100%" name="dbtype">
                <?=$dboption;?>
                </select>
                </td>
            </tr>
            <tr>
                <td align ="center">DB host:</td>
                <td><input type="text" name="dbhost" value="<?=$dbhost;?>"></td>
                <td><font size="-3">*</font></td>
            </tr>
            <tr>
                <td align ="center">DB name:</td>
                <td><input type="text" name="dbname" value="<?=$dbname;?>"></td>
                <td><font size="-3">*</font></td>
            </tr>
            <tr>
                <td align ="center">DB username:</td>
                <td><input type="text" name="dbusername" value="<?=$dbusername;?>"></td >
                <td><font size="-3">*</font></td>
            </tr>
            <tr>
                <td align ="center">DB password:</td>
                <td><input type="password" name="paswrd"></td>
            </tr>
            <tr>
                <td align ="center">Confirm DB password:</td>
                <td><input type="password" name="paswrd2"></td>
            </tr>
            <tr>
                <th colspan="2">Create webpage user</th>
            </tr>
            <tr>
                <td align ="center">Webpage username:</td>
                <td><input type="text" name="webusername" value="<?=$webusername;?>"></td >
                <td><font size="-3">*</font></td>
            </tr>
            <tr>
                <td align ="center">Webpage password:</td>
                <td><input type="password" name="webpaswrd"></td>
                <td><font size="-3">*</font></td>
            </tr>
            <tr>
                <td align ="center">Confirm webpage password:</td>
                <td><input type="password" name="webpaswrd2"></td>
                <td><font size="-3">*</font></td>
            </tr>
            <tr>
                <td colspan="2" align="right"><input type="submit" name="submit" value="Submit"></td>
            </tr>
        </table>
        </form>
    </div> <!-- EOF setupcontent -->