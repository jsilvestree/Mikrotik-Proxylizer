<?php
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/../index.php");
    return false;
}
?>
        <div style="font-size: 1.1em; font-weight: bold;"><?=$errorMSG2;?> </div>
        <h3> &nbsp;Mail server configuration :</h3>
        <form method="post" action="<?=ACTIVE_PAGE;?>" name="mail_config">
        <br/>
        <table>
            <tr>
                <td width="200" align="right">
                    E-mail : 
                </td>
                <td>
                    <input type="text" name="from_mail" id="from_mail" value="<?=$_REQUEST['from_mail'];?>"/>
                </td>
            </tr>
            <tr>
                <td width="200" align="right">
                    SMTP server :
                </td>
                <td width="200">
                    <input type="text" name="smtp" id="smtp" value="<?=$_REQUEST['smtp'];?>"/>
                </td>
            </tr>
            <tr>
                <td width="200" align="right">
                    SMTP username : 
                </td>
                <td width="200">
                    <input type="text" name="smtp_user" id="smtp_user" value="<?=$_REQUEST['smtp_user'];?>"/>
                </td>
            </tr>
            <tr>
                <td width="200" align="right">
                    SMTP password : 
                </td>
                <td width="200">
                    <input type="password" name="smtp_psw" id="smtp_psw"/>
                </td>
            </tr>
            <tr>
                <td width="200" align="right">
                    SMTP password<br/> confirm : 
                </td>
                <td width="200">
                    <input type="password" name="smtp_psw2" id="smtp_psw2"/>
                </td>
            </tr>
            <tr>
                <td width="200"> </td>
                <td width="200">
                    <input type="submit" name="change_smtp" value="Submit">
                </td>
            </tr>
        </table>
        </form>