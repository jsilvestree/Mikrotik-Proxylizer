<?php
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/../index.php");
    return false;
}
?>
        <div style="font-size: 1.1em; font-weight: bold;"><?=$errorMSG3;?> </div>
        <h3> &nbsp;Change login information :</h3>
        <br/>
        <form method="post" action="<?=ACTIVE_PAGE;?>">
        <table>
            <tr>
                <td width="200" align="right">
                    Old login :
                </td>
                <td width="200">
                    <input type="text" name="old_login" id="old_login" value="<?=$_REQUEST['old_login'];?>"/>
                </td>
            </tr>
            <tr>
                <td width="200" align="right">
                    Old password :
                </td>
                <td width="200">
                    <input type="password" name="old_psw"/>
                </td>
            </tr>
            <tr>
                <td width="200" align="right">
                    New login :
                </td>
                <td width="200">
                    <input type="text" name="new_login" id="new_login" value="<?=$_REQUEST['new_login'];?>"/>
                </td>
            </tr>
            <tr>
                <td width="200" align="right">
                    New password :
                </td>
                <td width="200">
                    <input type="password" name="psw"/>
                </td>
            </tr>
            <tr>
                <td width="200" align="right">
                    New password confirm :
                </td>
                <td width="200">
                    <input type="password" name="psw2"/>
                </td>
            </tr>
            <tr>
                <td width="200">
                </td>
                <td width="200">
                    <input type="submit" name="change_psw" value="Submit"/>
                </td>
            </tr>
        </table>
        </form>