<?php
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/../index.php");
    return false;
}
?>
    <form action="<?=ACTIVE_PAGE;?>" method="post" name="report3" onsubmit="return reallyDelete();">
    
    <h3>Delete records</h3>
    <table align="center">
        
        <tr>
            <td colspan="4" >
                <?=$errors; ?>
            </td>
        </tr>
        <tr>
            <td style="width : 150px" colspan="3" align="center"> Date </td>
            <td style="width : 150px" align="center"> IP </td>
        </tr>
        <tr>
            <td><input size="15" type="text" id="datetime1" name="datetime1" value ="<?=$_REQUEST['datetime1'];?>"/></td><td> - </td>
            <td><input size="15" type="text" id="datetime2" name="datetime2" value ="<?=$_REQUEST['datetime2'];?>"/></td>
            <td><input size="15" type="text" name="IP" value="<?=$_REQUEST['IP'];?>"/></td>
            <td><input size="15" type="submit" name="delete" value="Delete"/></td>
        </tr>
        <tr>
            <td colspan="4"><span style="font-size: 1.1em; font-weight: bold;"><?=$result; ?></span></td>
        </tr>
    </table> <br/>
    </form>
    <script type="text/javascript">
        var popupcalendar;
        function initCalendar () {
            popupcalendar = new Epoch('cal','popup',document.getElementById('datetime1'),false);
            popupcalendar2 = new Epoch('cal','popup',document.getElementById('datetime2'),false);
        }
    addLoadEvent(initCalendar);
    </script>