<?php
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/../index.php");
    return false;
}
if (!getStyle()) {
    $style = 'style_1.css';
} else {
    $style = getStyle();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>MikroTik Proxylizer</title> 
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <link rel="stylesheet" href=<?=$style;?>?a=1" type="text/css"/> 
    <link rel="stylesheet" href="calendar/epoch_styles.css?a=1" type="text/css"/> 
    <script type="text/javascript" src="main.js?a=1"></script> 
    <script type="text/javascript" src="calendar/epoch_classes.js?a=1"></script> 
    <script type="text/javascript" src="ajax.js?a=1"></script> 
    <!--[if IE 6]><link rel="stylesheet" href="ie6main.css?a=1" type="text/css"/><![endif]-->
</head>

<body>
<div id="canvas">
    <div id="topspacer">
        &nbsp; <!--  -->
    </div>
 