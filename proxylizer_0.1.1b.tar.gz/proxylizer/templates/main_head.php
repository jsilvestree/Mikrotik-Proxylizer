<?php
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/../index.php");
    return false;
}
?>
    <div id="container">
        <div class="head">
            <span id="links">
                <a href="?action=adm_panel" <?=($action == "adm_panel" ? "id=\"selected\"" : "");?> >Status</a> &gt; 
                <a href="?action=mail_report" <?=($action == "mail_report" ? "id=\"selected\"" : "");?> >Reports</a> &gt;
                <a href="?action=ip_users" <?=($action == "ip_users" ? "id=\"selected\"" : "");?> >IP users</a> &gt;
                <a href="?action=config" <?=($action == "config" ? "id=\"selected\"" : "") ?> > Config</a> 
            </span>
            <div class="logout">
                <a title="Log out" onclick="goTo('logout')">&nbsp;</a>
            </div>
        </div>
    
    <div id="content">