<?php
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/../index.php");
    return false;
}
?>
    <div id="setupcontent">
        <table>
            <tr>
                <td>
                    <div><?=$createdDB;?></div>
                </td>
            </tr>
            <tr>
                <td>
                    <div><?=$createdTables;?></div>
                </td>
            </tr>
            <tr>
                <td>
                    <div><?=$createdIndices;?></div>
                </td>
            </tr>
            <tr>
                <td>
                    <div><?=$createdForeignKeys;?></div>
                </td>
            </tr>
            <tr>
                <td>
                    <div><?=$miscTableChanges;?></div>
                    <br/><br/><br/><br/><br/><br/><br/><br/>
                </td>
            </tr>
            <tr>
                <td align="center">
                    <div><b>Setup complete! Please click <a style="color: #FF0000" href="index.php">here</a> to proceed!</b></div>
                </td>
            </tr>
        </table>
    </div> <!-- EOF setupcontent -->