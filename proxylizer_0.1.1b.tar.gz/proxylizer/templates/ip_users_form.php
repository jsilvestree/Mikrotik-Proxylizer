<?php
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/../index.php");
    return false;
}
?>
    <form action="<?=ACTIVE_PAGE . $editordelete;?>" method="post" name="ipusersform" id="ipusersform">
    <h3>IP Users : <?=$addorsaveuser;?></h3>
    
    <blockquote class="tip" style="display: none;">
    	This form is for adding a new user that will receive the proxy reports
    </blockquote>

    <table>
    <tr><td>
        <div class="stats_box">
        <table class="stats">
        <tr><td>
            <table>
                <tr>
                    <th colspan="2" style="font-size: 0.9em;">
                        <?=$errors;?>
                    </th>
                </tr>
                <tr>
                    <td style="border-bottom: none; padding-bottom: 0px;">
                        IP :
                    </td>
                    <td style="border-bottom: none">
                    <?=ipSelector(true);?>
                    </td>
                </tr>
                <tr>
                    <td style="border-bottom: none; padding-bottom: 0px;">
                        Name : 
                    </td>
                    <td style="border-bottom: none; padding-bottom: 0px;">
                        <input type="text" name="name" id="name" value="<?=$_REQUEST['name'];?>"/>
                    </td>
                </tr>
                <tr>
                    <td style="border-bottom: none; padding-bottom: 0px;">
                        E-mail : 
                    </td>
                    <td style="border-bottom: none; padding-bottom: 0px;">
                        <input type="text" name="e-mail" id="e-mail" value="<?=$_REQUEST['e-mail'];?>"/>
                    </td>
                </tr>
                <tr>
                    <td style="border-bottom: none; padding-bottom: 0px;">
                        Admin : 
                    </td>
                    <td style="border-bottom: none; padding-bottom: 0px;">
                        <input type="checkbox" name="isadmin" id="isadmin" <?=$checked;?>/>
                    </td>
                </tr>
                <tr>
                    <td>
                        User receives <br/> empty reports :
                    </td>
                    <td>
                        <input type="checkbox" name="empty_report" id="empty_report" <?=$checked2;?>/>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" style="text-align: right; border-bottom: none; padding-bottom: 0px;">
                        <?=$cancelbutton;?>
                        <input type="submit" name="<?=$addorsavename;?>" value="<?=$addorsavevalue;?>"/>
                    </td>
                </tr>
            </table>
            </div>
        </td></tr>
        </table>
    </td></tr>
    </table>