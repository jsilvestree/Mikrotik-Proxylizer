<?php
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/../index.php");
    return false;
}
?>
    <div id="setupcontent">
        <form action="index.php" method="POST" name="dropornot">
        <table>
        <tr>
            <td align="center">
            <b>Incorrect tables detected: <?=$errTables;?>! Do you want to DROP <?=$dropTarget;?>?<br /></b>
            </td>
        </tr>
        <tr>
            <td align="center">
                <input type="hidden" name="dbtype" value="<?=$dbtype;?>" />
                <input type="hidden" name="dbhost" value="<?=$dbhost;?>" />
                <input type="hidden" name="dbname" value="<?=$dbname;?>" />
                <input type="hidden" name="paswrd" value="<?=$paswrd;?>" />
                <input type="hidden" name="dbusername" value="<?=$dbusername;?>" />
                <input type="hidden" name="webusername" value="<?=$webusername;?>" />
                <input type="submit" name="droptable" value="DROP TABLE" />
                <input type="submit" name="changeparams" value="Change DB parameters" />
            </td>
        </tr>
        </table>
        </form>
    </div>