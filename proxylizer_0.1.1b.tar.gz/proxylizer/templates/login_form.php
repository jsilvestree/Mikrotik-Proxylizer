<?php
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/../index.php");
    return false;
}
?>
    <div id="logincontent">
        <img src="images/mtlogo.png" style="margin-bottom: 35px;" alt="" class="mtlogologin"/>
        <div align="center" style='color: #FF0000; font-weight: bold;font-size: 1.2em; visibility: visible;'>
            <?=$msg;?>
        </div>
        <form action="index.php" method="post" name="loginfrm">
            <input name="username" size="10" maxlength="30" style="font-size: 2em; visibility: visible;"/> <br/><br/>
            <input name="paswrd" size="10" maxlength="50" style="font-size: 2em; visibility: visible;" type="password"/> <br/>
            <input style="margin-top: 25px; width: 100px; height: 30px" name="submit" value=" Log in " type="submit"/> 
        </form>
        <!--<p class="smallsub"><a href="#">forgot password?</a></p> -->
    </div>
