<?php
/****************************************************************************
*                                                                           *
*    MikroTik Proxylizer, Web-proxy log analyzer                            *
*    Copyright (C) 2009  MikroTik                                           *
*                                                                           *
*    This program is free software: you can redistribute it and/or modify   *
*    it under the terms of the GNU General Public License as published by   *
*    the Free Software Foundation, either version 3 of the License, or      *
*    (at your option) any later version.                                    *
*                                                                           *
*    This program is distributed in the hope that it will be useful,        *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of         *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
*    GNU General Public License for more details.                           *
*                                                                           *
*    You should have received a copy of the GNU General Public License      *
*    along with this program.  If not, see <http://www.gnu.org/licenses/>.  *
*                                                                           *
****************************************************************************/
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/index.php");
    return false;
}
define("DBTYPE_INNO_DB", 1);
define("DBTYPE_MYISAM", 2);

define("TC_TABLE_OK", 1);
define("TC_INDEX_OK", 2);
define("TC_FK_OK", 4);

class TableField {
    var $name;
    var $type;
    var $notNull;
    var $isAutoIncrement;
    var $default;

    public function __construct($name, $type, $notNull = false, $autoInc = false, $default = null) {
        $this->name = $name;
        $this->type = $type;
        $this->notNull = $notNull;
        $this->isAutoIncrement = $autoInc;
        $this->default = $default;
    }
    
    public function getCreateStatement($useComma = true) {
        $notNull = $this->notNull ? " NOT NULL" : "";
        $default = $this->default === null ? "" : " DEFAULT {$this->default}";
        $autoInc = $this->isAutoIncrement ? " auto_increment" : "";
        $comma = $useComma ? "," : "";
        return "  {$this->name} {$this->type}{$notNull}{$default}{$autoInc}{$comma}\n";
    }
}

class TableIndex {
    var $table;
    var $fields;
    var $isUnique;
    
    public function __construct(& $table, $fields, $isUnique) {
        $this->table = $table;
        $this->fields = is_array($fields) ? $fields : null;
        $this->isUnique = $isUnique;
    }

    public function getCreateStatement() {
        // glue field names
        $fieldNames = array();
        foreach ($this->fields as $f) {
            array_push($fieldNames, $f->name);
        }
        $underlineSeparatedFields = implode("_", $fieldNames);
        $commaSeparatedFields = implode(", ", $fieldNames);

        $tblname = $this->table->name;
        $indexName = "{$tblname}_${underlineSeparatedFields}";
        $unique = $this->isUnique ? "UNIQUE " : "";
        
        return "CREATE {$unique}INDEX {$indexName} USING BTREE ON {$tblname} "
            . "({$commaSeparatedFields});\n";
    }
}

class ForeignKey {
    var $from_table;
    var $from_field;
    var $to_table;
    var $to_field;
    
    public function __construct(& $from_table,& $from_field, & $to_table,& $to_field) {
        $this->from_table = $from_table;
        $this->from_field = $from_field;
        $this->to_table = $to_table;
        $this->to_field = $to_field;
    }
    
    public function getCreateStatement() {
        $from_tbl_name = $this->from_table->name;
        $to_tbl_name = $this->to_table->name;
        return "ALTER TABLE {$from_tbl_name} ADD FOREIGN KEY ({$this->from_field->name})" 
        . " REFERENCES {$to_tbl_name}( {$this->to_field->name} );\n";
    }
}

class Table {
    var $name;
    var $type;
    var $fields;
    var $indices;
    var $primaryKey;
    var $charset;
    var $foreignkey;

    public function __construct($name, $type = DBTYPE_INNO_DB, $charset = "utf8") {
        $this->name = $name;
        $this->type = $type;
        $this->charset = $charset;
        $this->fields = array();
        $this->indices = array();
        $this->primaryKey = null;
        $this->foreignkeys = array();
    }

    public function addField(& $field, $isPrimaryKey = false) {
        array_push($this->fields, $field);
        if ($isPrimaryKey) $this->setPrimaryKey($field);
    }

    public function addIndex(& $index) {
        array_push($this->indices, $index);
    }

    public function addForeignKey(& $foreignkey) {
        array_push($this->foreignkeys, $foreignkey);
    }
    
    public function setPrimaryKey(& $field) {
        $this->primaryKey = $field;
    }

    private function getPrimaryKeyStatement() {
        if ($this->primaryKey == null) return "";
        return "  PRIMARY KEY ({$this->primaryKey->name})\n";
    }

    public function getCreateStatement() {
        $fieldDef = "";
        $fieldCount = count($this->fields);
        $primaryKeyDef = $this->getPrimaryKeyStatement();
        for ($i = 0; $i < $fieldCount; ++$i) {
            $f = & $this->fields[$i];
            $useComma = $primaryKeyDef != "" || $i < $fieldCount - 1;
            $fieldDef .= $f->getCreateStatement($useComma);
        }
        $primaryKeyDef = $this->getPrimaryKeyStatement();
        $engine = $this->type == DBTYPE_MY_ISAM ? "MyIssam" : "InnoDB";

    return "CREATE TABLE {$this->name} (\n"
        . "{$fieldDef}"
        . "{$primaryKeyDef}"
        . ") ENGINE={$engine} DEFAULT CHARSET={$this->charset};\n";
    }
    
    public function checkField ($name, $type) {
        $fieldCount = count($this->fields);
        for ($i = 0; $i < $fieldCount; $i++) {
            $f = $this->fields[$i];
            if ($f->name == $name && $f->type == $type) {
                return true;
            }
        }
        return false;
    }
    
    public function checkFieldCount() {
        return $fieldCount = count($this->fields);
    }
    
    public function isCorrupted() {
        global $db;
        $query = "EXPLAIN {$this->name}";
        $is_table = & $db -> query($query);
        if (PEAR::isError($is_table)) {
            $message = $is_table->getMessage();
            if ($message == "DB Error: no such table") {
                return !$this->create($createRes);
            } else {
                return true;
            }
        } else {
            $res =& $db->query($query);
            if (PEAR::isError($res)) {
                return true;
            } else {
                while ($row =& $res->fetchRow()) {
                    $counter++;
                    if (!$this->checkField($row[0], $row[1])) {
                        return true;
                    }
                }
                return $this->checkFieldCount() != $counter;
            }
        }
    }
    
    public function create(& $result) {
        global $db;
        $query = $this->getCreateStatement();
        $createtable = & $db-> query($query);
        if (PEAR::isError($createtable)) {
            echo $createtable->getMessage();
            return false;
        }
        $result = TC_TABLE_OK;
        $indexcreated = false;
        foreach ($this->indices as & $index) {
            $query2 = $index->getCreateStatement();
            $createindices = & $db->query($query2);
            if (PEAR::isError($createindices)) {
                return false;
            } 
            $indexcreated = true;
        }
        if ($indexcreated === true) $result += TC_INDEX_OK;
        return true;        
    }
    
    public function createForKey(& $result) {
        global $db;
        $for_keycreated = false;
        foreach ($this->foreignkeys as $for_key) {
            $query3 = $for_key->getCreateStatement();
            $createforkey = & $db->query($query3);
            if (PEAR::isError($createforkey)) {
                return false;
            }
            $for_keycreated = true;
        }
        if($for_keycreated === true) $result = TC_FK_OK;
        return true;
    }

    public function drop() {
        global $db;
        $query = "DROP TABLE {$this->name}";
        $res = & $db->query($query);
        //return !PEAR::isError($res);
        //echo "$query<br/>\n";
        return true;
    }
}
?>