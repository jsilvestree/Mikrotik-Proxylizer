/****************************************************************************
*                                                                           *
*    MikroTik Proxylizer, Web-proxy log analyzer                            *
*    Copyright (C) 2009  MikroTik                                           *
*                                                                           *
*    This program is free software: you can redistribute it and/or modify   *
*    it under the terms of the GNU General Public License as published by   *
*    the Free Software Foundation, either version 3 of the License, or      *
*    (at your option) any later version.                                    *
*                                                                           *
*    This program is distributed in the hope that it will be useful,        *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of         *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
*    GNU General Public License for more details.                           *
*                                                                           *
*    You should have received a copy of the GNU General Public License      *
*    along with this program.  If not, see <http://www.gnu.org/licenses/>.  *
*                                                                           *
****************************************************************************/
function goTo(action) {
    document.location = document.location.pathname + "?action=" + action;
}
function filterIP(ip) {
    var ipfield = document.getElementById("report3IP");
    if (ipfield) ipfield.value = ip;
    var form = document.getElementById("report3form");
    if (form) form.submit();
}

function setSelectFieldValue(selid, value, formid) {
    var sel = document.getElementById(selid);
    if (!sel) return;
    for (var index = 0; index < sel.length; ++index) {
        if (sel[index].value == value) {
            sel.selectedIndex = index;
            break;
        }
    }
    var form = document.getElementById(formid);
    if (form) form.submit();
}

function doNotUnCheckAll (allcheckid, checkboxid,alertdivid) {
    var allcheck=document.getElementById(allcheckid);
    if (!allcheck) return;
    var checkbox=document.getElementById(checkboxid);
    if (!checkbox) return;
    var alrtdiv=document.getElementById(alertdivid);
    if (!alrtdiv) return;
    var i = 0;
    for (var index = 0; index < allcheck.childNodes.length; ++index) {
        if (allcheck.childNodes[index].type && allcheck.childNodes[index].type == "checkbox") {
            if(allcheck.childNodes[index].checked != false){
                i++;
                
            }
        }
    }
    if (i == 0) {
        checkbox.checked = true;
        alrtdiv.innerHTML = "At least on weekday must be checked!";        
    } else {
        alrtdiv.innerHTML = "";
    }
}
var popupcalendar1=null;
var popupcalendar2=null;
var popupcalendar3=null;
var popupcalendar4=null;
var popupcalendar5=null;

function showHideOptions(selid) {
    var sel=document.getElementById(selid);
    if (!sel) return;
    var datebetween=document.getElementById("datebetween")
    if (!datebetween) return;
    var monthdaybetween = document.getElementById("mothdaybetween")
    if (!monthdaybetween) return;
    var weekday=document.getElementById("weekdaytr")
    if (!weekday) return;
    var clocktime=document.getElementById("clocktime")
    if (!clocktime) return;
    var clocktime2=document.getElementById("clocktime2")
    if (!clocktime2) return;
    var weekdayone=document.getElementById("weekdayonewhen")
    if (!weekdayone) return;
    var monthday=document.getElementById("monthday")
    if (!monthday) return;
    var dateone=document.getElementById("dateone")
    if (!dateone) return;
    var noworlater=document.getElementById("noworlater")
    if (!noworlater) return;
    var radio1 = document.getElementById("now");
    if(!radio1) return;
    var radio2 = document.getElementById("later");
    if(!radio2) return;
    var monthalert = document.getElementById("monthlyalert");
    if(!monthalert) return;
    var value = sel.value;
    switch (value) {
        case "0":
            datebetween.style.display="";
            if(popupcalendar1 == null) {
                popupcalendar1 = new Epoch('cal1','popup',document.getElementById('date1'),false);
            }
            if(popupcalendar2 == null) {
                popupcalendar2 = new Epoch('cal2','popup',document.getElementById('date2'),false);
            }
            last_format="Y-m-d";
            monthdaybetween.style.display="none";
            weekday.style.display="";
            clocktime.style.display="";
            monthalert.style.display="none";
            //when
            noworlater.style.display="";
            dateone.style.display="none";
            monthday.style.display="none";
            weekdayone.style.display="none";
            clocktime2.style.display="none";
            for (i=0;i<document.mail_report.noworlater.length;i++){
                if (document.mail_report.noworlater[i].checked){
                    var nowlater = document.mail_report.noworlater[i].value;
                }
            }
            if(nowlater == "later") {
                radio2.checked=true;
                showHideNowOrLater('0','later');  
            } else if (nowlater == "now") {
                radio1.checked=true;
                showHideNowOrLater('0','now');
            }
            break;
        case "1":
            datebetween.style.display="";
            if(popupcalendar1 == null) {
                popupcalendar1 = new Epoch('cal1','popup',document.getElementById('date1'),false);
            }
            if(popupcalendar2 == null) {
                popupcalendar2 = new Epoch('cal2','popup',document.getElementById('date2'),false);
            }
            monthdaybetween.style.display="none";
            weekday.style.display="";
            clocktime.style.display="";
            monthalert.style.display="none";
            last_format="Y-m-d";
            //when
            noworlater.style.display="none";
            dateone.style.display="none";
            monthday.style.display="none";
            weekdayone.style.display="none";
            clocktime2.style.display="";
            break;
        case "2":
            datebetween.style.display="";
            if(popupcalendar1 == null) {
                popupcalendar1 = new Epoch('cal1','popup',document.getElementById('date1'),false);
            }
            if(popupcalendar2 == null) {
                popupcalendar2 = new Epoch('cal2','popup',document.getElementById('date2'),false);
            }
            last_format="Y-m-d";
            monthdaybetween.style.display="none";
            weekday.style.display="";
            clocktime.style.display="";
            monthalert.style.display="none";
            //when
            noworlater.style.display="none";
            dateone.style.display="none";
            monthday.style.display="none";
            weekdayone.style.display="";
            clocktime2.style.display="";
            break;
        case "3":
            datebetween.style.display="";
            if(popupcalendar1 == null) {
                popupcalendar1 = new Epoch('cal1','popup',document.getElementById('date1'),false);
            }
            if(popupcalendar2 == null) {
                popupcalendar2 = new Epoch('cal2','popup',document.getElementById('date2'),false);
            }
            last_format="Y-m";
            monthdaybetween.style.display="";
            weekday.style.display="";
            clocktime.style.display="";
            monthalert.style.display="";
            //when
            noworlater.style.display="none";
            dateone.style.display="none";
            monthday.style.display="";
            weekdayone.style.display="none";
            clocktime2.style.display="";
            break;
    }
}

function showHideNowOrLater(frequency, value) {
    var radio = document.getElementById(value);
    if(!radio) return;
    var dateone=document.getElementById("dateone");
    if (!dateone) return;
    var clocktime2=document.getElementById("clocktime2");
    if (!clocktime2) return;
    if (frequency=="0") {
	    switch (value) {
	        case "now":
	            dateone.style.display="none";
	            clocktime2.style.display="none";
	            break;
	        case "later":
	            dateone.style.display="";
	            if(popupcalendar5 == null) {
	            	var datelater = document.getElementById('datelater');
	            	if (!datelater) return;
	                popupcalendar5 = new Epoch('cal5','popup',datelater ,false);
	            }
	            clocktime2.style.display="";
	            break;
	    }
    }
}
var freqoldsel = 1;
var freqselbox = new Array ;
freqselbox[2] = "daily \n <input type='hidden' id='frequency' name='frequency' value='1'/>";

function showHideReportType(objid) {
    var sel = document.getElementById(objid);
    if (!sel) return;
    freqselbox[freqoldsel] = document.getElementById('freq_sel_box').innerHTML;
    freqoldsel = sel.value;
    if (sel.value == '2') {
        document.getElementById('ip_selector_tr').style.display="none";
        document.getElementById('freq_sel_box').innerHTML = freqselbox[2];
        document.getElementById('noworlater').style.display="none";
        document.getElementById('weekdayonewhen').style.display="none";
        document.getElementById('monthday').style.display="none";
        document.getElementById('dateone').style.display="none";
        document.getElementById('clocktime2').style.display="";
    } else {
        document.getElementById('ip_selector_tr').style.display="";
        document.getElementById('freq_sel_box').innerHTML = freqselbox[1];
        showHideOptions('frequency');
    }
}

var counter=1;
function addTimeInterval(objid) {
    var divid=document.getElementById(objid);
    if(!divid) { 
        return;
    } else {
        counter++;
        var currentspan = counter
        var childNode = document.createElement("span");
        childNode.setAttribute("id", "addedtime"+counter);
        divid.appendChild(childNode);
        childNode.innerHTML = "<input size=\"7\" type=\"text\" id=\"clocktimestart"+counter+"\" \n" + 
                            "name=\"clocktimestart"+counter+"\"/> - <input size=\"7\" type=\"text\" \n"+ 
                            "id=\"clocktimeend"+counter+"\" name=\"clocktimeend"+counter+"\"/>\n"+ 
                            "<a onclick=\"removeTimeInterval('addedtime','"+currentspan+"')\">\n"+ 
                            "<img src=\"images/icons/clock__minus.png\" title=\"Remove time interval\""+ 
                            "alt=\"[-]\"/></a><br/>\n";
    }
}

function removeTimeInterval(objid,current) {
    var divid=document.getElementById(objid);
    if (!divid) {
        return;
    } else {
        var spanid=document.getElementById("addedtime"+current);
        if (!spanid) {
            return;
        } else {
            divid.removeChild(spanid);
        }
    }
}

function addLoadEvent(func) {
    var oldonload = window.onload;
    if (typeof window.onload != 'function') {
        window.onload = func;
    } else {
        window.onload = function() {
            if (oldonload) {
                oldonload();
            }
            func;
        }
    }
}

function reallyDelete() {
	return confirm('Action can\'t be reverted! Do you realy wan\'t to delete?');
}

//http://www.netlobo.com/wom.html;

function womOn(){
  window.onload = womGo;
}

function womGo(){
  for(var i = 0;i < woms.length;i++)
    eval(woms[i]);
}

function womAdd(func){
  woms[woms.length] = func;
}


var woms = new Array();