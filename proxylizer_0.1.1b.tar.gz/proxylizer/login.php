<?php
/****************************************************************************
*                                                                           *
*    MikroTik Proxylizer, Web-proxy log analyzer                            *
*    Copyright (C) 2009  MikroTik                                           *
*                                                                           *
*    This program is free software: you can redistribute it and/or modify   *
*    it under the terms of the GNU General Public License as published by   *
*    the Free Software Foundation, either version 3 of the License, or      *
*    (at your option) any later version.                                    *
*                                                                           *
*    This program is distributed in the hope that it will be useful,        *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of         *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
*    GNU General Public License for more details.                           *
*                                                                           *
*    You should have received a copy of the GNU General Public License      *
*    along with this program.  If not, see <http://www.gnu.org/licenses/>.  *
*                                                                           *
****************************************************************************/
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/index.php");
    return false;
}

$login = requestToQuery($_REQUEST['username']);
$pwd = md5($_REQUEST['paswrd']);

$DBpaswrd = $config_const['DB_PASSWORD'];
if ($DBpaswrd != "") $DBpaswrd = ":" . $DBpaswrd;

require_once 'DB.php';
$dsn = "{$config_const['DB_TYPE']}://{$config_const['DB_USERNAME']}{$DBpaswrd}@{$config_const['DB_HOST']}/{$config_const['DB_NAME']}";
$options = array(
    'debug'       => 2,
    'portability' => DB_PORTABILITY_ALL,
);
if (isset($_SESSION['logged'])) {
    if ($action == "logout") {
        unset($_SESSION['logged']);
        session_destroy();
        loginForm("You have logged out");
        return false;
    } else {
        return true;
    }

}
if (!isset($_REQUEST['username'])) {
    loginForm("");
    return false;
} else {
    $db = & DB::connect($dsn, $options);
    if (PEAR::isError($db)){
        loginForm($db->getMessage());
        return false;
    } elseif (checkLogin($db, $login, $pwd)) {
        $_SESSION['logged'] = true;
        return true;
    } else {
        loginForm("incorrect login or password");
        return false;
    }
}

function loginForm($msg) {
    if (defined("REDIRECT_LOGIN_FORM")) {
        $dir = dirname($_SERVER["PHP_SELF"]);
        //echo "Location: {$dir}/index.php";
        header("Location: {$dir}/index.php");
    } else {
        include('templates/login_form.php');
    }
}



?>
