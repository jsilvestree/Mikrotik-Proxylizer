<?php
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/index.php");
    return false;
}
if (!isset($cond_errormesage)) { ?>
<table>
    <tr>
        <td style="width : 150px" align="center">Data base size : </td>
        <td style="width : 150px" align="center" id="table_size"><?=$_SESSION['table_size'] ?><?=$loading; ?> MB</td>
    </tr>
</table>
<? } else {
    errorMesage($cond_errormesage);
}
?>