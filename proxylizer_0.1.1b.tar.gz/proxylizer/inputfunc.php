<?php
/****************************************************************************
*                                                                           *
*    MikroTik Proxylizer, Web-proxy log analyzer                            *
*    Copyright (C) 2009  MikroTik                                           *
*                                                                           *
*    This program is free software: you can redistribute it and/or modify   *
*    it under the terms of the GNU General Public License as published by   *
*    the Free Software Foundation, either version 3 of the License, or      *
*    (at your option) any later version.                                    *
*                                                                           *
*    This program is distributed in the hope that it will be useful,        *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of         *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
*    GNU General Public License for more details.                           *
*                                                                           *
*    You should have received a copy of the GNU General Public License      *
*    along with this program.  If not, see <http://www.gnu.org/licenses/>.  *
*                                                                           *
****************************************************************************/
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/index.php");
    return false;
}

function prepUserInput($rec, $len = 255) {
    return substr(str_replace(array("\\\"", "\\'", "\\\\"), array("\"", "'", "\\"), 
                              strip_tags($rec)),
                  0, $len);
}

function prepForQuery($rec) {
    return str_replace("'", "''", $rec);
}

function requestToQuery($rec, $len = 255) {
    return prepForQuery(prepUserInput($rec, $len), $len);
}

function prepForHTML($rec) {
    return htmlspecialchars($rec, ENT_QUOTES);
}

function checkDBPaswrd($pwd) {
	if (strlen($pwd) > 20) {
        return "Sorry DB password cann't be longer then 20 symbols";
    }
    if (ereg("@|'|/|:", $pwd)) {
        return "Sorry can't use @, ' or / in DB password";
    }
    return "";
}

function checkWebPaswrd($pwd) {
    if (strlen($pwd) > 20) {
        return "Sorry webpage password cann't be longer then 20 symbols";
    } elseif (strlen($pwd) < 5) {
        return "Sorry webpage password cann't be shorter then 5 symbols";
    }
    if (ereg("@|'|/|:", $pwd)) {
        return "Sorry can't use @, ' or / in webpage password";
    }
    return "";
}

function formatStartDate($t) {
    $timestamp = strtotime($t);
    if ($timestamp === false) {
        return false;
    } else {
        $t = date("Y-m-d H:i:s", $timestamp);
        return $t;
    }
}

function formatEndDate($t) {
    $timestamp = strtotime($t);
    if ($timestamp === false) {
        return false;
    } else {
        $checktime = date("Y-m-d", $timestamp);
        $checktime = strtotime($checktime);
        if ($checktime == $timestamp) {
            $timestamp = $timestamp + 86399;
        }
        $t = date("Y-m-d H:i:s", $timestamp);
        return $t;
    }
}

function checkLogin(& $db, $login, $pwd) {

    $query = "SELECT * from login WHERE login = '{$login}' AND passw = '{$pwd}'";
    $res =& $db->query($query);
    if ($row =& $res->fetchRow()) {
        return true;
    }
    return false;
}

function parseAndSplitInput($input_string, $maxlength, $wordlength) {
    if (strlen($input_string) > $maxlength) {
        return false;
    } else {
        $words = prepUserInput($input_string);
        $words = explode(" ", $input_string);
        foreach ($words as $key=>$word) {
            $word .= "";
        	if (strlen($word) > $wordlength) {
        		$split_word = str_split($word, strlen($word) / 2 + strlen($word) % 2);
        		$words[$key] = implode(" ", $split_word);
        	}
        }
        return implode(" ", $words);
    }
    
}
?>