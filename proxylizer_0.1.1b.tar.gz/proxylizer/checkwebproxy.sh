#!/bin/bash

a=$(ps axuf | grep "webproxylogtomysql\.php" | grep -v "grep" | wc -l )

if [ $a = 0 ] ; then
	cd $(dirname $0)
	./webproxylogtomysql.php > /var/log/proxylizer/webproxytodb_debug.log 2> /var/log/proxylizer/webproxytodb_error.log </dev/null &
fi



