<?php

if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/index.php");
    return false;
}

if (!isset($hm_errormesage) || !isset($cond_errormesage)) {;?>
	
	    <h3>System status</h3>
<br/>
    <table border="0">
        <tr>
            <td style="width : 150px" align="right">HIT/MISS ratio : </td>
            <td style="width : 150px; padding-left: 10px" align="left" id="hit_miss"><?=$_SESSION['hitmiss'];?><?=$loading; ?> %</td>
      
        </tr>
        <tr>
            <td style="width : 150px" align="right" >Total domain count : </td>
            <td style="width : 150px; padding-left: 10px" align="left" id="domain_count"><?=$_SESSION['domain_count'];?><?=$loading; ?></td>
        </tr>
        <tr>
    		<td style="width: 150px;" align="right"> Total hit count : </td>
    		<td style="width: 150px; padding-left: 10px" align="left" id="hit_count"><?=$_SESSION['hit_count'];?><?=$loading;?></td>
    	</tr>
    	<tr>
    	   <td style="width: 150px;" align="right"> Oldest record : </td>
    	   <td style="width: 150px; padding-left: 10px" align="left" id="min_date"><?=$_SESSION['min_date'];?><?=$loading;?></td>
    	</tr>
    	<tr>
           <td style="width: 150px;" align="right"> Latest record : </td>
           <td style="width: 150px; padding-left: 10px" align="left" id="max_date"><?=$_SESSION['max_date'];?><?=$loading;?></td>
        </tr>
        <tr>
            <td style="width : 150px" align="right">Data base size : </td>
            <td style="width : 150px; padding-left: 10px" align="left" id="table_size"><?=$_SESSION['table_size'] ?><?=$loading; ?> MB</td>
        </tr>
        <tr>
            <td style="width : 150px" align="right"></td>
            <td style="width : 150px; padding-left: 10px; padding-top: 20px" align="left">
            	<input class="refreshbutton" type="button" name="refresh" value="Refresh" onclick="xmlhttpPost('adm_panel_act.php', true)"/>
            	<br/>
            </td>
        </tr>
        
        	

    </table>
<?} else {
    errorMesage($hm_errormesage);
}
?>