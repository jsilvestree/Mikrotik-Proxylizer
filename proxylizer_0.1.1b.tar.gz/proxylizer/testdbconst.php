#!/usr/bin/php
<?

require_once("dbconstants.php");
$counter = 1;
foreach ($TABLES as $T) {
    echo "nr." . $counter . "\n";
    echo $T->getCreateStatement();
    foreach ($T->indices as & $index) {
        echo $index->getCreateStatement();
    }
    foreach ($T->foreignkeys as & $for_key) {
        echo $for_key->getCreateStatement();
    }
    $counter++;
}

?>
