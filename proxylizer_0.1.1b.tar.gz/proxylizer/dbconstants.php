<?php
/****************************************************************************
*                                                                           *
*    MikroTik Proxylizer, Web-proxy log analyzer                            *
*    Copyright (C) 2009  MikroTik                                           *
*                                                                           *
*    This program is free software: you can redistribute it and/or modify   *
*    it under the terms of the GNU General Public License as published by   *
*    the Free Software Foundation, either version 3 of the License, or      *
*    (at your option) any later version.                                    *
*                                                                           *
*    This program is distributed in the hope that it will be useful,        *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of         *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
*    GNU General Public License for more details.                           *
*                                                                           *
*    You should have received a copy of the GNU General Public License      *
*    along with this program.  If not, see <http://www.gnu.org/licenses/>.  *
*                                                                           *
****************************************************************************/
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/index.php");
    return false;
}
require_once('db_class.php');

// Tables
$logTable = new Table("webproxylog");
$logTable->addField(new TableField("ID", "bigint(20)", true, true), true);
$logTable->addField(new TableField("host", "int(11)", true));
$f_log_event_date = new TableField("event_date", "date", true);
$logTable->addField($f_log_event_date);
$f_log_event_time = new TableField("event_time", "time", true);
$logTable->addField($f_log_event_time);
$f_log_ip = new TableField("IP", "int(11)", true);
$logTable->addField($f_log_ip);
$f_log_domainID = new TableField("domain_id", "int(10)", true);
$logTable->addField($f_log_domainID);
$logTable->addField(new TableField("path", "varchar(128)",false));
$logTable->addField(new TableField("action", "int(1)", true));
$f_log_cache = new TableField("cache", "int(1)", true);
$logTable->addField($f_log_cache);

$domainTable = new Table("domain");
$domainTable->addField(new TableField("id", "int(10)", true, true), true);
$f_dom_subdomain = new TableField("subdomain", "varchar(32)", true);
$domainTable->addField($f_dom_subdomain);
$f_dom_domain = new TableField("domain", "varchar(32)", true);
$domainTable->addField($f_dom_domain);
$f_dom_topdomain = new TableField("topdomain", "varchar(32)", true);
$domainTable->addField($f_dom_topdomain);

$gen_reports = new Table("generated_reports");
$gen_reports -> addField(new TableField("id", "int(10)", true, true),true);
$f_gen_rep_reportid = new TableField("report_id", "int(10)", true);
$gen_reports -> addField($f_gen_rep_reportid);
$gen_reports -> addField(new TableField("date_time", "timestamp", true, false, "CURRENT_TIMESTAMP"));
$gen_reports -> addField(new TableField("datestart", "date", true));
$gen_reports -> addField(new TableField("dateend", "date", true));
$gen_reports -> addField(new TableField("msg", "mediumtext", true));
$gen_reports -> addField(new TableField("status", "int(1)"));
$gen_reports -> addField(new TableField("execute_time", "int(10)", true));
$gen_reports -> addField(new TableField("php_pid", "int(10)", true));
$gen_reports -> addField(new TableField("execute_count", "int(10)", true, false, "0"));
$gen_reports -> addField(new TableField("version_no", "varchar(32)", true));

$report_conf = new Table("report_config");
$f_rep_conf_id = new TableField("id", "int(10)", true, true);
$report_conf -> addField($f_rep_conf_id, true);
$report_conf -> addField(new TableField("report_name", "varchar(25)", true));
$report_conf -> addField(new TableField("email", "varchar(128)",true));
$report_conf -> addField(new TableField("send_to_admin", "tinyint(1)", true));
$report_conf -> addField(new TableField("frequency", "varchar(12)", true));
$report_conf -> addField(new TableField("rep_type", "int(1)", true));
$report_conf -> addField(new TableField("date_start", "date"));
$report_conf -> addField(new TableField("date_end", "date"));
$report_conf -> addField(new TableField("weekdays","int(3)", true));
$report_conf -> addField(new TableField("send_date_start", "date", false));
$report_conf -> addField(new TableField("send_date_end", "date"));
$report_conf -> addField(new TableField("send_time", "time"));
$report_conf -> addField(new TableField("send_weekday", "int(3)", true));
$report_conf -> addField(new TableField("IP", "int(11)", true));
$report_conf -> addField(new TableField("sub_domain", "varchar(32)", true));
$report_conf -> addField(new TableField("domain", "varchar(32)",true));
$report_conf -> addField(new TableField("topdomain", "varchar(32)", true));
$report_conf -> addField(new TableField("top", "int(3)", true));
$report_conf -> addField(new TableField("is_active", "timestamp", true, false, "CURRENT_TIMESTAMP")); 

$time_intervals = new Table("time_intervals");
$time_intervals -> addField(new TableField("id", "int(10)", true, true),true);
$f_time_int_reportid = new TableField("report_id", "int(10)", true);
$time_intervals -> addField($f_time_int_reportid);
$time_intervals -> addField(new TableField("time_start", "time"));
$time_intervals -> addField(new TableField("time_end", "time"));

$ip_users = new Table("ip_users");
$ip_users -> addField(new TableField("id", "int(10)", true, true),true);
$f_ip_users_ip = new TableField("ip", "int(11)", true);
$ip_users -> addField($f_ip_users_ip);
$f_ip_users_name = new TableField("name","varchar(32)", true);
$ip_users -> addField($f_ip_users_name);
$f_ip_users_email = new TableField("email", "varchar(128)", true);
$ip_users -> addField($f_ip_users_email);
$ip_users -> addField(new TableField("is_admin", "tinyint(1)", true));
$ip_users -> addField(new TableField("is_empty_report_receiver", "tinyint(1)", true, false, "1"));

$proxylizerconfig = new Table("proxylizerconfig");
$f_p_conf_name = new TableField("name", "varchar(32)", true);
$proxylizerconfig -> addField($f_p_conf_name, true);
$proxylizerconfig -> addField(new TableField("value", "varchar(256)", true));

$TABLES = array($logTable, $domainTable, $report_conf, $gen_reports, $time_intervals, $ip_users, $proxylizerconfig);


// Indices
$logTable->addIndex(new TableIndex($logTable, array($f_log_ip), false));
$logTable->addIndex(new TableIndex($logTable, array($f_log_domainID), false));
$logTable->addIndex(new TableIndex($logTable, array($f_log_event_date,$f_log_event_time), false));
$logTable->addIndex(new TableIndex($logTable, array($f_log_cache), false));

$domainTable->addIndex(new TableIndex($domainTable,array($f_dom_subdomain,$f_dom_domain,$f_dom_topdomain),true));

$proxylizerconfig->addIndex(new TableIndex($proxylizerconfig, array($f_p_conf_name), true));

$ip_users->addIndex(new TableIndex($ip_users, array($f_ip_users_name, $f_ip_users_ip, $f_ip_users_email), true));

//Foreign keys

$gen_reports -> addForeignKey(new ForeignKey($gen_reports, $f_gen_rep_reportid, $report_conf, $f_rep_conf_id));
$time_intervals -> addForeignKey(new ForeignKey($time_intervals, $f_time_int_reportid, $report_conf, $f_rep_conf_id));
?>
