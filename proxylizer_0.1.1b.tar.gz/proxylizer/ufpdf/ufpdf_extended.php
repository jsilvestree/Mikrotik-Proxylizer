<?php
class PDF extends UFPDF {
    //Page header
    function Footer() {
        //Logo
        //$this->Image('images/mtlogo2.jpg');
    }
    function RepTable($header,$data, $rep_type) {
        //Header
        //print_r($data);
        if ($rep_type == 1) {
            $w=array(70, 70, 40);
        } elseif ($rep_type == 2) {
            $w=array(70, 20, 60, 30);
        }
        $this->printTableHeader($header, $w);
        //Color and font restoration
        $this->SetFillColor(255,255,255);
        $this->SetTextColor(0);
        $this->SetFont('');
        //Data
        foreach($data as $row)
        {
            if ($counter > 36) {
                $this->AddPage();
                $this->printTableHeader($header, $w);
                $counter = -5;
            }
            $first_cell = parseCellString($row[0], $w[0], $this);
            $this->Cell($w[0],6 ,$first_cell, 1, 0, 'C');
            $this->Cell($w[1],6,$row[1], 1, 0, 'C');
            $this->Cell($w[2],6,$row[2], 1, 0, 'C');
            if (count($row) >= 4) {
                $this->Cell($w[3],6,$row[3], 1, 0, 'C');
            }
            $this->Ln();
            $counter++;
        }
        $this->Cell(array_sum($w),0,'','T');
    }
    function printTableHeader($header, $w) {
        //Colors, line width and bold font
        $this->SetFillColor(204,204,204);
        $this->SetTextColor(255);
        $this->SetDrawColor(0, 0, 0);
        $this->SetLineWidth(.3);
        //$this->SetFont('Times');
        //Header
        for($i=0;$i<count($header);$i++) {
            $this->Cell($w[$i],7,$header[$i],1,0,'C',true);
        }
        $this->Ln();
        $this->SetFillColor(255,255,255);
        $this->SetTextColor(0);
        $this->SetFont('');
    } 
}

?>