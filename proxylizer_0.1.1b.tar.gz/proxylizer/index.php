<?php
/****************************************************************************
*                                                                           *
*    MikroTik Proxylizer, Web-proxy log analyzer                            *
*    Copyright (C) 2009  MikroTik                                           *
*                                                                           *
*    This program is free software: you can redistribute it and/or modify   *
*    it under the terms of the GNU General Public License as published by   *
*    the Free Software Foundation, either version 3 of the License, or      *
*    (at your option) any later version.                                    *
*                                                                           *
*    This program is distributed in the hope that it will be useful,        *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of         *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
*    GNU General Public License for more details.                           *
*                                                                           *
*    You should have received a copy of the GNU General Public License      *
*    along with this program.  If not, see <http://www.gnu.org/licenses/>.  *
*                                                                           *
****************************************************************************/

define("STARTED_FROM_INDEX", 1);
session_start();
include ("constants.php");
include ("functions.php");
include("templates/html_header.php");
$action = $_REQUEST['action'];
//$subact = $_REQUEST['subact'];
define("THIS_PAGE", $_SERVER["PHP_SELF"]);
define("ACTIVE_PAGE", THIS_PAGE . "?action={$action}" /*&subact={$subact}"*/);

if (!@include("config_constants.php")) {
    include("setup.php");
} elseif (include("login.php")) {
    if ($action == "") {
        $action = "adm_panel";
    }
    include("templates/main_head.php");
    switch ($action) {
    case "adm_panel":
        include("adm_panel.php");
        break;
    case "mail_report":
        include("mail_report.php");
        break;
    case "ip_users":
        include("ip_users.php");
        break;
    case "config":
        include("proxylizer_config.php");
        break;
    }
    include("templates/main_footer.php");
}
include("templates/html_footer.php");
?>

