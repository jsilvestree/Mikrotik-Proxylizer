<?php
/****************************************************************************
*                                                                           *
*    MikroTik Proxylizer, Web-proxy log analyzer                            *
*    Copyright (C) 2009  MikroTik                                           *
*                                                                           *
*    This program is free software: you can redistribute it and/or modify   *
*    it under the terms of the GNU General Public License as published by   *
*    the Free Software Foundation, either version 3 of the License, or      *
*    (at your option) any later version.                                    *
*                                                                           *
*    This program is distributed in the hope that it will be useful,        *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of         *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
*    GNU General Public License for more details.                           *
*                                                                           *
*    You should have received a copy of the GNU General Public License      *
*    along with this program.  If not, see <http://www.gnu.org/licenses/>.  *
*                                                                           *
****************************************************************************/
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/index.php");
    return false;
}

set_time_limit(0);
require_once 'DB.php';
if (!isset($_REQUEST['add']) || !isset($_REQUEST['save'])) {
    $addorsavename = "add";
    $addorsavevalue = "Add";
    $addorsaveuser = "add user";
}
if(isset($_REQUEST['add'])) {
    $valid_request = checkIpUserForm();
    if ($valid_request) {
        insertIpUserTable($valid_request['ip'], $valid_request['name'], 
                $valid_request['email'], $valid_request['isadmin'], $valid_request['empty_report']);
    }
}elseif(isset($_REQUEST['edit'])) {
    $cancelbutton = "<input type=\"submit\" name=\"cancel\" value=\"Cancel\"/>";
    $addorsavename = "save";
    $addorsavevalue = "Save";
    $addorsaveuser = "edit user data";
    $edit = (int)$_REQUEST['edit'];
    editIpUserTable($edit);
    $editordelete = "&idedit={$edit}";
} elseif(isset($_REQUEST['save'])) {
    $valid_request = checkIpUserForm();
    if ($valid_request) {
        $id = (int) $_REQUEST['idedit'];
        alterIpUserTable($id, $valid_request['ip'], $valid_request['name'], $valid_request['email'],
                 $valid_request['isadmin'], $valid_request['empty_report']);
    } else {
        $cancelbutton = "<input type=\"submit\" name=\"cancel\" value=\"Cancel\"/>";
        $addorsavename = "save";
        $addorsavevalue = "Save";
        $addorsaveuser = "edit user data";
    }
} elseif (isset($_REQUEST['delete'])) {
    $id = (int) $_REQUEST['delete'];
    deleteRowIpUserTable($id);
} elseif (isset($_REQUEST['cancel'])) {
    unset($_REQUEST);
} else {
    $checked2 = "checked=\"checked\"";
}
include("templates/ip_users_form.php");
writeIpUserTable();

function checkIpUserForm() {
global $errors, $errorcount;
    $valid_request = array();
    $valid_request['name'] = prepForQuery($_REQUEST['name']);
    if(isset($_REQUEST['e-mail'])) {
        if($_REQUEST['e-mail'] == "") {
            $errors .= errorMesage("Please enter e-mail address!");
            $errorcount++;
        } else {
            $isvalidemail = ereg("^[a-zA-Z0-9_\.]+@[a-zA-Z0-9\-]+\.[a-zA-Z0-9\-\.]+$", $_REQUEST['e-mail']);
            if($isvalidemail === false) {
                $errors .= errorMesage("Not valid e-mail address!");
                $errorcount++;
            } else {
                $valid_request["email"] = $_REQUEST['e-mail'];
            }
        }
    }
    if (isset($_REQUEST['isadmin'])) {
        $valid_request['isadmin'] = true; 
    } else {
        $valid_request['isadmin'] = false;
    }
    if (isset($_REQUEST['empty_report'])) {
        $valid_request['empty_report'] = true;
    } else {
        $valid_request['empty_report'] = false;
    }
    if(isset($_REQUEST['IP'])) {
        if($_REQUEST['IP'] != ""){
            $ip = ip2long($_REQUEST['IP']);
            if($ip == false) {
                $errors .= errorMesage("Invalid IP address!");
                $errorcount++;
            }
            $valid_request["ip"] = $ip; 
        } else {
            $errors .= errorMesage("No IP value selected!");
            $errorcount++;
        }
    }
    if($errorcount) {
        return false;
    } else {
    return $valid_request;
    }
}

function insertIpUserTable($ip, $name, $email, $isadmin, $is_empty_report) {
global $errors, $errorcount;
    if ($db = connectDB()) {
        $query = "INSERT INTO ip_users(ip, name, email, is_admin, is_empty_report_receiver) "
            . "VALUES ('{$ip}', '{$name}', '{$email}', '{$isadmin}', '{$is_empty_report}')";
        $insertdata = & $db->query($query);
        if (PEAR::isError($insertdata)) {
            $msg = $insertdata->getMessage();
            if ($msg == "DB Error: constraint violation") {
                $errors .= errorMesage("User alredy added!");
            } else {
                $errors .= errorMesage("Failed to insert data - " . $msg . "!");
            }
            return false;
        } elseif (setEmptyReportReceiver($db, $email, $is_empty_report)) {
            unset($_REQUEST);
        }
    } else {
        $errors = errorMesage("Failed to connect to data base!");
        $errorcount++;
        return false;
    }
}

function writeIpUserTable() {
global $errors, $errorcount;
    if ($db = connectDB()) {
        $query = "SELECT id, ip, name, email, is_admin, is_empty_report_receiver FROM ip_users";
        $res = & $db->query($query);
        if (PEAR::isError($res)){
            return false;
        } else {
            if ($row =& $res->fetchRow()) {
                $rowcounter = 1;
                writeIpUserTableHeader();
                writeIpUserTableRow($row, $rowcounter);
                $rowcounter++;
                $eoftable .= "</table>";
            } else {
                echo "<div align=\"center\" style='color: #FF0000; font-weight: bold;'>Please, add IP users!</div>";
            }
            while ($row =& $res->fetchRow()) {
                writeIpUserTableRow($row, $rowcounter);
                $rowcounter++;
            }
            echo $eoftable;
        }
    } else {
        $errors = errorMesage("Failed to connect to data base!");
        $errorcount++;
        return false;
    }
}

function writeIpUserTableHeader() {
    echo "<table class=\"report\" border=\"1\">\n";
    echo "<th align=\"center\">#</th>";
    echo "<th align=\"center\">IP</th>\n";
    echo "<th align=\"center\">Name</th>\n";
    echo "<th align=\"center\">e-mail</th>\n";
    echo "<th align=\"center\">Admin</th>\n";
    echo "<th align=\"center\">Actions</th>\n";
}

function writeIpUserTableRow(& $fetchedrow, $rowcounter) {
    echo "<tr>\n";
    echo "<td align=\"center\"> {$rowcounter}</td>\n";
    echo "<td align=\"center\"> " . long2ip($fetchedrow['1']) . "</td>\n";
    echo "<td align=\"center\"> {$fetchedrow['2']}</td>\n";
    if ($fetchedrow['5'] == true) {
        $empty_report = "&nbsp;<img src=\"images/icons/receive_empty_report.png\" 
                title = \"User receives empty reports\" alt=\" [Empty report receiver]\"/>";
    } else {
        $empty_report = "";
    }
    echo "<td align=\"center\"> {$fetchedrow['3']}{$empty_report}</td>\n";
    if ($fetchedrow['4'] == true) {
        echo "<td align=\"center\"> <img src=\"images/icons/tick_circle.png\" 
                title=\"User is administrator\" alt=\"X\"/> </td>\n";
    } else {
        echo "<td align=\"center\"> </td>\n";
    }
    echo "<td align=\"center\"><a href=\"" . ACTIVE_PAGE . "&edit=" . $fetchedrow['0'] . "\">
            <img src=\"images/icons/edit.png\" border=\"0\" title=\"Edit user\" alt=\"Edit\"/></a>
            <a href=\"". ACTIVE_PAGE . "&delete=" . $fetchedrow['0'] . "\">
            <img src=\"images/icons/delete.png\" border=\"0\" title=\"Delete user\" alt=\"Delete\"/></a></td>\n";
    echo "</tr>\n";
}

function editIpUserTable($field_id_edit) {
global $checked, $checked2;
global $errors, $errorcount;
    if($db = connectDB()) {
        $query = "SELECT id, ip, name, email, is_admin, is_empty_report_receiver FROM ip_users WHERE id=\"{$field_id_edit}\"";
        $res = & $db->query($query);
        if (PEAR::isError($res)){
            return false;
        } else {
            if ($row =& $res->fetchRow()) {
                $_REQUEST['IP'] = long2ip($row['1']);
                $_REQUEST['name'] = $row['2'];
                $_REQUEST['e-mail'] = $row['3'];
                if ($row['4'] == true) {
                    $checked = "checked=\"checked\"";
                }
                if ($row['5'] == true) {
                    $checked2 = "checked=\"checked\"";
                }
            }
        }
    } else {
        $errors = errorMesage("Failed to connect to data base!");
        $errorcount++;
        return false;
    }
}

function alterIpUserTable($id, $ip, $name, $email, $isadmin, $is_empty_report) {
global $errors, $errorcount;
    if($db = connectDB()) {
        $query = "UPDATE ip_users SET ip='{$ip}', name='{$name}', email='{$email}',"
            . " is_admin='{$isadmin}', is_empty_report_receiver='{$is_empty_report}' WHERE id='{$id}'";
        $update = & $db->query($query);
        if (PEAR::isError($update)){
            $errors .= errorMesage($update->getMessage());
            return false;
        } elseif (setEmptyReportReceiver($db, $email, $is_empty_report)) {
            unset($_REQUEST);
        }
    } else {
        $errors = errorMesage("Failed to connect to data base!");
        $errorcount;
        return false;
    }
}

function deleteRowIpUserTable($id) {
global $errors, $errorcount;
    if($db = connectDB()) {
        $query = "DELETE FROM ip_users WHERE id=\"{$id}\"";
        $delete =  & $db->query($query);
        if (PEAR::isError($update)){
            $errors = errorMesage("Error deleting record!");
            $errorcount++;
            return false;
        }
    } else {
        $errors = errorMesage("Failed to connect to data base!");
        $errorcount++;
        return false;
    }
}

function setEmptyReportReceiver(& $db, $email, $is_empty_report) {
global $errors;
    $query = "UPDATE ip_users SET is_empty_report_receiver='{$is_empty_report}' "
            . " WHERE email = '{$email}'";
    $update = & $db->query($query);
    if (PEAR::isError($update)){
        $msg = $update->getMessage();
        $errors .= errorMesage("Failed to update data - " . $msg . "!");
        return false;
    } else {
        return true;
    }
}

?>