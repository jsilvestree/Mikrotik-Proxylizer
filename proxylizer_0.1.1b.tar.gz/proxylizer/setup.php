<?php
/****************************************************************************
*                                                                           *
*    MikroTik Proxylizer, Web-proxy log analyzer                            *
*    Copyright (C) 2009  MikroTik                                           *
*                                                                           *
*    This program is free software: you can redistribute it and/or modify   *
*    it under the terms of the GNU General Public License as published by   *
*    the Free Software Foundation, either version 3 of the License, or      *
*    (at your option) any later version.                                    *
*                                                                           *
*    This program is distributed in the hope that it will be useful,        *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of         *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
*    GNU General Public License for more details.                           *
*                                                                           *
*    You should have received a copy of the GNU General Public License      *
*    along with this program.  If not, see <http://www.gnu.org/licenses/>.  *
*                                                                           *
****************************************************************************/
if (!defined("STARTED_FROM_INDEX")) {
    header("Location:". dirname($_SERVER["PHP_SELF"]) . "/index.php");
    return false;
}

$suporteddb = array(
        'mysql' => 'MySQL',
//         'ibase' => 'Interbase',
//         'mssql' => 'MicrosoftSQL',
//         'pgsql' => 'PostgreSQL',
//         'sqlite' => 'SQLite'
);

$errorMSG = checkDSN();
if ($errorMSG != "") {
    return configform($errorMSG);
}
$webusername = requestToQuery($_REQUEST['webusername']);
$webpassword = md5($_REQUEST['webpaswrd']);

require_once 'DB.php';
require_once 'dbconstants.php';
$dsn = createDsnString($dbtype, $dbusername, $paswrd, $dbhost, $dbname);
$options = array(
'debug'       => 2,
'portability' => DB_PORTABILITY_ALL,
);

if (isset($_REQUEST['droptable'])) {
    $db = & DB::connect($dsn, $options);
    if (PEAR::isError($db)) {
        return configform($db->getMessage());
    } else {
        dropTables();
        createTables($db);
        createConfConstFin();
    }
} elseif (isset($_REQUEST['changeparams'])) {
    configform("");
} elseif (isset($_REQUEST['submit'])) {
    $errorMSG = checkForm();
    if ($errorMSG != "") {
        return configform($errorMSG);
    }
    $db = & DB::connect($dsn, $options);
    if (PEAR::isError($db)){
    	$message = $db->getMessage();
    //echo $dsn;
    	if ($message == "DB Error: no such database") {
            $query = "CREATE DATABASE {$dbname}";
            $dsn = createDsnString($dbtype, $dbusername, $paswrd, $dbhost, "");
            $db = & DB::connect($dsn, $options);
            $createDB = & $db -> query($query);
            if (PEAR::isError($createDB)) {
                return configform($createDB->getMessage());
            } else {
                $dsn .= "/{$dbname}"; 
                $db = & DB::connect($dsn, $options);
                if (PEAR::isError($db)) {
                    return configform($db->getMessage());
                } else {
                    $createdDB = " * Data base {$dbname} created<br/>\n";
                    createTables($db);
                    storeLogin($db);
                    createConfConstFin();
                }
            }
        } else {
        	return configform($db->getMessage());
        }
    } else {
    	$errTables = checkTableErrors();
    	if (count($errTables) > 0) {
    		return dropornotForm($errTables);
    	} else {
            storeLogin($db);
            createConfConstFin();
    	}
    	setVersionNumber($db);
        $db->disconnect();
    }
} else {
    return configform("Please fill all fields with *");
}

function storeLogin(& $db) {
global $dbname, $miscTableChanges;
global $webusername;
global $webpassword;
    $query = "SELECT login, passw from login";
    $islogintable = & $db->query($query);
    if (PEAR::isError($islogintable)) {
        $message = $islogintable->getMessage();
        if ($message == "DB Error: no such table") {
            $query1 = "CREATE TABLE {$dbname}.login ( 
                    login VARCHAR( 20 ) NOT NULL ,
                    passw VARCHAR( 32 ) NOT NULL COMMENT 'md5',
                    PRIMARY KEY ( login ))
                    ";
            $createtable = & $db->query($query1);
            if (PEAR::isError($createtable)) {
                return configform($createtable->getMessage());
            } else {
            $miscTableChanges .= " * login table created<br/>\n";
            insertLogin ($db);
            }
        } else {
            return configform($islogintable->getMessage());
        }
    } else {
        insertLogin($db);
    }
}

function insertLogin (& $db) {
global $dbname, $miscTableChanges;
global $webusername;
global $webpassword;
    $query = "INSERT INTO {$dbname}.login (login, passw) VALUES ('{$webusername}', '{$webpassword}');";
    $insertlogin = & $db->query($query);
    if (PEAR::isError($insertlogin)) {
        $message = $insertlogin->getMessage();
        if ($message == "DB Error: constraint violation") {
            $query2 = "UPDATE {$dbname}.login SET passw = '{$webpassword}' WHERE login.login = '{$webusername}'";
            $updatelogin = & $db->query($query2);
            if (PEAR::isError($updatelogin)) {
                return configform($updatelogin->getMessage());
            } else {
                $_SESSION['logged'] = true;
                $miscTableChanges .= "*Webpage login information updated<br/>\n";
                return true;
            }
        } else {
            return configform($insertlogin->getMessage());
        }
    } else {
        $_SESSION['logged'] = true;
        $miscTableChanges .= " * Webpage login informatin stored<br/>\n";
        return true;
    }
}

function createConfConstFin() {
    $is_created = createConfConst();
    if ($is_created !== true) {
        configform($is_created);
    } else {
        finalForm();
    }
}

function checkIsTable($table) {
global $db;
global $logTable, $domainTable;
    $query = "EXPLAIN {$table->name}";
    $is_table = & $db -> query($query);
    if (PEAR::isError($is_table)){
        $message = $is_table->getMessage();
        if ($message == "DB Error: no such table") {
            return createTables($db);
        } else {
            return $is_table->getMessage();
        }
    } else {
        $res =& $db->query($query);
        if (PEAR::isError($res)) {
            return $res->getMessage();
        } else {
            while ($row =& $res->fetchRow()) {
                $counter++;
                $table->checkField( $row[0], $row[1] );
            }
            if ($table->checkFieldCount() > $counter) {
                echo "<div style='font-size: 2em' align=\"center\" style='color: #FF0000; font-weight: bold';> Too few fields in {$table->name} table!</div>";
                return false;
            } elseif ( $table->checkFieldCount() < $counter) {
                echo "<div style='font-size: 2em' align=\"center\" style='color: #FF0000; font-weight: bold';> {$table->name} table has too much fields!</div>";
                return false;
            } else {
                return true;
            }
        }
    }
    return true;
}

function checkTableErrors() {
global $TABLES;
    $ret = array();
    foreach ($TABLES as & $TABLE) {
    	if ($TABLE->isCorrupted()) array_push($ret, $TABLE); 
    }
	return $ret;
}

function checkIsAllTables() {
global $db;
global $TABLES;
    foreach ($TABLES as & $T) {
        if (!checkIsTable($T)) {
            return false;
        }
    }
    return true;
}

function checkForm() {
global $suporteddb;
    if ($_REQUEST['paswrd'] != $_REQUEST['paswrd2']) {
        return "DB passwords didn't match!";
    }
    if ($_REQUEST['webpaswrd'] != $_REQUEST['webpaswrd2']) {
        return "Webpage passwords didn't match!";
    }
    $chDBpaswrd = checkDBPaswrd($_REQUEST['paswrd']);
    if ($chDBpaswrd !== "") {
        return $chDBpaswrd;
    }
    $chwebpaswrd = checkWebPaswrd($_REQUEST['webpaswrd']);
    if ($chwebpaswrd !== "") {
        return $chwebpaswrd;
    }
    if (!in_array($_REQUEST['dbtype'], array_keys($suporteddb))) {
        return "Data base not suported";
    }
    if ($_REQUEST['dbhost'] == "") {
        return "Please type data base host";
    }
    if ($_REQUEST['dbname'] == "") {
        return "Please type data base name";
    }
    if ($_REQUEST['dbusername'] == "") {
        return "Please type data base username";
    }
    if ($_REQUEST['webusername'] == "") {
        return "Please type webpage username";
    }
    if ($_REQUEST['webpaswrd'] == "" || $_REQUEST['webpaswrd2'] == "") {
        return "Please type webpage password";
    }
    return "";
}

function createTables(& $db) {
global $TABLES;
global $createdTables, $createdIndices, $createdForeignKeys;
    foreach ($TABLES as $T) {
        $T->createForKey($createRes);
        if ($createRes & TC_FK_OK) {
            $createdForeignKeys .= "* Foreign key on {$T->name} table created<br/>\n";
        }
    }
    return true;
}

function createConfConst(){
global $miscTableChanges;

    require_once("config_const_template.php");
    $const_to_replace = array( "DB_TYPE" => $_REQUEST['dbtype'],
                        "DB_HOST" => $_REQUEST['dbhost'],
                        "DB_NAME" => $_REQUEST['dbname'],
                        "DB_USERNAME" => $_REQUEST['dbusername'],
                        "DB_PASSWORD" => $_REQUEST['paswrd']
                        );
    $contents = file_get_contents("config_const_template.php");
    $contents = str_replace($config_const, $const_to_replace, $contents);
    $is_create_file = @file_put_contents("config_constants.php",$contents);
    if ($is_create_file == false) {
        return "Error creating file. Please check permisions for directory!";
    } else {
    $miscTableChanges .= "<div>* File config_constants.php created<div/>\n";
    return true;
    }
}

function configform($msg) {
global $suporteddb;
global $dbtype;
global $dbhost;
global $dbname;
global $dbusername;
global $webusername;
    foreach ($suporteddb as $key => $value) {
        $dboption .= "<option value=\"{$key}\">{$value}</option>\n";
    }
    include("templates/setup_form.php");
    return false;
}

function finalForm() {
global $createdTables, $createdIndices, $createdForeignKeys, $miscTableChanges, $createdDB;
    include("templates/final_form.php");
    $_SESSION['logged'] = true;
}

function dropornotForm(& $tables) {
global $dbtype;
global $dbhost;
global $dbname;
global $paswrd;
global $dbusername;
global $webusername;
    $errTables = "";
    foreach ($tables as $table) {
    	if ($errTables != "") $errTables .= ", ";
    	$errTables .= $table->name;
    }
    $dropTarget = count($tables) > 1 ? "them all" : "it";
    include("templates/dropornot_form.php"); 
}

function dropTables() {
global $TABLES;
    foreach ($TABLES as & $T) {
    	if ($T->isCorrupted()) $T->drop();
    }
}

function setVersionNumber($db) {
    $ver_num = file_get_contents("version_number.txt");
    $query =  "SELECT name, value FROM proxylizerconfig WHERE name='version_number'";
    $res = & $db -> query($query);
    if(PEAR::isError($res)) {
        return configform($res->getMessage());
    } else {
        if($row = & $res->fetchRow()) {
            $query = "UPDATE proxylizerconfig SET value='{$ver_num}' WHERE name='version_number'";
            $update = &  $db -> query($query);
            if(PEAR::isError($update)) {
                return configform($insert->getMessage());
            }
        } else {
            $query = "INSERT INTO proxylizerconfig(name, value) VALUES('version_number','{$ver_num}') ";
            $insert = & $db -> query($query);
            if(PEAR::isError($insert)) {
                return configform($insert->getMessage());
            }
        }
    }
}

?>
