/****************************************************************************
*                                                                           *
*    MikroTik Proxylizer, Web-proxy log analyzer                            *
*    Copyright (C) 2009  MikroTik                                           *
*                                                                           *
*    This program is free software: you can redistribute it and/or modify   *
*    it under the terms of the GNU General Public License as published by   *
*    the Free Software Foundation, either version 3 of the License, or      *
*    (at your option) any later version.                                    *
*                                                                           *
*    This program is distributed in the hope that it will be useful,        *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of         *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
*    GNU General Public License for more details.                           *
*                                                                           *
*    You should have received a copy of the GNU General Public License      *
*    along with this program.  If not, see <http://www.gnu.org/licenses/>.  *
*                                                                           *
****************************************************************************/
function xmlhttpPost(strURL, isButton) {
    var xmlHttpReq = false;
    var self = this;
    // Mozilla/Safari
    if (window.XMLHttpRequest) {
        self.xmlHttpReq = new XMLHttpRequest();
    }
    // IE
    else if (window.ActiveXObject) {
        self.xmlHttpReq = new ActiveXObject("Microsoft.XMLHTTP");
    }
    self.xmlHttpReq.open('POST', strURL, true);
    if (isButton == true) {
    	document.getElementById("hit_miss").innerHTML = "<img src=\"images/icons/loading.gif\" />";
        document.getElementById("domain_count").innerHTML = "<img src=\"images/icons/loading.gif\" />";
        document.getElementById("table_size").innerHTML = "<img src=\"images/icons/loading.gif\" />";
        document.getElementById("hit_count").innerHTML = "<img src=\"images/icons/loading.gif\" />";
        document.getElementById("min_date").innerHTML = "<img src=\"images/icons/loading.gif\" />";
        document.getElementById("max_date").innerHTML = "<img src=\"images/icons/loading.gif\" />";
    }
    self.xmlHttpReq.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    self.xmlHttpReq.onreadystatechange = function() {
        if (self.xmlHttpReq.readyState == 4) {
            updatePage(self.xmlHttpReq.responseText, isButton);
        }
    }
    self.xmlHttpReq.send("");
}

function updatePage(str, isButton) {
    var result = str.split(";");
    // special identifier sent as prefix
    if (result[0] != "AJAXRESP") result = new Array("");
    var perc = result[1] ? (result[1] + " %") : "unknown";
    var dc = result[2] ? result[2] : "unknown";
    var ts = result[3] ? (result[3] + " MB") : "unknown";
    var hc = result[4] ? result[4] : "unknown";
    var mind = result[5] ? result[5] : "unknown";
    var maxd = result[6] ? result[6] : "unknown";
    document.getElementById("hit_miss").innerHTML = perc;
    document.getElementById("domain_count").innerHTML = dc;
    document.getElementById("table_size").innerHTML = ts;
    document.getElementById("hit_count").innerHTML = hc;
    document.getElementById("min_date").innerHTML = mind;
    document.getElementById("max_date").innerHTML = maxd;
    
}