<?php
/****************************************************************************
*                                                                           *
*    MikroTik Proxylizer, Web-proxy log analyzer                            *
*    Copyright (C) 2009  MikroTik                                           *
*                                                                           *
*    This program is free software: you can redistribute it and/or modify   *
*    it under the terms of the GNU General Public License as published by   *
*    the Free Software Foundation, either version 3 of the License, or      *
*    (at your option) any later version.                                    *
*                                                                           *
*    This program is distributed in the hope that it will be useful,        *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of         *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
*    GNU General Public License for more details.                           *
*                                                                           *
*    You should have received a copy of the GNU General Public License      *
*    along with this program.  If not, see <http://www.gnu.org/licenses/>.  *
*                                                                           *
****************************************************************************/
define("STARTED_FROM_INDEX", 2);
require_once('functions.php');
require_once ('DB.php');

// check authorization
session_start();
define("REDIRECT_LOGIN_FORM", 1);
if (!include("login.php")) return false;
// to allow concurent scripts (user may proceed to other section, while statistics are loading)
session_write_close();

if($db = connectDB()) {
    if (PEAR::isError($db)) {
        $errormesage = $db->getMessage();
        $is_error = true;
    } else {
        $query = "SELECT data_length + index_length as size FROM information_schema.tables 
                WHERE table_schema = '{$config_const['DB_NAME']}'
                AND (table_name = 'webproxylog' or table_name = 'domain')";
        $res =& $db->query($query);
        if (PEAR::isError($res)) {
            $errormesage = $res->getMessage();
        } else {
            $size = 0;
            while ($row =& $res->fetchRow()) {
                $size += $row['0'];
            }
        }
        $size = $size / (1024 * 1024);
        $size = round($size, 2);
    
        $query = "SELECT COUNT(*) FROM webproxylog where cache='1'";
        $res =& $db->query($query);
        $hit = 0;           
        if (PEAR::isError($res)) {
            $errormesage = $res->getMessage();
        } else {
            if ($row =& $res->fetchRow()) {
                $hit = $row['0'];
            }
        }
        $query = "SELECT COUNT(*) FROM webproxylog";
    	$res =& $db->query($query);
    	$row_count = 0;
    	if (PEAR::isError($res)) {
    		$errormesage = $res->getMessage();
    	} else {
    		if ($row =& $res->fetchRow()) {
    			$row_count = $row['0'];
    		}
    	}
    	if ($row_count == 0) {
    		$hit_miss = 0;
    	} else {
    		$hit_miss = round(($hit / $row_count) * 100, 2);
    	}
        $query = "SELECT COUNT(*) FROM domain;";
        $res =& $db->query($query);
        if (PEAR::isError($res)) {
            $errormesage = $res->getMessage();
        } else {
            if ($row =& $res->fetchRow()) {
                $domain_count = $row['0'];
            }
        }
        $query = "SELECT event_date, event_time FROM webproxylog ORDER BY event_date DESC , event_time DESC LIMIT 1";
        $res =& $db->query($query);
        if (PEAR::isError($res)) {
            $errormesage = $res->getMessage();
        } else {
            if ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
                $max_date = date("Y-m-d H:i", strtotime($row['event_date'] . " " . $row['event_time']));
            }
        }
        $query = "SELECT event_date, event_time FROM webproxylog ORDER BY event_date ASC , event_time ASC LIMIT 1";
        $res =& $db->query($query);
        if (PEAR::isError($res)) {
            $errormesage = $res->getMessage();
        } else {
            if ($row =& $res->fetchRow(DB_FETCHMODE_ASSOC)) {
                $min_date = date("Y-m-d H:i", strtotime($row['event_date'] . " " . $row['event_time']));
            }
        }
    } 
}
@session_start();
$_SESSION['errormesage'] = $errormesage;
$_SESSION['table_size'] = $size;
$_SESSION['hitmiss'] = $hit_miss;
$_SESSION['domain_count'] = $domain_count;
$_SESSION['hit_count'] = $row_count;
$_SESSION['min_date'] = $min_date;
$_SESSION['max_date'] = $max_date;
echo "AJAXRESP;" . $_SESSION['hitmiss'] . ";" . $_SESSION['domain_count'] . ";" . $_SESSION['table_size'] . ";" 
        . $_SESSION['hit_count'] . ";" . $_SESSION['min_date'] . ";" . $_SESSION['max_date'];
?>